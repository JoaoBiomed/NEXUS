
import { GoogleGenAI, Type } from "@google/genai";
import { ProtocolRequest, LifestyleTip, Compound } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// 1. Pesquisa / Grounding (Flash 2.5) - Traduzido
export const searchMedicalInfo = async (query: string): Promise<{ text: string; sources: any[] }> => {
  if (!apiKey) throw new Error("API Key missing");
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Forneça um resumo clínico conciso e em Português para um endocrinologista sobre: ${query}. 
      Use formatação Markdown:
      - Use "### " para subtítulos.
      - Use bullets para listas.
      - Destaque termos importantes com **negrito**.
      Foque em contraindicações e estudos recentes.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "Nenhum resultado encontrado.";
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    return { text, sources };
  } catch (error) {
    console.error("Search failed:", error);
    return { text: "Erro ao recuperar dados médicos.", sources: [] };
  }
};

// 2. Raciocínio de Protocolo Complexo (Thinking Mode - Pro 3) - Traduzido & Integrado
export const generateProtocolWithThinking = async (request: ProtocolRequest): Promise<string> => {
  if (!apiKey) throw new Error("API Key missing");

  // Construção do contexto avançado se disponível
  let integratedContext = "";
  if (request.genetics) {
    integratedContext += `
    DADOS iMEDDIS (FARMACOGENÉTICA):
    - Metabolismo Hepático: ${request.genetics.metabolism}
    - Risco Aromatização (CYP19A1): ${request.genetics.aromatizationRisk}
    - Afinidade SHBG: ${request.genetics.shbgAffinity}
    - Polimorfismos Detectados: ${request.genetics.polymorphisms.join(', ')}
    `;
  }

  if (request.labs) {
    integratedContext += `
    DADOS LabPro (BIOQUÍMICA ATUAL):
    - Função Hepática: ${request.labs.liverFunction}
    - Perfil Lipídico: ${request.labs.lipidProfile}
    - Testosterona Total: ${request.labs.hormonalStatus.testoTotal} ng/dL
    - Estradiol: ${request.labs.hormonalStatus.estradiol} pg/mL
    `;
  }

  const prompt = `
    Você é o Sistema NEXUS CORTEX, a inteligência clínica suprema.
    Atue como um Endocrinologista e Geneticista Sênior.
    
    PACIENTE: ${request.patientName || 'Não identificado'}
    - Peso: ${request.patientWeight}kg | Altura: ${request.patientHeight}cm | Gênero: ${request.gender}
    - Objetivo: ${request.goal}
    - Histórico: ${request.medicalHistory}

    ${integratedContext}
    
    TAREFA: Desenvolver um Protocolo Injetável/Implante de Alta Precisão.
    
    IMPORTANTE: Você DEVE justificar suas escolhas com base nos dados do iMeddis e LabPro se fornecidos.
    Exemplo: "Devido ao polimorfismo CYP19A1 (iMeddis), evitamos Testosterona Cipionato e optamos por..."
    Exemplo: "Como o LabPro indica TGO/TGP elevados, adicionamos Silimarina injetável..."

    Gere um documento estruturado em Markdown:

    # 🧬 ANÁLISE DE PRECISÃO (NEXUS INTELLIGENCE)
    (Cruze os dados genéticos com o objetivo. Explique o "Porquê" biológico da escolha da droga)

    # 💊 PROTOCOLO SUGERIDO
    (Liste ativos, doses exatas e frequência. Seja específico. Ex: "Enantato de Testosterona 100mg a cada 5 dias")
    *Se houver risco hepático, inclua protetores.*

    # 🧪 MONITORAMENTO & SEGURANÇA
    (Quais marcadores do LabPro devemos vigiar nas próximas semanas?)

    # 🥑 OTIMIZAÇÃO DE ESTILO DE VIDA
    (Ajustes na dieta/treino baseados no perfil metabólico do iMeddis)

    Use formatação rica, ícones e negrito para facilitar a leitura rápida.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }, // Max thinking para raciocínio profundo
      },
    });

    return response.text || "Não foi possível gerar o protocolo.";
  } catch (error) {
    console.error("Thinking protocol failed:", error);
    return "Erro ao gerar protocolo. Tente novamente.";
  }
};

// 3. Geração de Imagem para Educação (Pro 3 Image)
export const generateEducationalVisual = async (prompt: string, size: '1K' | '2K' | '4K'): Promise<string | null> => {
  if (!apiKey) throw new Error("API Key missing");

  try {
    const model = 'gemini-3-pro-image-preview'; 

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [{ text: `Medical illustration, clean, professional, anatomical style, white background: ${prompt}` }],
      },
      config: {
        imageConfig: {
            aspectRatio: "16:9",
            imageSize: size,
        },
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image gen failed:", error);
    return null;
  }
};

// 4. Edição de Imagem (Nano Banana / Flash Image)
export const editMedicalImage = async (imageBase64: string, instruction: string): Promise<string | null> => {
  if (!apiKey) throw new Error("API Key missing");

  const base64Data = imageBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: 'image/png',
            },
          },
          {
            text: instruction,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;

  } catch (error) {
    console.error("Image edit failed:", error);
    return null;
  }
}

// 5. Geração de Plano de Estilo de Vida Científico (JSON)
export const generateLifestylePlan = async (goal: string): Promise<LifestyleTip[]> => {
  if (!apiKey) throw new Error("API Key missing");

  // Prompt estritamente científico e focado em sinergia terapêutica com adaptações práticas
  const prompt = `Atue como uma Enfermeira Chefe Especialista em Nutrologia e Práticas Injetáveis.
  Crie 3 diretrizes científicas de "Adaptação de Estilo de Vida" para POTENCIALIZAR a terapia focada em: ${goal}.
  
  REGRAS:
  1. EVITE termos holísticos ou genéricos. Seja técnica e prática.
  2. FOQUE em adaptações que o paciente deve fazer na rotina (ex: horário de sono, tipo de nutriente específico para sinergia, gestão de stress).
  3. Baseie-se em cronobiologia e bioquímica.
  
  As categorias DEVEM ser mapeadas para:
  - Nutrition (Nutrição Clínica / Sinergia de Nutrientes)
  - Sleep (Higiene do Sono & Recuperação)
  - Mental (Gestão Neurocomportamental)

  Retorne APENAS um JSON array válido.
  Cada item deve ter: id, title (curto e de alto impacto), description (explicação científica da adaptação), category (Nutrition, Sleep, Mental) e imageUrl (use uma URL placeholder do Unsplash válida se possível, ou deixe string vazia).`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING },
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    category: { type: Type.STRING, enum: ["Nutrition", "Sleep", "Mental"] },
                    imageUrl: { type: Type.STRING },
                },
                required: ["id", "title", "description", "category", "imageUrl"],
            },
        },
      },
    });

    if (response.text) {
        let tips = JSON.parse(response.text) as LifestyleTip[];
        tips = tips.map((t, i) => ({
            ...t,
            imageUrl: t.imageUrl && t.imageUrl.startsWith('http') ? t.imageUrl : `https://picsum.photos/seed/${t.id}/400/600`
        }));
        return tips;
    }
    return [];
  } catch (error) {
    console.error("Lifestyle plan failed:", error);
    return [];
  }
};

// 6. Geração de Vídeo com Veo
export const generateVeoVideo = async (imageBase64: string, prompt: string): Promise<string | null> => {
  // @ts-ignore
  if (typeof window !== 'undefined' && window.aistudio) {
    // @ts-ignore
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
    }
  }

  const veoAi = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  try {
    const base64Data = imageBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

    let operation = await veoAi.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      image: {
        imageBytes: base64Data,
        mimeType: 'image/png',
      },
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '9:16'
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await veoAi.operations.getVideosOperation({operation: operation});
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (videoUri) {
      return `${videoUri}&key=${process.env.API_KEY}`;
    }
    return null;
  } catch (error) {
    console.error("Veo video generation failed:", error);
    return null;
  }
};

// 7. Sugestão de Fórmula/Combo Injetável (Compound Builder)
export const generateCompoundSuggestion = async (goal: string): Promise<Compound[]> => {
  if (!apiKey) throw new Error("API Key missing");

  const prompt = `Você é um farmacêutico especialista em injetáveis estéreis e nutrologia.
  Crie 3 opções de "Complexos/Combos Injetáveis" sinérgicos para o objetivo: ${goal}.
  
  Use ativos comuns como: L-Carnitina, HMB, BCAA, B12, Magnésio, PQQ, CoQ10, Testosterona, Nandrolona, etc.
  
  Retorne APENAS um JSON array válido.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              administration: { type: Type.STRING, enum: ["IM", "IV", "SC"] },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } },
              totalVolume: { type: Type.NUMBER },
              ingredients: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    dose: { type: Type.STRING },
                    volume: { type: Type.NUMBER }
                  },
                  required: ["name", "dose", "volume"]
                }
              }
            },
            required: ["id", "name", "description", "administration", "ingredients", "totalVolume", "tags"]
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as Compound[];
    }
    return [];
  } catch (error) {
    console.error("Compound gen failed:", error);
    return [];
  }
};
