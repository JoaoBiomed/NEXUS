
import { InventoryItem, Patient, LabResult, PresetProtocol, CompoundStockItem } from "./types";

export const MOCK_PATIENTS: Patient[] = [
  {
    id: '1',
    name: 'Carlos Mendes',
    cpf: '123.456.789-00',
    age: 42,
    gender: 'Male',
    avatar: 'https://picsum.photos/100/100?random=1',
    status: 'Active',
    lastVisit: '2023-10-15',
    nextRenewal: '2023-12-15',
    currentProtocol: 'TRT + Nandrolona (Dose Baixa)',
    photos: [
        { id: 'ph1', date: '10/06/2023', url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&q=80&w=800', category: 'Body', note: 'Início do Protocolo. BF: 22%.', weight: 88 },
        { id: 'ph2', date: '15/08/2023', url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=800', category: 'Body', note: '60 dias de TRT. Melhora visível na densidade.', weight: 84 },
        { id: 'ph3', date: '15/10/2023', url: 'https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?auto=format&fit=crop&q=80&w=800', category: 'Body', note: 'Protocolo atual. BF: 15%.', weight: 82 }
    ]
  },
  {
    id: '2',
    name: 'Juliana Silva',
    cpf: '234.567.890-11',
    age: 35,
    gender: 'Female',
    avatar: 'https://picsum.photos/100/100?random=2',
    status: 'Maintenance',
    lastVisit: '2023-09-20',
    nextRenewal: '2024-01-20',
    currentProtocol: 'Implante de Gestrinona',
    photos: [
        { id: 'ph4', date: '20/01/2023', url: 'https://images.unsplash.com/photo-1576678927484-cc907957088c?auto=format&fit=crop&q=80&w=800', category: 'Body', note: 'Pré-implante. Retenção hídrica acentuada.', weight: 65 },
        { id: 'ph5', date: '20/07/2023', url: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=800', category: 'Body', note: '6 meses de Gestrinona. Definição abdominal.', weight: 61 }
    ]
  },
  {
    id: '3',
    name: 'Roberto Alencar',
    cpf: '345.678.901-22',
    age: 50,
    gender: 'Male',
    avatar: 'https://picsum.photos/100/100?random=3',
    status: 'Critical',
    lastVisit: '2023-11-01',
    nextRenewal: '2023-11-15',
    currentProtocol: 'GH + Testosterona',
    photos: []
  }
];

export const MOCK_INVENTORY: InventoryItem[] = [
  {
    id: 'v1',
    name: 'Cipionato de Testosterona',
    concentration: '200mg/mL',
    totalVolume: 10,
    currentVolume: 2.5, // Alerta de estoque baixo
    expirationDate: '01/05/2024',
    batchNumber: 'TC-9921',
    type: 'Vial',
    category: 'Hormone',
    costPerMl: 15.00
  },
  {
    id: 'v2',
    name: 'Decanoato de Nandrolona',
    concentration: '100mg/mL',
    totalVolume: 5,
    currentVolume: 4.8,
    expirationDate: '01/01/2025',
    batchNumber: 'ND-1102',
    type: 'Vial',
    category: 'Hormone',
    costPerMl: 18.00
  },
  {
    id: 'i1',
    name: 'Implante de Gestrinona',
    concentration: '40mg',
    totalVolume: 1, // Lógica de unidade para implantes
    currentVolume: 1,
    expirationDate: '15/08/2024',
    batchNumber: 'GI-552',
    type: 'Implant',
    category: 'Hormone',
    costPerMl: 450.00 // Preço por unidade
  },
  {
    id: 'v3',
    name: 'Semaglutida',
    concentration: '2mg/1.5mL',
    totalVolume: 1.5,
    currentVolume: 0.2, // Crítico
    expirationDate: '20/12/2023',
    batchNumber: 'OZ-331',
    type: 'Vial',
    category: 'Peptide',
    costPerMl: 200.00
  },
  {
    id: 'v4',
    name: 'L-Carnitina Base',
    concentration: '600mg/mL',
    totalVolume: 50,
    currentVolume: 45,
    expirationDate: '10/10/2024',
    batchNumber: 'LC-001',
    type: 'Vial',
    category: 'Lipolytic',
    costPerMl: 5.00
  },
  {
    id: 'v5',
    name: 'PQQ Mitocondrial',
    concentration: '10mg/mL',
    totalVolume: 10,
    currentVolume: 8,
    expirationDate: '12/12/2024',
    batchNumber: 'PQ-999',
    type: 'Vial',
    category: 'Vitamin',
    costPerMl: 35.00
  },
  {
    id: 'v6',
    name: 'Ácido Tranexâmico',
    concentration: '50mg/mL',
    totalVolume: 20,
    currentVolume: 18,
    expirationDate: '15/06/2024',
    batchNumber: 'TR-551',
    type: 'Vial',
    category: 'Peptide',
    costPerMl: 12.00
  },
  {
    id: 'v7',
    name: 'Pentoxifilina',
    concentration: '20mg/mL',
    totalVolume: 30,
    currentVolume: 12,
    expirationDate: '20/08/2024',
    batchNumber: 'PT-123',
    type: 'Vial',
    category: 'Lipolytic',
    costPerMl: 8.00
  }
];

export const MOCK_LAB_RESULTS: LabResult[] = [
  { date: 'Jan/23', testosteroneTotal: 350, estradiol: 20, hematocrit: 42, dosage: 100 },
  { date: 'Mar/23', testosteroneTotal: 600, estradiol: 35, hematocrit: 44, dosage: 100 },
  { date: 'Mai/23', testosteroneTotal: 850, estradiol: 45, hematocrit: 46, dosage: 150 },
  { date: 'Jul/23', testosteroneTotal: 1100, estradiol: 55, hematocrit: 49, dosage: 150 }, // Hct subindo
  { date: 'Set/23', testosteroneTotal: 900, estradiol: 40, hematocrit: 47, dosage: 125 }, // Ajustado para baixo
];

// Protocolos Completos da Base de Dados com PREÇOS
export const PRESET_PROTOCOLS: PresetProtocol[] = [
  // --- FACIAL ---
  {
    id: 'fac-01',
    category: 'Facial',
    name: 'Antioxidante Lifting Facial (40+)',
    description: 'Trata perda de elasticidade e falta de hidratação. Ação antioxidante potente.',
    indication: 'Sinais de envelhecimento, flacidez.',
    administration: 'ID',
    ingredients: [
      { name: 'Ácido Alfa Lipóico', dose: '10mg', volume: 0.5 },
      { name: 'Lipossoma Coenzima Q10', dose: '0.5%', volume: 0.5 },
      { name: 'IDP2', dose: '1%', volume: 0.5 },
      { name: 'Ácido Hialurônico NR', dose: '0.2%', volume: 0.5 },
      { name: 'BFGF', dose: '1%', volume: 0.5 }
    ],
    averageMarketPrice: 650.00,
    estimatedCost: 120.00,
    mechanism: 'Combinação sinérgica de fatores de crescimento (BFGF, IDP2) com antioxidantes mitocondriais, promovendo neocolagênese e proteção contra ROS.',
    pros: ['Hidratação profunda imediata', 'Redução de linhas finas', 'Seguro para todos fototipos'],
    cons: ['Pode causar eritema transitório', 'Requer múltiplas sessões para efeito lifting duradouro']
  },
  {
    id: 'fac-02',
    category: 'Facial',
    name: 'Skinbooster Premium',
    description: 'Ameniza rugas de expressão, excelente preparo de pele.',
    indication: 'Hidratação profunda, preparo para bioestimulador.',
    administration: 'ID',
    ingredients: [
      { name: 'Hialuronato de Sódio', dose: '10mg/mL', volume: 1.0 },
      { name: 'Monométiltrissilanol', dose: '5mg/mL', volume: 0.5 },
      { name: 'Lipossomas Coenzima Q10', dose: '0.5%', volume: 0.5 },
      { name: 'Glucosaminoglicano', dose: '100mg', volume: 0.5 },
      { name: 'Niacinamida', dose: '2%', volume: 0.5 }
    ],
    averageMarketPrice: 800.00,
    estimatedCost: 150.00,
    mechanism: 'Atrai água para a derme profunda através do AH não reticulado, enquanto o Silício Orgânico organiza a matriz extracelular.',
    pros: ['Efeito "Glow" instantâneo', 'Melhora turgor da pele', 'Compatível com toxina botulínica'],
    cons: ['Risco de hematoma local', 'Não volumiza (apenas hidrata)']
  },
  {
    id: 'fac-03',
    category: 'Facial',
    name: 'Protocolo PDRN + Exossomas',
    description: 'Fórmula adjuvante no tratamento pro-age, clareamento e flacidez.',
    indication: 'Rejuvenescimento avançado e regeneração tecidual.',
    administration: 'ID',
    ingredients: [
      { name: 'PDRN', dose: '15mg', volume: 1.5 },
      { name: 'Exossomas', dose: '3%', volume: 1.0 },
      { name: 'Matrixyl', dose: '1%', volume: 0.5 },
      { name: 'TGF B3', dose: '1%', volume: 0.5 },
      { name: 'TGP2', dose: '1%', volume: 0.5 },
      { name: 'Niacinamida', dose: '0.3%', volume: 1.0 }
    ],
    averageMarketPrice: 1500.00,
    estimatedCost: 450.00,
    mechanism: 'PDRN atua nos receptores de adenosina promovendo reparo de DNA e angiogênese. Exossomas carreiam sinais de regeneração celular.',
    pros: ['Tecnologia regenerativa de ponta', 'Ação anti-inflamatória potente', 'Clareamento melasma resistente'],
    cons: ['Custo elevado de insumo', 'Requer armazenamento refrigerado estrito']
  },
  {
    id: 'fac-04',
    category: 'Facial',
    name: 'Mescla Papada Lipo Enzimática',
    description: 'Combate a flacidez gerada pela lipo enzimática e melhora qualidade da pele.',
    indication: 'Papada pós-procedimento lipolítico.',
    administration: 'ID',
    ingredients: [
      { name: 'BFGF', dose: '1%', volume: 0.5 },
      { name: 'TGF', dose: '1%', volume: 0.5 },
      { name: 'Hidroxiprolina + Silício', dose: '0.5%', volume: 0.5 },
      { name: 'Glucosaminoglicano', dose: '100mg', volume: 0.5 },
      { name: 'IDP2', dose: '1%', volume: 0.5 }
    ],
    averageMarketPrice: 450.00,
    estimatedCost: 80.00,
    mechanism: 'Fatores de crescimento estimulam fibroblastos a retrair a pele após o esvaziamento do compartimento de gordura.',
    pros: ['Evita o "efeito pelicano" pós-lipo', 'Melhora contorno mandibular'],
    cons: ['Não remove gordura (apenas trata flacidez)', 'Pode causar edema por 24h']
  },
  {
    id: 'fac-05',
    category: 'Facial',
    name: 'Melasma Control Plus',
    description: 'Bloqueio da tirosinase e clareamento de manchas resistentes.',
    indication: 'Melasma dérmico e hiperpigmentação pós-inflamatória.',
    administration: 'ID',
    ingredients: [
      { name: 'Ácido Tranexâmico', dose: '8mg/mL', volume: 1.0 },
      { name: 'Vitamina C', dose: '20%', volume: 0.5 },
      { name: 'Glutationa', dose: '100mg', volume: 0.5 },
      { name: 'Belides', dose: '2%', volume: 0.5 },
      { name: 'TGP-2 Peptídeo', dose: '1%', volume: 0.5 }
    ],
    averageMarketPrice: 500.00,
    estimatedCost: 90.00,
    mechanism: 'O Ácido Tranexâmico inibe a plasmina (fator vascular do melasma), enquanto Glutationa e Vitamina C neutralizam a melanogênese oxidativa.',
    pros: ['Atua no componente vascular do melasma', 'Seguro no verão', 'Ação rápida'],
    cons: ['Ardor leve na aplicação (Vit C)', 'Contraindicado em pacientes com coagulopatias ativas']
  },
  {
    id: 'fac-06',
    category: 'Facial',
    name: 'Acne Control & Oil Free',
    description: 'Regulação sebácea e efeito anti-inflamatório para pele acneica.',
    indication: 'Acne ativa grau I e II, poros dilatados.',
    administration: 'ID',
    ingredients: [
      { name: 'Sulfato de Zinco', dose: '20mg', volume: 0.5 },
      { name: 'Nicotinamida', dose: '4%', volume: 1.0 },
      { name: 'Ácido Salicílico', dose: '1%', volume: 0.5 },
      { name: 'Vitamina A', dose: '5000UI', volume: 0.5 },
      { name: 'Extrato de Hamamelis', dose: '2%', volume: 0.5 }
    ],
    averageMarketPrice: 350.00,
    estimatedCost: 50.00,
    mechanism: 'O Zinco inibe a 5-alfa-redutase na glândula sebácea. Ácido Salicílico promove queratólise suave.',
    pros: ['Secagem rápida de pústulas', 'Redução de brilho oleoso'],
    cons: ['Pode causar descamação leve', 'Não usar em gestantes (Vit A/Salicílico)']
  },

  // --- CORPORAL ---
  {
    id: 'corp-01',
    category: 'Corporal',
    name: 'Redutor Gordura Localizada Power',
    description: 'Mescla potente sem desoxicolato para gordura localizada.',
    indication: 'Gordura localizada resistente.',
    administration: 'SC',
    ingredients: [
      { name: 'Tripeptídeo', dose: '1%', volume: 2.0 },
      { name: 'Cafeína', dose: '50mg', volume: 2.0 },
      { name: 'L-Carnitina', dose: '600mg', volume: 3.0 },
      { name: 'Silício Orgânico', dose: '300mg', volume: 1.5 },
      { name: 'Procaína', dose: '2%', volume: 1.5 }
    ],
    averageMarketPrice: 300.00,
    estimatedCost: 45.00,
    mechanism: 'Cafeína inibe fosfodiesterase, aumentando AMPc e lipólise. L-Carnitina transporta ácidos graxos para oxidação.',
    pros: ['Menos inflamação que desoxicolato', 'Pode ser usado em grandes áreas'],
    cons: ['Evitar em hipertensos descontrolados (Cafeína)', 'Pode causar hematomas extensos']
  },
  {
    id: 'corp-02',
    category: 'Corporal',
    name: 'Alta Performance Harmonização Glútea',
    description: 'Pode ser feito após exercícios físicos localizados ou eletroestimulação.',
    indication: 'Volumização e firmeza glútea.',
    administration: 'SC',
    ingredients: [
      { name: 'L-Valina', dose: '8mg', volume: 1.0 },
      { name: 'L-Leucina', dose: '8mg', volume: 1.0 },
      { name: 'Isoleucina', dose: '3.4mg', volume: 1.0 },
      { name: 'Metionina', dose: '2.5mg', volume: 0.5 },
      { name: 'Hidroxiprolina + Silício', dose: '0.5%', volume: 1.0 },
      { name: 'Glucosaminoglicano', dose: '50mg', volume: 0.5 },
      { name: 'DMAE', dose: '10mg', volume: 1.0 }
    ],
    averageMarketPrice: 550.00,
    estimatedCost: 110.00,
    mechanism: 'Nutrição muscular direta com BCAA e estímulo de tensão dérmica com DMAE, melhorando o aspecto "pump".',
    pros: ['Melhora tônus visível', 'Reduz aspecto de "casca de laranja"'],
    cons: ['Requer exercício físico para efeito máximo', 'Aplicação dolorosa (pH dos aminoácidos)']
  },
  {
    id: 'corp-03',
    category: 'Corporal',
    name: 'Definição Abdominal',
    description: 'Utilizada em protocolos de alta performance, promove máxima definição.',
    indication: 'Praticantes de atividades físicas intensas.',
    administration: 'SC',
    ingredients: [
      { name: 'Arginina Alfa Cetoglutarato', dose: '75mg', volume: 1.0 },
      { name: 'L-Carnitina', dose: '150mg', volume: 1.0 },
      { name: 'L-Leucina', dose: '8mg', volume: 0.5 },
      { name: 'Isoleucina', dose: '3.4mg', volume: 0.5 },
      { name: 'Valina', dose: '8mg', volume: 0.5 },
      { name: 'Inositol', dose: '100mg', volume: 1.0 },
      { name: 'Ornitina', dose: '100mg', volume: 0.5 }
    ],
    averageMarketPrice: 280.00,
    estimatedCost: 55.00,
    mechanism: 'Aumenta vasodilatação local e oxidação lipídica subcutânea, revelando a musculatura subjacente.',
    pros: ['Ideal para "finalização" pré-verão', 'Melhora vascularização'],
    cons: ['Não funciona em percentual de gordura alto (>20%)']
  },
  {
    id: 'corp-04',
    category: 'Corporal',
    name: 'Celulite Off (Grau I e II)',
    description: 'Melhora da microcirculação e drenagem linfática local.',
    indication: 'Celulite edematosa e fibrosa leve.',
    administration: 'SC',
    ingredients: [
      { name: 'Pentoxifilina', dose: '20mg', volume: 2.0 },
      { name: 'Benzopirona', dose: '5mg', volume: 2.0 },
      { name: 'Cafeína', dose: '50mg', volume: 1.0 },
      { name: 'L-Carnitina', dose: '300mg', volume: 2.0 },
      { name: 'Rutina', dose: '5mg', volume: 1.0 }
    ],
    averageMarketPrice: 320.00,
    estimatedCost: 40.00,
    mechanism: 'Pentoxifilina melhora a reologia sanguínea. Benzopirona reduz edema intersticial. Rutina fortalece capilares.',
    pros: ['Alívio de pernas cansadas', 'Visível melhora da textura'],
    cons: ['Risco de equimoses (vasodilatação)', 'Pode causar rubor intenso']
  },
  {
    id: 'corp-05',
    category: 'Corporal',
    name: 'Firmador Corporal (Flacidez)',
    description: 'Estímulo de colágeno e tensão dérmica para áreas flácidas.',
    indication: 'Pós-emagrecimento, pós-gestação (braços, interno de coxa).',
    administration: 'SC',
    ingredients: [
      { name: 'DMAE', dose: '6%', volume: 2.0 },
      { name: 'Silício Orgânico', dose: '10mg', volume: 2.0 },
      { name: 'Vitamina C', dose: '10%', volume: 1.0 },
      { name: 'Cobre Coloidal', dose: '2mg', volume: 1.0 },
      { name: 'Piruato de Sódio', dose: '1%', volume: 1.0 }
    ],
    averageMarketPrice: 400.00,
    estimatedCost: 75.00,
    mechanism: 'DMAE aumenta a contração de miofibroblastos. Silício e Cobre são cofatores essenciais para síntese de elastina.',
    pros: ['Excelente para "umbigo triste"', 'Pode ser usado em papada'],
    cons: ['Ardor moderado na aplicação', 'Requer manutenção mensal']
  },

  // --- CAPILAR ---
  {
    id: 'cap-01',
    category: 'Capilar',
    name: 'Alopecia Androgenética Masculina',
    description: 'Inibe 5 alfa redutase, melhora circulação, nutre o folículo.',
    indication: 'Queda de cabelo padrão masculino.',
    administration: 'ID',
    ingredients: [
      { name: 'D-Pantenol', dose: '2%', volume: 1.0 },
      { name: 'Finasterida', dose: '0.05%', volume: 1.0 },
      { name: 'Minoxidil', dose: '0.5%', volume: 1.0 },
      { name: 'Biotina', dose: '0.05%', volume: 1.0 }
    ],
    averageMarketPrice: 350.00,
    estimatedCost: 60.00,
    mechanism: 'Finasterida local bloqueia DHT sem efeitos sistêmicos. Minoxidil prolonga fase anágena.',
    pros: ['Baixo risco de colaterais sexuais', 'Interrompe a queda em 3-4 sessões'],
    cons: ['Não recupera folículos mortos', 'Queda temporária (shedding) no início']
  },
  {
    id: 'cap-02',
    category: 'Capilar',
    name: 'Crescimento e Barba (Booster)',
    description: 'Acelera o crescimento, reverte atrofia folicular.',
    indication: 'Falhas na barba ou alopecia difusa.',
    administration: 'ID',
    ingredients: [
      { name: 'IGF', dose: '1%', volume: 0.5 },
      { name: 'bFGF', dose: '1%', volume: 0.5 },
      { name: 'VEGF', dose: '1%', volume: 0.5 },
      { name: 'Copper Peptídeo', dose: '1%', volume: 0.5 }
    ],
    averageMarketPrice: 450.00,
    estimatedCost: 85.00,
    mechanism: 'Fatores de crescimento (IGF, VEGF) estimulam a angiogênese e mitose no bulbo capilar.',
    pros: ['Preenchimento rápido de falhas', 'Engrossa o fio existente'],
    cons: ['Custo elevado', 'Pode causar foliculite se não higienizar bem']
  },
  {
    id: 'cap-03',
    category: 'Capilar',
    name: 'Feminino Fortalecedor (Queda Telógena)',
    description: 'Nutrição intensa para eflúvio telógeno e pós-covid.',
    indication: 'Queda difusa em mulheres, fios finos.',
    administration: 'ID',
    ingredients: [
      { name: 'Vitamina B6', dose: '10mg', volume: 1.0 },
      { name: 'Biotina', dose: '5mg', volume: 1.0 },
      { name: 'Pill Food Mix', dose: 'Complex', volume: 1.0 },
      { name: 'Silício', dose: '10mg', volume: 1.0 },
      { name: 'L-Cistina', dose: '20mg', volume: 1.0 }
    ],
    averageMarketPrice: 380.00,
    estimatedCost: 70.00,
    mechanism: 'Fornecimento direto de substratos de queratina (Cistina, Biotina) para o fio em formação.',
    pros: ['Melhora brilho e textura', 'Reduz quebra capilar'],
    cons: ['Aplicação dolorosa no couro cabeludo', 'Necessita múltiplas sessões']
  },

  // --- IM / IV / Outros ---
  {
    id: 'im-01',
    category: 'IM',
    name: 'Acelerador de Metabolismo',
    description: 'Inibe o apetite, ativa o metabolismo. Aplicação 1-2x por semana.',
    indication: 'Estagnação de peso, metabolismo lento.',
    administration: 'IM',
    ingredients: [
      { name: 'L-Carnitina', dose: '600mg', volume: 2.0 },
      { name: 'L-Ornitina', dose: '300mg', volume: 1.0 },
      { name: 'L-Arginina', dose: '300mg', volume: 1.0 },
      { name: 'L-Fenilalanina', dose: '50mg', volume: 0.5 }
    ],
    averageMarketPrice: 200.00,
    estimatedCost: 35.00,
    mechanism: 'Aumento da beta-oxidação mitocondrial e estímulo leve da tireoide.',
    pros: ['Energia extra para treino', 'Redução de gordura visceral'],
    cons: ['Pode causar insônia se aplicado à noite', 'Contraindicado em fenilcetonúricos']
  },
  // ... outros mantêm estrutura similar (simplificado para brevidade, mas o padrão prossegue)
  {
    id: 'im-04',
    category: 'IM',
    name: 'Hipertrofia Max (Ganho de Massa)',
    description: 'Pool de aminoácidos essenciais para síntese proteica.',
    indication: 'Atletas e sarcopenia em idosos.',
    administration: 'IM',
    ingredients: [
      { name: 'HMB', dose: '100mg', volume: 2.0 },
      { name: 'BCAA Injetável', dose: '10%', volume: 2.0 },
      { name: 'L-Leucina', dose: '20mg', volume: 1.0 },
      { name: 'Magnésio', dose: '200mg', volume: 1.0 }
    ],
    averageMarketPrice: 250.00,
    estimatedCost: 50.00,
    mechanism: 'HMB anticatabólico previne degradação muscular pós-treino, BCAA estimula via mTOR.',
    pros: ['Recuperação muscular acelerada', 'Preserva massa magra em cutting'],
    cons: ['Volume de injeção alto (6mL)', 'Requer músculo profundo (glúteo)']
  },
  {
    id: 'soro-01',
    category: 'Soro',
    name: 'Soro da Beleza (Glow)',
    description: 'Complexo para pele, cabelo e unhas via endovenosa.',
    indication: 'Revitalização sistêmica.',
    administration: 'IV',
    ingredients: [
      { name: 'Vitamina C 20%', dose: '20%', volume: 5.0 },
      { name: 'Complexo B sem B1', dose: '2mL', volume: 2.0 },
      { name: 'Vitamina B3', dose: '5mg/mL', volume: 2.0 },
      { name: 'Vitamina B5', dose: '25mg/mL', volume: 2.0 },
      { name: 'Cloreto de Magnésio', dose: '400mg', volume: 2.0 },
      { name: 'Sulfato de Zinco', dose: '10mg', volume: 2.0 }
    ],
    averageMarketPrice: 450.00,
    estimatedCost: 100.00,
    mechanism: 'Hidratação sistêmica e saturação de cofatores enzimáticos para pele.',
    pros: ['Efeito sistêmico (corpo todo)', 'Absorção 100% (biodisponibilidade)'],
    cons: ['Tempo de infusão (30-40 min)', 'Requer acesso venoso']
  }
];

// INTEGRATED STOCK: Mirrors the Protocols with FINANCIALS
export const MOCK_COMPOUND_STOCK: CompoundStockItem[] = [
  // Facial
  { id: 'stk-fac-01', name: 'Antioxidante Lifting Facial (40+)', description: 'Kit estéril para aplicação ID.', quantity: 0, unitVolume: 2.5, category: 'Facial', status: 'Production', batchDate: '-', costPrice: 120, sellingPrice: 650 },
  { id: 'stk-fac-02', name: 'Skinbooster Premium', description: 'Caixa c/ 5 ampolas prontas.', quantity: 8, unitVolume: 3, category: 'Facial', status: 'Ready', batchDate: '20/10/2023', costPrice: 150, sellingPrice: 800 },
  { id: 'stk-fac-03', name: 'Protocolo PDRN + Exossomas', description: 'Kit avançado refrigerado.', quantity: 2, unitVolume: 5, category: 'Facial', status: 'Low Stock', batchDate: '01/11/2023', costPrice: 450, sellingPrice: 1500 },
  { id: 'stk-fac-04', name: 'Mescla Papada Lipo Enzimática', description: 'Frasco ampola multidose.', quantity: 12, unitVolume: 10, category: 'Facial', status: 'Ready', batchDate: '15/10/2023', costPrice: 80, sellingPrice: 450 },
  { id: 'stk-fac-05', name: 'Melasma Control Plus', description: 'Kit clareador intensivo.', quantity: 5, unitVolume: 4, category: 'Facial', status: 'Ready', batchDate: '05/11/2023', costPrice: 90, sellingPrice: 500 },
  { id: 'stk-fac-06', name: 'Acne Control & Oil Free', description: 'Mescla antisseborreica.', quantity: 0, unitVolume: 3, category: 'Facial', status: 'Production', batchDate: '-', costPrice: 50, sellingPrice: 350 },

  // Corporal
  { id: 'stk-corp-01', name: 'Redutor Gordura Localizada Power', description: 'Lipolítico potente.', quantity: 20, unitVolume: 10, category: 'Corporal', status: 'Ready', batchDate: '10/11/2023', costPrice: 45, sellingPrice: 300 },
  { id: 'stk-corp-02', name: 'Harmonização Glútea', description: 'Volumizador muscular.', quantity: 4, unitVolume: 10, category: 'Corporal', status: 'Low Stock', batchDate: '12/10/2023', costPrice: 110, sellingPrice: 550 },
  { id: 'stk-corp-03', name: 'Definição Abdominal', description: 'Protocolo six-pack.', quantity: 0, unitVolume: 5, category: 'Corporal', status: 'Production', batchDate: '-', costPrice: 55, sellingPrice: 280 },
  { id: 'stk-corp-04', name: 'Celulite Off (Drenante)', description: 'Anticelulite grau I/II.', quantity: 15, unitVolume: 8, category: 'Corporal', status: 'Ready', batchDate: '25/10/2023', costPrice: 40, sellingPrice: 320 },
  { id: 'stk-corp-05', name: 'Firmador Corporal (Flacidez)', description: 'Skin tightening mix.', quantity: 3, unitVolume: 10, category: 'Corporal', status: 'Low Stock', batchDate: '20/09/2023', costPrice: 75, sellingPrice: 400 },

  // Capilar
  { id: 'stk-cap-01', name: 'Alopecia Androgenética Masc.', description: 'Bloqueio DHT tópico/ID.', quantity: 10, unitVolume: 5, category: 'Capilar', status: 'Ready', batchDate: '01/11/2023', costPrice: 60, sellingPrice: 350 },
  { id: 'stk-cap-02', name: 'Crescimento e Barba', description: 'Fatores de crescimento.', quantity: 0, unitVolume: 5, category: 'Capilar', status: 'Production', batchDate: '-', costPrice: 85, sellingPrice: 450 },
  { id: 'stk-cap-03', name: 'Feminino Fortalecedor', description: 'Nutrição capilar intensa.', quantity: 8, unitVolume: 5, category: 'Capilar', status: 'Ready', batchDate: '05/11/2023', costPrice: 70, sellingPrice: 380 },

  // IM
  { id: 'stk-im-01', name: 'Acelerador de Metabolismo', description: 'Termogênico injetável.', quantity: 25, unitVolume: 5, category: 'IM', status: 'Ready', batchDate: '15/11/2023', costPrice: 35, sellingPrice: 200 },
  { id: 'stk-im-02', name: 'Emagrecimento (Compulsão)', description: 'Controle de ansiedade/doce.', quantity: 5, unitVolume: 5, category: 'IM', status: 'Low Stock', batchDate: '10/10/2023', costPrice: 40, sellingPrice: 220 },
  { id: 'stk-im-03', name: 'Longevidade / Anti-Aging', description: 'Pool de antioxidantes.', quantity: 0, unitVolume: 4, category: 'IM', status: 'Production', batchDate: '-', costPrice: 80, sellingPrice: 350 },
  { id: 'stk-im-04', name: 'Hipertrofia Max', description: 'Aminoácidos essenciais.', quantity: 30, unitVolume: 10, category: 'IM', status: 'Ready', batchDate: '20/11/2023', costPrice: 50, sellingPrice: 250 },
  { id: 'stk-im-05', name: 'Ansiedade e Stress Control', description: 'Relaxante muscular/mental.', quantity: 10, unitVolume: 5, category: 'IM', status: 'Ready', batchDate: '01/11/2023', costPrice: 60, sellingPrice: 280 },

  // Soro
  { id: 'stk-soro-01', name: 'Soro da Beleza (Glow)', description: 'Bolsa pronta para infusão.', quantity: 2, unitVolume: 250, category: 'Soro', status: 'Low Stock', batchDate: '28/10/2023', costPrice: 100, sellingPrice: 450 },
  { id: 'stk-soro-02', name: 'Booster Mitocondrial', description: 'Kit de aditivos para soro.', quantity: 5, unitVolume: 20, category: 'Soro', status: 'Ready', batchDate: '15/11/2023', costPrice: 140, sellingPrice: 550 },
  { id: 'stk-soro-03', name: 'Imunidade Blindada', description: 'Alta dose de Vit C e Zinco.', quantity: 10, unitVolume: 100, category: 'Soro', status: 'Ready', batchDate: '01/11/2023', costPrice: 110, sellingPrice: 480 },
  { id: 'stk-soro-04', name: 'Detox Hepático', description: 'Recuperação pós-ciclo.', quantity: 0, unitVolume: 250, category: 'Soro', status: 'Production', batchDate: '-', costPrice: 120, sellingPrice: 500 }
];