

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female';
  avatar: string; // URL
  status: 'Active' | 'Maintenance' | 'Critical';
  lastVisit: string;
  nextRenewal: string;
  currentProtocol: string;
  cpf?: string; // Adicionado para busca
  photos?: PhotoRecord[]; // Novo: Histórico Fotográfico
}

export interface PhotoRecord {
  id: string;
  date: string;
  url: string;
  category: 'Face' | 'Body' | 'Hair';
  note: string;
  weight?: number; // kg no momento da foto
}

export interface LabResult {
  date: string;
  testosteroneTotal: number; // ng/dL
  estradiol: number; // pg/mL
  hematocrit: number; // %
  dosage: number; // mg/week
}

// Novos Tipos para Integração Avançada
export interface GeneticProfile {
  metabolism: 'Fast' | 'Slow' | 'Normal';
  aromatizationRisk: 'High' | 'Low';
  shbgAffinity: 'High' | 'Low';
  oxidativeStress: 'High' | 'Low' | 'Medium';
  polymorphisms: string[]; // ex: ['CYP19A1', 'COMT']
}

export interface LabProReport {
  lastExamDate: string;
  liverFunction: 'Normal' | 'Stressed';
  lipidProfile: 'Optimal' | 'Dyslipidemia';
  kidneyFunction: 'Normal' | 'Warning';
  hormonalStatus: {
    testoTotal: number;
    freeTesto: number;
    estradiol: number;
    shbg: number;
  }
}

export interface InventoryItem {
  id: string;
  name: string;
  concentration: string; // e.g., 200mg/mL
  totalVolume: number; // mL
  currentVolume: number; // mL
  expirationDate: string;
  batchNumber: string;
  type: 'Vial' | 'Implant' | 'Oral';
  category?: 'Hormone' | 'Peptide' | 'Vitamin' | 'Aminoacid' | 'Lipolytic';
  costPerMl: number; // Custo por mL para cálculo de fórmula
  clinicalTags?: string[]; // Hashtags para filtragem clínica (ex: #Hipertrofia, #Lipolitico)
}

export interface CompoundStockItem {
  id: string;
  name: string;
  description: string;
  quantity: number; // Unidades (Kits/Frascos prontos)
  unitVolume: number; // Volume por unidade
  category: 'Facial' | 'Corporal' | 'Capilar' | 'IM' | 'Soro';
  status: 'Ready' | 'Low Stock' | 'Production';
  batchDate: string;
  costPrice: number; // Custo de produção do kit
  sellingPrice: number; // Preço de venda praticado
  clinicalTags?: string[]; // Hashtags para filtragem clínica
}

export interface CompoundIngredient {
  name: string;
  dose: string;
  volume: number; // mL
}

export interface Compound {
  id: string;
  name: string; // e.g. "Lipo Burn Ultimate"
  description: string;
  ingredients: CompoundIngredient[];
  totalVolume: number;
  administration: 'IM' | 'IV' | 'SC' | 'ID';
  tags: string[];
}

export interface PresetProtocol {
  id: string;
  category: 'Facial' | 'Corporal' | 'Capilar' | 'IM' | 'Soro' | 'Outros';
  name: string;
  description: string;
  indication: string;
  administration: 'IM' | 'IV' | 'SC' | 'ID'; // ID = Intradérmica
  ingredients: CompoundIngredient[];
  averageMarketPrice: number; // Preço médio de mercado (Sugestão)
  estimatedCost: number; // Custo estimado de insumos
  mechanism: string; // Explicação científica
  pros: string[]; // Pontos positivos
  cons: string[]; // Pontos negativos/atenção
}

export interface ProtocolRequest {
  patientWeight: number; // kg
  patientHeight: number; // cm
  gender: 'Male' | 'Female';
  goal: 'Hypertrophy' | 'Weight Loss' | 'HRT' | 'Libido';
  medicalHistory: string;
  // Novos campos opcionais para a IA avançada
  patientName?: string;
  genetics?: GeneticProfile;
  labs?: LabProReport;
}

export interface LifestyleTip {
  id: string;
  title: string;
  description: string;
  category: 'Nutrition' | 'Sleep' | 'Mental';
  imageUrl: string;
  videoUrl?: string;
}

export interface Appointment {
  id: string;
  patientName: string;
  date: Date; // Object Date para facilitar manipulação
  type: 'Consultation' | 'Injection' | 'Implant' | 'FollowUp';
  status: 'Confirmed' | 'Pending' | 'Cancelled';
  notes?: string;
}

export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  PATIENTS = 'PATIENTS',
  INVENTORY = 'INVENTORY',
  PROTOCOL_AI = 'PROTOCOL_AI',
  CALENDAR = 'CALENDAR',
  COMPOUNDS = 'COMPOUNDS',
  IMEDDIS = 'IMEDDIS',
}