
import React from 'react';
import { HashRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import InventoryManager from './components/InventoryManager';
import ProtocolAssistant from './components/ProtocolAssistant';
import PatientDetail from './components/PatientDetail';
import CalendarView from './components/CalendarView';
import CompoundBuilder from './components/CompoundBuilder';
import IMeddisIntegration from './components/IMeddisIntegration';
import LabProIntegration from './components/LabProIntegration';
import PlansView from './components/PlansView';

function AppContent() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen bg-transparent">
      <Sidebar />
      <main className="flex-1 ml-72 p-8 overflow-x-hidden relative z-10 transition-colors duration-300">
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route 
            path="/dashboard" 
            element={
              <div className="animate-fade-in">
                <Dashboard />
              </div>
            } 
          />
          <Route 
            path="/calendar" 
            element={
              <div className="animate-fade-in">
                <CalendarView />
              </div>
            } 
          />
          <Route 
            path="/patients" 
            element={
              <div className="animate-fade-in">
                <PatientDetail />
              </div>
            } 
          />
          <Route 
            path="/inventory" 
            element={
              <div className="animate-fade-in">
                <InventoryManager />
              </div>
            } 
          />
          <Route 
            path="/compounds" 
            element={
              <div className="animate-fade-in">
                <CompoundBuilder />
              </div>
            } 
          />
          <Route 
            path="/protocol" 
            element={
              <div className="animate-fade-in">
                <ProtocolAssistant />
              </div>
            } 
          />
           <Route 
            path="/imeddis" 
            element={
              <div className="animate-fade-in">
                <IMeddisIntegration />
              </div>
            } 
          />
          <Route 
            path="/labpro" 
            element={
              <div className="animate-fade-in">
                <LabProIntegration />
              </div>
            } 
          />
          <Route 
            path="/plans" 
            element={
              <div className="animate-fade-in">
                <PlansView />
              </div>
            } 
          />
        </Routes>
      </main>
      
      {/* Global AI Floating Action Button - Glass Style */}
      <button 
        onClick={() => navigate('/protocol')}
        className="fixed bottom-8 right-8 w-16 h-16 bg-clinical-900/90 dark:bg-clinical-600/90 backdrop-blur-md text-white rounded-full shadow-[0_0_20px_rgba(37,99,235,0.5)] flex items-center justify-center hover:scale-110 transition-transform z-50 border border-white/20 group"
        title="Assistente IA Rápido"
      >
        <div className="absolute inset-0 bg-clinical-500 rounded-full animate-ping opacity-20"></div>
        <i className="fa-solid fa-robot text-2xl group-hover:rotate-12 transition-transform"></i>
      </button>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <HashRouter>
        <AppContent />
      </HashRouter>
    </ThemeProvider>
  );
}

export default App;
