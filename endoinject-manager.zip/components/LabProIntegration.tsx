import React, { useState } from 'react';
import { MOCK_PATIENTS } from '../constants';
import { Patient } from '../types';

interface LabProPanel {
    name: string;
    markers: {
        name: string;
        value: number;
        unit: string;
        min: number;
        max: number;
        alert: boolean;
    }[];
}

const LabProIntegration: React.FC = () => {
    const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
    const [status, setStatus] = useState<'IDLE' | 'CONNECTING' | 'SYNCING' | 'READY'>('IDLE');
    const [labData, setLabData] = useState<LabProPanel[] | null>(null);

    const selectedPatient = MOCK_PATIENTS.find(p => p.id === selectedPatientId);

    const handlePatientSelect = (id: string) => {
        setSelectedPatientId(id);
        setStatus('IDLE');
        setLabData(null);
    };

    const handleSyncLabs = () => {
        if (!selectedPatient) return;
        setStatus('CONNECTING');

        // Step 1: Connecting
        setTimeout(() => {
            setStatus('SYNCING');
        }, 1500);

        // Step 2: Syncing Data (Simulated)
        setTimeout(() => {
            const isMale = selectedPatient.gender === 'Male';
            const mockData: LabProPanel[] = [
                {
                    name: 'Painel Hormonal',
                    markers: [
                        { name: 'Testosterona Total', value: isMale ? 850 : 45, unit: 'ng/dL', min: isMale ? 300 : 15, max: isMale ? 900 : 60, alert: false },
                        { name: 'Estradiol (E2)', value: isMale ? 55 : 120, unit: 'pg/mL', min: isMale ? 10 : 30, max: isMale ? 40 : 400, alert: isMale }, // Alert if male high
                        { name: 'SHBG', value: 25, unit: 'nmol/L', min: 10, max: 57, alert: false },
                    ]
                },
                {
                    name: 'Função Hepática & Renal',
                    markers: [
                        { name: 'TGO (AST)', value: 38, unit: 'U/L', min: 0, max: 40, alert: false },
                        { name: 'TGP (ALT)', value: 52, unit: 'U/L', min: 0, max: 41, alert: true }, // Alert
                        { name: 'Creatinina', value: 1.1, unit: 'mg/dL', min: 0.7, max: 1.3, alert: false },
                    ]
                },
                {
                    name: 'Hematologia',
                    markers: [
                        { name: 'Hematócrito', value: 51, unit: '%', min: 38, max: 50, alert: true }, // Alert
                        { name: 'Hemoglobina', value: 16.5, unit: 'g/dL', min: 13, max: 17, alert: false },
                    ]
                }
            ];
            setLabData(mockData);
            setStatus('READY');
        }, 3500);
    };

    // Helper to render range bar (High Precision Visuals)
    const renderRangeBar = (value: number, min: number, max: number, alert: boolean) => {
        const range = max - min;
        // Normalize position (0 to 100%)
        let percent = ((value - min) / range) * 100;
        // Clamp for visual
        if (percent < 0) percent = 0;
        if (percent > 100) percent = 100;

        return (
            <div className="relative w-full h-3 bg-slate-100 rounded-full mt-2 overflow-hidden shadow-inner border border-slate-200/60">
                {/* Safe Zone Marker (Gradient for better aesthetic) */}
                <div className="absolute left-0 top-0 h-full w-full bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200"></div>
                
                {/* Value Marker */}
                <div 
                    className={`absolute top-0 h-full w-1.5 rounded-full transition-all duration-1000 z-10 ${alert ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)] scale-y-125' : 'bg-indigo-600 shadow-[0_0_8px_rgba(79,70,229,0.5)]'}`}
                    style={{ left: `${percent}%`, transform: 'translateX(-50%)' }}
                ></div>

                {/* Min/Max Ticks */}
                <div className="absolute top-0 left-0 w-px h-full bg-slate-300 opacity-50"></div>
                <div className="absolute top-0 right-0 w-px h-full bg-slate-300 opacity-50"></div>
            </div>
        );
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-fade-in pb-12">
             {/* LABPRO HEADER - PREMIUM VISUAL */}
            <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-indigo-900/20 bg-slate-900 min-h-[320px] flex flex-col items-center justify-center text-center p-8 border border-slate-800">
                {/* Advanced Background System */}
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                    <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-indigo-600/20 rounded-full blur-[100px] animate-pulse-slow"></div>
                    <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px]"></div>
                    {/* Medical Grid Pattern */}
                    <div className="absolute inset-0" style={{backgroundImage: 'radial-gradient(rgba(99, 102, 241, 0.15) 1px, transparent 1px)', backgroundSize: '30px 30px'}}></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
                </div>

                <div className="relative z-10 space-y-6">
                    <div className="inline-flex items-center space-x-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-5 py-2 shadow-lg">
                        <div className="relative flex h-2.5 w-2.5">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
                        </div>
                        <span className="text-[11px] font-black uppercase tracking-[0.2em] text-indigo-100">LabPro Server: Online</span>
                    </div>
                    
                    <div>
                        <h1 className="text-5xl md:text-6xl font-black text-white tracking-tighter drop-shadow-lg">
                            LAB<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-blue-400">PRO</span> CONNECT
                        </h1>
                        <p className="text-slate-400 font-medium max-w-2xl mx-auto text-lg mt-4 leading-relaxed">
                            Integração de <span className="text-indigo-300 font-bold">Análises Clínicas</span> em Tempo Real. 
                            <br/>Sincronização LIMS, Hematologia e Bioquímica.
                        </p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 -mt-20 relative z-20 px-4 md:px-0">
                {/* LEFT: Patient Selector */}
                <div className="lg:col-span-4 flex flex-col space-y-4">
                    <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-soft-xl border border-white/40 p-6 flex-1">
                        <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center pl-1">
                            <i className="fa-solid fa-users-viewfinder mr-2.5 text-indigo-500"></i> Seleção de Paciente (LIMS)
                        </h3>
                        
                        <div className="space-y-3 max-h-[450px] overflow-y-auto custom-scrollbar pr-2">
                            {MOCK_PATIENTS.map(p => (
                                <button
                                    key={p.id}
                                    onClick={() => handlePatientSelect(p.id)}
                                    className={`w-full flex items-center p-3.5 rounded-2xl border transition-all duration-300 group relative overflow-hidden ${
                                        selectedPatientId === p.id 
                                        ? 'bg-slate-900 border-slate-900 shadow-xl scale-[1.02] z-10' 
                                        : 'bg-white border-slate-100 hover:border-indigo-200 hover:shadow-md'
                                    }`}
                                >
                                    <div className="relative">
                                        <img src={p.avatar} className={`w-12 h-12 rounded-xl object-cover ring-2 transition-all ${selectedPatientId === p.id ? 'ring-indigo-400' : 'ring-slate-100'}`} alt={p.name} />
                                        {selectedPatientId === p.id && <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-indigo-500 border-2 border-slate-900 rounded-full"></div>}
                                    </div>
                                    <div className="ml-4 text-left">
                                        <p className={`font-bold text-sm ${selectedPatientId === p.id ? 'text-white' : 'text-slate-800 group-hover:text-slate-900'}`}>{p.name}</p>
                                        <p className={`text-[10px] font-bold uppercase tracking-wide mt-0.5 ${selectedPatientId === p.id ? 'text-indigo-300' : 'text-slate-400'}`}>ID: {p.id.padStart(6, '0')}</p>
                                    </div>
                                    {selectedPatientId === p.id && (
                                        <div className="absolute right-5 text-indigo-400 animate-pulse">
                                            <i className="fa-solid fa-wifi text-sm"></i>
                                        </div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                {/* RIGHT: Lab Data Visualizer */}
                <div className="lg:col-span-8">
                     <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-soft-xl border border-white/40 p-8 min-h-[450px] flex flex-col relative overflow-hidden transition-all duration-500">
                        
                        {status === 'IDLE' && (
                            <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 animate-fade-in">
                                <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center border border-slate-100 shadow-inner">
                                    <i className="fa-solid fa-flask-vial text-5xl text-slate-300"></i>
                                </div>
                                <div>
                                    <h3 className="text-lg font-bold text-slate-900">Aguardando Sincronização</h3>
                                    <p className="text-slate-500 font-medium text-sm mt-1">Selecione um paciente para importar o histórico.</p>
                                </div>
                                {selectedPatient && (
                                    <button 
                                        onClick={handleSyncLabs}
                                        className="px-8 py-3.5 bg-slate-900 text-white font-bold rounded-2xl shadow-xl hover:bg-slate-800 hover:scale-105 transition-all animate-fade-in flex items-center group"
                                    >
                                        <i className="fa-solid fa-cloud-arrow-down mr-2 group-hover:animate-bounce"></i>
                                        Baixar Análises Clínicas
                                    </button>
                                )}
                            </div>
                        )}

                        {(status === 'CONNECTING' || status === 'SYNCING') && (
                            <div className="flex-1 flex flex-col items-center justify-center space-y-8 animate-fade-in">
                                <div className="relative w-28 h-28">
                                    <div className="absolute inset-0 border-4 border-slate-100 rounded-full"></div>
                                    <div className="absolute inset-0 border-4 border-t-indigo-600 rounded-full animate-spin"></div>
                                    <div className="absolute inset-0 flex items-center justify-center text-indigo-600">
                                        <i className="fa-solid fa-server text-3xl"></i>
                                    </div>
                                </div>
                                <div className="text-center">
                                    <h3 className="text-2xl font-black text-slate-900">{status === 'CONNECTING' ? 'Conectando ao Servidor...' : 'Baixando Resultados...'}</h3>
                                    <p className="text-sm text-slate-500 font-mono mt-2 bg-slate-100 px-3 py-1 rounded-lg inline-block">Secure TLS 1.3 Handshake</p>
                                </div>
                                {/* Simulated Terminal Output */}
                                <div className="bg-slate-900 text-indigo-300 font-mono text-[10px] p-5 rounded-2xl w-full max-w-md text-left overflow-hidden shadow-2xl border border-slate-800">
                                    <p>> Initiating request sequence...</p>
                                    <p className="opacity-80 mt-1">> Auth token verified [OK].</p>
                                    {status === 'SYNCING' && (
                                        <>
                                            <p className="opacity-80 mt-1">> Fetching HL7 clinical records...</p>
                                            <p className="opacity-80 mt-1">> Parsing biochemistry data...</p>
                                            <p className="animate-pulse text-emerald-400 mt-1">> Decrypting patient metrics...</p>
                                        </>
                                    )}
                                </div>
                            </div>
                        )}

                        {status === 'READY' && labData && (
                            <div className="space-y-8 animate-fade-in">
                                <div className="flex justify-between items-center border-b border-slate-100 pb-6">
                                    <div className="flex items-center space-x-4">
                                        <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100 shadow-sm">
                                            <i className="fa-solid fa-file-medical-alt text-xl"></i>
                                        </div>
                                        <div>
                                            <h3 className="font-black text-slate-900 text-lg">Resultados Consolidados</h3>
                                            <p className="text-xs text-slate-500 font-bold uppercase tracking-wide">Ref: Última Coleta</p>
                                        </div>
                                    </div>
                                    <button onClick={handleSyncLabs} className="text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-4 py-2 rounded-xl transition-all border border-indigo-100">
                                        <i className="fa-solid fa-rotate mr-2"></i> Atualizar
                                    </button>
                                </div>

                                <div className="grid grid-cols-1 gap-6">
                                    {labData.map((panel, idx) => (
                                        <div key={idx} className="bg-white/60 rounded-3xl border border-slate-200 shadow-sm p-6 hover:border-indigo-300 hover:shadow-md transition-all group">
                                            <h4 className="text-xs font-black text-slate-600 uppercase tracking-widest mb-6 border-l-4 border-indigo-500 pl-3 flex items-center">
                                                {panel.name}
                                                <div className="flex-1 h-px bg-slate-100 ml-4"></div>
                                            </h4>
                                            
                                            <div className="space-y-6">
                                                {panel.markers.map((marker, mIdx) => (
                                                    <div key={mIdx} className="grid grid-cols-12 gap-4 items-center group/marker">
                                                        <div className="col-span-12 sm:col-span-4">
                                                            <p className="font-extrabold text-slate-800 text-sm group-hover/marker:text-indigo-700 transition-colors">{marker.name}</p>
                                                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Ref: {marker.min} - {marker.max}</p>
                                                        </div>
                                                        <div className="col-span-3 sm:col-span-2 text-right sm:text-left">
                                                            <div className="flex items-baseline justify-end sm:justify-start">
                                                                <span className={`text-lg font-black ${marker.alert ? 'text-red-600' : 'text-slate-900'}`}>
                                                                    {marker.value}
                                                                </span>
                                                                <span className="text-[10px] text-slate-500 font-bold ml-1">{marker.unit}</span>
                                                            </div>
                                                        </div>
                                                        <div className="col-span-9 sm:col-span-5">
                                                            {renderRangeBar(marker.value, marker.min, marker.max, marker.alert)}
                                                        </div>
                                                        <div className="col-span-12 sm:col-span-1 flex justify-end">
                                                            {marker.alert ? (
                                                                <div className="bg-red-50 text-red-600 px-2 py-1 rounded-lg border border-red-100 flex items-center shadow-sm">
                                                                    <i className="fa-solid fa-triangle-exclamation text-xs"></i>
                                                                </div>
                                                            ) : (
                                                                <div className="text-emerald-500 opacity-20 group-hover/marker:opacity-100 transition-opacity">
                                                                    <i className="fa-solid fa-check text-lg"></i>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-2xl p-5 flex items-start space-x-4 border border-indigo-100 shadow-sm">
                                    <div className="w-8 h-8 rounded-full bg-white text-indigo-600 flex items-center justify-center flex-shrink-0 shadow-sm border border-indigo-100">
                                        <i className="fa-solid fa-wand-magic-sparkles text-sm"></i>
                                    </div>
                                    <div>
                                        <h4 className="text-xs font-black text-indigo-900 uppercase tracking-wide">Interpretação LabPro AI</h4>
                                        <p className="text-sm text-indigo-800 mt-1 leading-relaxed font-medium">
                                            Os níveis elevados de <span className="font-bold border-b border-indigo-300">TGP</span> e <span className="font-bold border-b border-indigo-300">Hematócrito</span> sugerem sobrecarga hepática leve e eritrocitose secundária ao uso de andrógenos. Recomenda-se protocolo de proteção hepática e avaliação para sangria terapêutica.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                     </div>
                </div>
            </div>
        </div>
    );
};

export default LabProIntegration;