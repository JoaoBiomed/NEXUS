
import React, { useState } from 'react';

const PlansView: React.FC = () => {
  const [billingCycle, setBillingCycle] = useState<'MONTHLY' | 'YEARLY'>('MONTHLY');

  const plans = [
    {
      id: 'clinical',
      name: 'EndoInject Clinical',
      description: 'A base sólida para gestão de consultórios e prontuários.',
      price: { monthly: 249, yearly: 199 },
      features: [
        'Prontuário Eletrônico (PEP) Especializado',
        'Agenda Inteligente & Confirmações',
        'Prescrição Digital Básica',
        'App do Paciente (Visualização)',
        'Suporte por Ticket'
      ],
      notIncluded: [
        'Inteligência Artificial (Nexus Core)',
        'Gestão de Estoque Injetável',
        'Laboratório de Fórmulas'
      ],
      highlight: false,
      theme: 'cyan'
    },
    {
      id: 'performance',
      name: 'EndoInject Performance',
      description: 'Otimização metabólica e gestão de injetáveis com IA.',
      price: { monthly: 599, yearly: 479 },
      features: [
        'Tudo do plano Clinical',
        'Motor IA Nexus (Protocolos & Raciocínio)',
        'Gestão de Estoque & Validade',
        'Compound Builder (Criador de Fórmulas)',
        'Geração de Imagens Educativas',
        'Suporte via WhatsApp'
      ],
      notIncluded: [
        'Integração Laboratorial (LIMS)',
        'Personalização White Label'
      ],
      highlight: true,
      theme: 'gradient'
    },
    {
      id: 'ecosystem',
      name: 'EndoInject Ecosystem',
      description: 'A plataforma definitiva para clínicas de alta performance.',
      price: { monthly: 1299, yearly: 1039 },
      features: [
        'Tudo do plano Performance',
        'Integração Total (iMeddis + LabPro)',
        'Múltiplos Profissionais',
        'White Label (Sua Marca no App)',
        'API para Business Intelligence',
        'Consultoria de Sucesso do Cliente'
      ],
      notIncluded: [],
      highlight: false,
      theme: 'pink'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto pb-12 animate-fade-in">
      
      {/* Header Section */}
      <div className="text-center py-16 space-y-6 relative">
        {/* Decorative Background Elements */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-r from-sky-200/20 to-pink-200/20 blur-3xl rounded-full pointer-events-none"></div>

        <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight relative z-10">
          Planos Modulares <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-500 to-pink-500">EndoInject</span>
        </h2>
        <p className="text-slate-500 dark:text-slate-400 font-medium max-w-2xl mx-auto text-xl relative z-10">
          Do prontuário básico à inteligência artificial avançada. Selecione o módulo que impulsiona sua prática médica.
        </p>

        {/* Billing Toggle */}
        <div className="flex items-center justify-center mt-10 relative z-10">
          <div className="bg-white dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 inline-flex relative shadow-sm">
            <button
              onClick={() => setBillingCycle('MONTHLY')}
              className={`px-8 py-3 rounded-xl text-sm font-bold transition-all relative z-10 ${
                billingCycle === 'MONTHLY' 
                  ? 'text-slate-900 dark:text-white shadow-sm' 
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
              }`}
            >
              Mensal
            </button>
            <button
              onClick={() => setBillingCycle('YEARLY')}
              className={`px-8 py-3 rounded-xl text-sm font-bold transition-all relative z-10 ${
                billingCycle === 'YEARLY' 
                  ? 'text-pink-600 dark:text-pink-400 shadow-sm' 
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
              }`}
            >
              Anual <span className="text-[10px] bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-300 px-2 py-0.5 rounded-full ml-2 font-extrabold">-20%</span>
            </button>
            
            {/* Sliding Background */}
            <div className={`absolute top-1.5 bottom-1.5 w-[calc(50%-6px)] bg-slate-100 dark:bg-slate-700 rounded-xl transition-all duration-300 ease-in-out ${
              billingCycle === 'MONTHLY' ? 'left-1.5' : 'left-[calc(50%+3px)]'
            }`}></div>
          </div>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4 lg:px-12">
        {plans.map((plan) => {
          const currentPrice = billingCycle === 'MONTHLY' ? plan.price.monthly : plan.price.yearly;
          
          // Theme Logic
          let containerClass = "";
          let buttonClass = "";
          let checkIconClass = "";
          let priceClass = "text-slate-900 dark:text-white";
          
          if (plan.theme === 'cyan') { // Clinical
             containerClass = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-sky-300 dark:hover:border-sky-700 hover:shadow-sky-100 dark:hover:shadow-sky-900/20";
             buttonClass = "bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200";
             checkIconClass = "bg-sky-100 text-sky-600 dark:bg-sky-900/30 dark:text-sky-400";
          } else if (plan.theme === 'pink') { // Ecosystem
             containerClass = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-pink-300 dark:hover:border-pink-700 hover:shadow-pink-100 dark:hover:shadow-pink-900/20";
             buttonClass = "bg-pink-50 text-pink-700 hover:bg-pink-100 border border-pink-200";
             checkIconClass = "bg-pink-100 text-pink-600 dark:bg-pink-900/30 dark:text-pink-400";
          } else { // Performance (Gradient)
             containerClass = "bg-slate-900 text-white border-transparent ring-4 ring-pink-500/20 transform md:-translate-y-4";
             buttonClass = "bg-gradient-to-r from-sky-500 to-pink-500 text-white hover:shadow-lg hover:shadow-pink-500/30 border-none";
             checkIconClass = "bg-white/20 text-white";
             priceClass = "text-white";
          }

          return (
            <div 
              key={plan.id}
              className={`relative rounded-[2rem] p-8 flex flex-col transition-all duration-500 hover:shadow-2xl border ${containerClass}`}
            >
              {plan.highlight && (
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-sky-500 to-pink-500 text-white px-6 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-xl shadow-pink-500/30">
                  Mais Escolhido
                </div>
              )}

              <div className="mb-8">
                <h3 className={`text-2xl font-black mb-3 ${plan.theme === 'gradient' ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                  {plan.name}
                </h3>
                <p className={`text-sm font-medium leading-relaxed ${plan.theme === 'gradient' ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                  {plan.description}
                </p>
              </div>

              <div className="mb-8 flex items-baseline">
                <span className={`text-lg font-bold mr-1 ${plan.theme === 'gradient' ? 'text-slate-300' : 'text-slate-400'}`}>R$</span>
                <span className={`text-6xl font-black tracking-tighter ${priceClass}`}>
                  {currentPrice}
                </span>
                <span className={`text-sm font-bold ml-1 ${plan.theme === 'gradient' ? 'text-slate-300' : 'text-slate-400'}`}>/mês</span>
              </div>

              {/* Divider */}
              <div className={`h-px w-full mb-8 ${plan.theme === 'gradient' ? 'bg-white/10' : 'bg-slate-100 dark:bg-slate-700'}`}></div>

              <div className="space-y-5 flex-1 mb-10">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start space-x-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${checkIconClass}`}>
                      <i className="fa-solid fa-check text-[10px]"></i>
                    </div>
                    <span className={`text-sm font-bold ${plan.theme === 'gradient' ? 'text-slate-100' : 'text-slate-700 dark:text-slate-300'}`}>
                      {feature}
                    </span>
                  </div>
                ))}
                {plan.notIncluded.map((feature, i) => (
                  <div key={i} className="flex items-start space-x-3 opacity-40">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${plan.theme === 'gradient' ? 'bg-white/10 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}>
                      <i className="fa-solid fa-xmark text-[10px]"></i>
                    </div>
                    <span className={`text-sm font-medium ${plan.theme === 'gradient' ? 'text-slate-300' : 'text-slate-500 dark:text-slate-500'}`}>
                      {feature}
                    </span>
                  </div>
                ))}
              </div>

              <button className={`w-full py-4 rounded-2xl font-black text-sm tracking-wide transition-all transform active:scale-95 shadow-md ${buttonClass}`}>
                {plan.theme === 'pink' ? 'Falar com Consultor' : 'Começar Avaliação Gratuita'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Trust Badges */}
      <div className="mt-20 border-t border-slate-200 dark:border-slate-800 pt-12">
        <p className="text-center text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-8">Segurança & Compliance</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center text-center space-y-3">
               <div className="w-12 h-12 bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 rounded-2xl flex items-center justify-center text-xl">
                 <i className="fa-solid fa-lock"></i>
               </div>
               <p className="font-bold text-slate-700 dark:text-slate-300 text-sm">Dados Criptografados</p>
            </div>
            <div className="flex flex-col items-center text-center space-y-3">
               <div className="w-12 h-12 bg-pink-50 dark:bg-pink-900/20 text-pink-600 dark:text-pink-400 rounded-2xl flex items-center justify-center text-xl">
                 <i className="fa-solid fa-server"></i>
               </div>
               <p className="font-bold text-slate-700 dark:text-slate-300 text-sm">Backup Diário</p>
            </div>
            <div className="flex flex-col items-center text-center space-y-3">
               <div className="w-12 h-12 bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 rounded-2xl flex items-center justify-center text-xl">
                 <i className="fa-solid fa-certificate"></i>
               </div>
               <p className="font-bold text-slate-700 dark:text-slate-300 text-sm">Padrão SBEM</p>
            </div>
            <div className="flex flex-col items-center text-center space-y-3">
               <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center text-xl">
                 <i className="fa-solid fa-headset"></i>
               </div>
               <p className="font-bold text-slate-700 dark:text-slate-300 text-sm">Suporte Dedicado</p>
            </div>
        </div>
      </div>

    </div>
  );
};

export default PlansView;
