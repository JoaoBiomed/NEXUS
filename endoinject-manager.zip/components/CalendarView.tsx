
import React, { useState } from 'react';
import { Appointment } from '../types';

// Mock Data for Initial State
const MOCK_APPOINTMENTS: Appointment[] = [
  { id: '1', patientName: 'Carlos Mendes', date: new Date(new Date().setHours(9, 0, 0, 0)), type: 'Consultation', status: 'Confirmed' },
  { id: '2', patientName: 'Juliana Silva', date: new Date(new Date().setHours(14, 30, 0, 0)), type: 'Implant', status: 'Confirmed', notes: 'Gestrinona' },
  { id: '3', patientName: 'Roberto Alencar', date: new Date(new Date().setDate(new Date().getDate() + 1)), type: 'Injection', status: 'Pending', notes: 'Testosterona' },
];

const CalendarView: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [appointments, setAppointments] = useState<Appointment[]>(MOCK_APPOINTMENTS);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newEvent, setNewEvent] = useState<Partial<Appointment>>({
    type: 'Consultation',
    status: 'Confirmed'
  });

  // Calendar Logic
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleDateClick = (day: number) => {
    const clickedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedDate(clickedDate);
    // Reset modal form
    setNewEvent({
        type: 'Consultation',
        status: 'Confirmed',
        date: clickedDate
    });
    setIsModalOpen(true);
  };

  const handleSaveEvent = () => {
    if (newEvent.patientName && newEvent.date && newEvent.type) {
        // Parse time if it was a string input, or combine with date
        // For simplicity in this UI demo, we assume the time is set or defaults
        const newAppointment: Appointment = {
            id: Math.random().toString(36).substr(2, 9),
            patientName: newEvent.patientName,
            date: newEvent.date, // Time would be handled here
            type: newEvent.type as any,
            status: newEvent.status as any,
            notes: newEvent.notes
        };
        setAppointments([...appointments, newAppointment]);
        setIsModalOpen(false);
    }
  };

  const getDayEvents = (day: number) => {
    return appointments.filter(app => 
      app.date.getDate() === day && 
      app.date.getMonth() === currentDate.getMonth() && 
      app.date.getFullYear() === currentDate.getFullYear()
    );
  };

  const getEventTypeColor = (type: string) => {
      switch(type) {
          case 'Consultation': return 'bg-blue-100 text-blue-700 border-blue-200';
          case 'Implant': return 'bg-purple-100 text-purple-700 border-purple-200';
          case 'Injection': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
          default: return 'bg-gray-100 text-gray-700';
      }
  };

  const getEventIcon = (type: string) => {
    switch(type) {
        case 'Consultation': return 'fa-user-doctor';
        case 'Implant': return 'fa-capsules';
        case 'Injection': return 'fa-syringe';
        case 'FollowUp': return 'fa-clipboard-check';
        default: return 'fa-calendar';
    }
  };

  const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
  const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

  return (
    <div className="max-w-7xl mx-auto h-[calc(100vh-6rem)] flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex justify-between items-center mb-6 bg-white p-6 rounded-3xl shadow-soft border border-gray-100">
        <div className="flex items-center space-x-6">
            <h2 className="text-3xl font-bold text-gray-900 capitalize w-48">
                {monthNames[currentDate.getMonth()]} <span className="text-clinical-400 font-normal">{currentDate.getFullYear()}</span>
            </h2>
            <div className="flex bg-gray-100 rounded-xl p-1 space-x-1">
                <button onClick={handlePrevMonth} className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-white hover:shadow-sm transition-all text-gray-600">
                    <i className="fa-solid fa-chevron-left"></i>
                </button>
                <button onClick={() => setCurrentDate(new Date())} className="px-4 text-sm font-bold text-gray-700 hover:bg-white hover:shadow-sm rounded-lg transition-all">
                    Hoje
                </button>
                <button onClick={handleNextMonth} className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-white hover:shadow-sm transition-all text-gray-600">
                    <i className="fa-solid fa-chevron-right"></i>
                </button>
            </div>
        </div>
        <button 
            onClick={() => { setSelectedDate(new Date()); setIsModalOpen(true); }}
            className="bg-clinical-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-clinical-700 shadow-lg shadow-clinical-500/30 transition-all flex items-center"
        >
            <i className="fa-solid fa-plus mr-2"></i> Novo Agendamento
        </button>
      </div>

      {/* Calendar Grid */}
      <div className="flex-1 bg-white rounded-3xl shadow-soft border border-gray-100 overflow-hidden flex flex-col">
        {/* Week Days Header */}
        <div className="grid grid-cols-7 border-b border-gray-100 bg-gray-50/50">
            {weekDays.map(day => (
                <div key={day} className="py-4 text-center text-sm font-bold text-gray-400 uppercase tracking-wider">
                    {day}
                </div>
            ))}
        </div>

        {/* Days Cells */}
        <div className="grid grid-cols-7 flex-1 auto-rows-fr">
            {/* Empty slots for previous month */}
            {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                <div key={`empty-${i}`} className="border-b border-r border-gray-50 bg-gray-50/20"></div>
            ))}

            {/* Actual Days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const events = getDayEvents(day);
                const isToday = day === new Date().getDate() && currentDate.getMonth() === new Date().getMonth() && currentDate.getFullYear() === new Date().getFullYear();

                return (
                    <div 
                        key={day} 
                        onClick={() => handleDateClick(day)}
                        className={`min-h-[120px] p-3 border-b border-r border-gray-50 transition-colors cursor-pointer group hover:bg-blue-50/30 relative ${isToday ? 'bg-blue-50/10' : ''}`}
                    >
                        <span className={`w-8 h-8 flex items-center justify-center rounded-full text-sm font-bold mb-2 ${isToday ? 'bg-clinical-600 text-white shadow-md' : 'text-gray-700 group-hover:text-clinical-600'}`}>
                            {day}
                        </span>

                        <div className="space-y-1.5 overflow-y-auto max-h-[100px] custom-scrollbar">
                            {events.map(event => (
                                <div key={event.id} className={`px-2 py-1.5 rounded-lg border text-xs font-semibold truncate ${getEventTypeColor(event.type)}`}>
                                    <div className="flex items-center gap-1.5">
                                        <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${event.status === 'Confirmed' ? 'bg-current' : 'bg-transparent border border-current'}`}></div>
                                        <i className={`fa-solid ${getEventIcon(event.type)} text-[10px] opacity-70`}></i>
                                        <span className="truncate">{event.patientName}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
      </div>

      {/* Modal - New Appointment */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden">
                <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                    <h3 className="text-xl font-bold text-gray-900">
                        {selectedDate?.toLocaleDateString('pt-BR')} - Novo Evento
                    </h3>
                    <button onClick={() => setIsModalOpen(false)} className="w-8 h-8 rounded-full bg-white text-gray-400 hover:text-gray-600 flex items-center justify-center shadow-sm">
                        <i className="fa-solid fa-times"></i>
                    </button>
                </div>
                
                <div className="p-8 space-y-6">
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Paciente</label>
                        <input 
                            type="text" 
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-clinical-500 focus:bg-white transition-all font-medium text-gray-900"
                            placeholder="Nome do paciente"
                            value={newEvent.patientName || ''}
                            onChange={(e) => setNewEvent({...newEvent, patientName: e.target.value})}
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">Tipo</label>
                            <select 
                                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-clinical-500 font-medium text-gray-900"
                                value={newEvent.type}
                                onChange={(e) => setNewEvent({...newEvent, type: e.target.value as any})}
                            >
                                <option value="Consultation">Consulta</option>
                                <option value="Injection">Injetável (Aplicação)</option>
                                <option value="Implant">Implante Hormonal</option>
                                <option value="FollowUp">Retorno</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">Horário</label>
                            <input 
                                type="time"
                                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-clinical-500 font-medium text-gray-900"
                                defaultValue="09:00"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Notas</label>
                        <textarea 
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-clinical-500 font-medium text-gray-900 resize-none h-24"
                            placeholder="Detalhes adicionais..."
                            value={newEvent.notes || ''}
                            onChange={(e) => setNewEvent({...newEvent, notes: e.target.value})}
                        />
                    </div>

                    <div className="pt-2">
                        <button 
                            onClick={handleSaveEvent}
                            className="w-full py-4 bg-clinical-600 hover:bg-clinical-700 text-white font-bold rounded-xl shadow-lg shadow-clinical-500/20 transition-all transform active:scale-95"
                        >
                            Confirmar Agendamento
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default CalendarView;
