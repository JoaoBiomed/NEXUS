
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { MOCK_PATIENTS, MOCK_LAB_RESULTS } from '../constants';
import { searchMedicalInfo, generateEducationalVisual, editMedicalImage, generateLifestylePlan, generateVeoVideo } from '../services/geminiService';
import { LifestyleTip, Patient } from '../types';
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  Legend,
  LabelList
} from 'recharts';

const SIDE_EFFECTS = [
  { id: 1, name: 'Irritabilidade', severity: 'severe', note: 'Paciente relatou episódios de raiva.' },
  { id: 2, name: 'Acne Dorsal', severity: 'moderate', note: 'Grau II. Iniciado peróxido de benzoíla.' },
  { id: 3, name: 'Retenção Hídrica', severity: 'mild', note: 'Leve edema tornozelo vespertino.' },
];

const MOCK_HISTORY = [
  { id: 1, date: '15 OUT 2023', type: 'Procedimento (Implante)', title: 'Inserção Gestrinona + Testo', notes: 'Procedimento realizado sem intercorrências. Anestesia local (Lidocaína 2%). Curativo oclusivo aplicado.' },
  { id: 2, date: '20 SET 2023', type: 'Consulta', title: 'Avaliação de Queixas', notes: 'Paciente relatou baixa libido e fadiga vespertina. Solicitado painel laboratorial completo.' },
  { id: 3, date: '10 AGO 2023', type: 'Terapia IM', title: 'Booster Metabólico Inicial', notes: 'Aplicação Intramuscular de L-Carnitina (600mg) + B12. Tolerância excelente.' },
  { id: 4, date: '01 JUN 2023', type: 'Consulta', title: 'Anamnese Inicial', notes: 'Primeira visita. Histórico de hipotireoidismo subclínico. Definido objetivo de recomposição corporal.' },
];

// Simple formatter for search results
const SimpleFormattedText: React.FC<{ text: string }> = ({ text }) => {
    if (!text) return null;
    const lines = text.split('\n');
    return (
        <div className="space-y-3">
            {lines.map((line, i) => {
                const trimmed = line.trim();
                if (!trimmed) return <div key={i} className="h-1" />;
                
                if (trimmed.startsWith('###')) {
                     return <h4 key={i} className="text-clinical-800 dark:text-clinical-300 font-extrabold mt-3 text-base border-b border-clinical-200 dark:border-clinical-800 pb-1">{trimmed.replace('###', '')}</h4>;
                }
                if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
                     const parts = trimmed.substring(2).split(/(\*\*.*?\*\*)/g);
                     return (
                         <div key={i} className="flex items-start space-x-2 ml-1">
                             <div className="w-1.5 h-1.5 rounded-full bg-clinical-600 dark:bg-clinical-400 mt-2 flex-shrink-0"></div>
                             <p className="text-slate-800 dark:text-slate-300 text-sm leading-relaxed font-medium">
                                {parts.map((part, idx) => 
                                    part.startsWith('**') ? <strong key={idx} className="text-slate-900 dark:text-white font-bold">{part.replace(/\*\*/g, '')}</strong> : part
                                )}
                             </p>
                         </div>
                     );
                }
                const parts = trimmed.split(/(\*\*.*?\*\*)/g);
                return <p key={i} className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed font-medium">
                    {parts.map((part, idx) => 
                        part.startsWith('**') ? <strong key={idx} className="text-slate-900 dark:text-white font-bold">{part.replace(/\*\*/g, '')}</strong> : part
                    )}
                </p>;
            })}
        </div>
    );
};

const PatientDetail: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const [patient, setPatient] = useState<Patient>(MOCK_PATIENTS[0]);

  useEffect(() => {
    if (location.state && location.state.patientData) {
        setPatient(location.state.patientData);
    }
  }, [location.state]);
  
  const [patientSearchTerm, setPatientSearchTerm] = useState('');
  const [isPatientDropdownOpen, setIsPatientDropdownOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<{ text: string, sources: any[] } | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const [imagePrompt, setImagePrompt] = useState('Anatomia muscular do quadríceps mostrando local de injeção');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGeneratingImg, setIsGeneratingImg] = useState(false);

  const [editPrompt, setEditPrompt] = useState('');
  const [isEditingImg, setIsEditingImg] = useState(false);
  const [showEditControls, setShowEditControls] = useState(false);

  const [lifestylePlan, setLifestylePlan] = useState<LifestyleTip[]>([]);
  const [isLoadingLifestyle, setIsLoadingLifestyle] = useState(false);
  const [generatingVideoId, setGeneratingVideoId] = useState<string | null>(null);

  const filteredPatients = MOCK_PATIENTS.filter(p => 
    p.name.toLowerCase().includes(patientSearchTerm.toLowerCase()) ||
    (p.cpf && p.cpf.includes(patientSearchTerm))
  );

  const handlePatientSelect = (p: Patient) => {
      setPatient(p);
      setPatientSearchTerm('');
      setIsPatientDropdownOpen(false);
  };

  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
              setIsPatientDropdownOpen(false);
          }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
          document.removeEventListener("mousedown", handleClickOutside);
      };
  }, []);

  const handleSearch = async () => {
    if(!searchQuery) return;
    setIsSearching(true);
    const result = await searchMedicalInfo(searchQuery);
    setSearchResult(result);
    setIsSearching(false);
  };

  const handleGenerateImage = async () => {
    setIsGeneratingImg(true);
    setShowEditControls(false);
    const img = await generateEducationalVisual(imagePrompt, imageSize);
    setGeneratedImage(img);
    setIsGeneratingImg(false);
  };

  const handleEditImage = async () => {
    if (!generatedImage || !editPrompt) return;
    setIsEditingImg(true);
    const newImg = await editMedicalImage(generatedImage, editPrompt);
    if (newImg) {
        setGeneratedImage(newImg);
        setEditPrompt('');
    }
    setIsEditingImg(false);
  };

  const handleGenerateLifestyle = async () => {
    setIsLoadingLifestyle(true);
    const context = `${patient.currentProtocol} para Otimização de Performance`;
    const plan = await generateLifestylePlan(context);
    setLifestylePlan(plan);
    setIsLoadingLifestyle(false);
  };

  const handleAnimateTip = async (tipId: string, imageBase64: string, tipTitle: string) => {
    setGeneratingVideoId(tipId);
    const videoUrl = await generateVeoVideo(imageBase64, `Cinematic slow motion shot representing ${tipTitle}, professional medical aesthetic, 4k`);
    
    if (videoUrl) {
      setLifestylePlan(prev => prev.map(tip => 
        tip.id === tipId ? { ...tip, videoUrl } : tip
      ));
    }
    setGeneratingVideoId(null);
  };

  const handleNavigateToProtocol = () => {
    navigate('/protocol', {
      state: {
        patientWeight: 82, 
        patientHeight: 179, 
        gender: patient.gender,
        goal: 'HRT', 
        medicalHistory: `Paciente ${patient.name}, ${patient.age} anos.\nProtocolo atual: ${patient.currentProtocol}.\nStatus: ${patient.status}.`,
      }
    });
  };

  const getSeverityEmoji = (severity: string) => {
    switch(severity) {
      case 'severe': return '😞';
      case 'moderate': return '😐';
      case 'mild': return '🙂';
      default: return '😐';
    }
  };

  const getTimelineStyle = (type: string) => {
    if (type.includes('Consulta')) return { 
        icon: 'fa-user-doctor', 
        bg: 'bg-blue-100 dark:bg-blue-900/40', 
        text: 'text-blue-700 dark:text-blue-300', 
        border: 'border-blue-200 dark:border-blue-800' 
    };
    if (type.includes('Procedimento')) return { 
        icon: 'fa-microscope', 
        bg: 'bg-purple-100 dark:bg-purple-900/40', 
        text: 'text-purple-700 dark:text-purple-300', 
        border: 'border-purple-200 dark:border-purple-800' 
    };
    if (type.includes('Terapia')) return { 
        icon: 'fa-syringe', 
        bg: 'bg-emerald-100 dark:bg-emerald-900/40', 
        text: 'text-emerald-700 dark:text-emerald-300', 
        border: 'border-emerald-200 dark:border-emerald-800' 
    };
    return { 
        icon: 'fa-notes-medical', 
        bg: 'bg-slate-100 dark:bg-slate-700', 
        text: 'text-slate-600 dark:text-slate-300', 
        border: 'border-slate-200 dark:border-slate-600' 
    };
  };

  const groupedHistory = MOCK_HISTORY.reduce((acc, item) => {
    if (!acc[item.date]) {
      acc[item.date] = [];
    }
    acc[item.date].push(item);
    return acc;
  }, {} as Record<string, typeof MOCK_HISTORY>);

  return (
    <div className="space-y-8 pb-24 max-w-7xl mx-auto animate-fade-in">
      
      {/* Patient Search & Header */}
      <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 flex flex-col relative overflow-visible z-30">
        
        {/* Search Bar */}
        <div className="mb-6 relative w-full max-w-lg" ref={searchContainerRef}>
            <div className="relative">
                <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400"></i>
                <input 
                    type="text" 
                    placeholder="Buscar paciente (Nome ou CPF)..."
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-clinical-600 font-bold text-slate-700 dark:text-white placeholder-slate-400 transition-all"
                    value={patientSearchTerm}
                    onChange={(e) => {
                        setPatientSearchTerm(e.target.value);
                        setIsPatientDropdownOpen(true);
                    }}
                    onFocus={() => setIsPatientDropdownOpen(true)}
                />
            </div>
            {isPatientDropdownOpen && patientSearchTerm && (
                <div className="absolute top-full left-0 w-full mt-2 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 max-h-60 overflow-y-auto custom-scrollbar z-50">
                    {filteredPatients.length > 0 ? (
                        filteredPatients.map(p => (
                            <div 
                                key={p.id}
                                onClick={() => handlePatientSelect(p)}
                                className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer flex items-center space-x-3 border-b border-slate-50 dark:border-slate-700 last:border-0 transition-colors"
                            >
                                <img src={p.avatar} alt={p.name} className="w-8 h-8 rounded-full object-cover" />
                                <div>
                                    <p className="font-bold text-sm text-slate-900 dark:text-white">{p.name}</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">{p.cpf || 'CPF não cadastrado'}</p>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="p-4 text-center text-slate-500 dark:text-slate-400 font-medium text-sm">
                            Nenhum paciente encontrado.
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* Patient Profile Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
            <div className="absolute top-0 right-0 w-64 h-64 bg-clinical-50 dark:bg-clinical-900/20 rounded-full mix-blend-multiply filter blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
            
            <div className="flex items-center space-x-6 z-10">
                <div className="relative">
                    <img src={patient.avatar} className="w-24 h-24 rounded-2xl object-cover shadow-lg ring-4 ring-white dark:ring-slate-700" alt="Patient" />
                    <div className={`absolute -bottom-2 -right-2 w-6 h-6 border-4 border-white dark:border-slate-800 rounded-full ${patient.status === 'Critical' ? 'bg-red-600' : 'bg-green-500'}`}></div>
                </div>
                <div>
                    <div className="flex items-center space-x-3 mb-1">
                        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">{patient.name}</h1>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide border ${
                            patient.status === 'Active' ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800' :
                            patient.status === 'Critical' ? 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 border-red-200 dark:border-red-800' :
                            'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                        }`}>
                            {patient.status === 'Active' ? 'Ativo' : patient.status === 'Critical' ? 'Crítico' : 'Manutenção'}
                        </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 mb-4 font-bold">{patient.age} anos • {patient.gender === 'Male' ? 'Masculino' : 'Feminino'} • CPF: {patient.cpf || '---'}</p>
                    <div className="flex space-x-8">
                        <div>
                            <div className="flex items-center space-x-2 mb-1">
                                <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-extrabold tracking-wider">Protocolo Atual</p>
                                <button 
                                    onClick={handleNavigateToProtocol}
                                    className="text-[10px] bg-clinical-50 dark:bg-clinical-900/30 text-clinical-800 dark:text-clinical-300 font-bold px-2 py-0.5 rounded border border-clinical-200 dark:border-clinical-800 hover:bg-clinical-100 dark:hover:bg-clinical-800 transition-colors flex items-center"
                                    title="Analisar e ajustar protocolo com IA"
                                >
                                    <i className="fa-solid fa-wand-magic-sparkles mr-1"></i> Revisar c/ IA
                                </button>
                            </div>
                            <p className="font-bold text-slate-900 dark:text-white">{patient.currentProtocol}</p>
                        </div>
                        <div>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-extrabold tracking-wider mb-1">Próxima Renovação</p>
                            <p className="font-bold text-clinical-600 dark:text-clinical-400">{patient.nextRenewal}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="flex space-x-3 z-10">
                <button className="px-5 py-3 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-800 dark:text-white font-bold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-600 transition-all shadow-sm">
                    <i className="fa-solid fa-notes-medical mr-2 text-slate-500 dark:text-slate-300"></i> Diário
                </button>
                <button className="px-5 py-3 bg-clinical-600 text-white font-bold rounded-xl hover:bg-clinical-800 shadow-lg shadow-clinical-900/30 transition-all transform hover:-translate-y-0.5">
                    <i className="fa-solid fa-rotate mr-2"></i> Renovar
                </button>
            </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Charts */}
        <div className="lg:col-span-2 space-y-8">
           <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700">
             <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Histórico de Exames Laboratoriais</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Monitoramento integrado de resposta hormonal e hematológica.</p>
                </div>
             </div>
             
             {/* Interactive Chart */}
             <div className="h-96 w-full mb-8">
               <ResponsiveContainer width="100%" height="100%">
                 <ComposedChart data={MOCK_LAB_RESULTS} margin={{top: 10, right: 10, left: -20, bottom: 0}}>
                   <defs>
                     <linearGradient id="colorT" x1="0" y1="0" x2="0" y2="1">
                       <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.1}/>
                       <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                     </linearGradient>
                   </defs>
                   <CartesianGrid stroke="#e2e8f0" strokeOpacity={0.2} vertical={false} strokeDasharray="3 3" />
                   <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 700}} dy={15} />
                   
                   <YAxis yAxisId="left" orientation="left" stroke="#0ea5e9" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 600}} label={{ value: 'Testo (ng/dL)', angle: -90, position: 'insideLeft', fill: '#0ea5e9', fontSize: 11, fontWeight: 'bold' }} />
                   
                   <YAxis yAxisId="right" orientation="right" stroke="#c084fc" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 600}} />

                   <Tooltip 
                     contentStyle={{ backgroundColor: '#1e293b', borderRadius: '16px', border: '1px solid #334155', padding: '12px', color: '#f8fafc' }}
                     itemStyle={{ fontWeight: 600, color: '#e2e8f0' }}
                     cursor={{fill: 'rgba(255,255,255,0.05)'}}
                   />
                   <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ paddingTop: '0px', paddingBottom: '20px', fontWeight: 600, color: '#94a3b8' }}/>

                   <Bar yAxisId="right" dataKey="dosage" barSize={32} fill="#c084fc" radius={[8, 8, 0, 0]} name="Dose Semanal (mg)">
                      <LabelList dataKey="dosage" position="top" fill="#a855f7" fontSize={11} fontWeight="bold" formatter={(val: number) => `${val}mg`} />
                   </Bar>
                   <Area yAxisId="left" type="monotone" dataKey="testosteroneTotal" stroke="#0ea5e9" strokeWidth={3} fillOpacity={1} fill="url(#colorT)" name="Testosterona Total" />
                   <Line yAxisId="right" type="monotone" dataKey="estradiol" stroke="#ec4899" strokeWidth={3} dot={{r: 4}} name="Estradiol" />
                   <Line yAxisId="right" type="monotone" dataKey="hematocrit" stroke="#f97316" strokeWidth={3} dot={{r: 4}} name="Hematócrito (%)" />
                 </ComposedChart>
               </ResponsiveContainer>
             </div>

             {/* Data Table */}
             <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                <table className="w-full text-sm text-left text-slate-600 dark:text-slate-400">
                    <thead className="text-xs text-slate-800 dark:text-slate-200 uppercase bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700">
                        <tr>
                            <th scope="col" className="px-6 py-4 font-extrabold">Data</th>
                            <th scope="col" className="px-6 py-4 font-extrabold text-clinical-600 dark:text-clinical-400">Testosterona</th>
                            <th scope="col" className="px-6 py-4 font-extrabold text-pink-600 dark:text-pink-400">Estradiol</th>
                            <th scope="col" className="px-6 py-4 font-extrabold text-orange-600 dark:text-orange-400">Hematócrito</th>
                            <th scope="col" className="px-6 py-4 font-extrabold text-purple-700 dark:text-purple-400 text-right">Dosagem</th>
                        </tr>
                    </thead>
                    <tbody>
                        {MOCK_LAB_RESULTS.map((result, index) => (
                            <tr key={index} className="bg-white dark:bg-slate-800 border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors last:border-0">
                                <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">{result.date}</td>
                                <td className="px-6 py-4 font-semibold">{result.testosteroneTotal} ng/dL</td>
                                <td className="px-6 py-4 font-semibold">{result.estradiol} pg/mL</td>
                                <td className="px-6 py-4 font-semibold">
                                    <span className={result.hematocrit > 50 ? 'text-red-700 dark:text-red-400 font-bold flex items-center gap-1' : ''}>
                                        {result.hematocrit > 50 && <i className="fa-solid fa-triangle-exclamation text-xs"></i>}
                                        {result.hematocrit}%
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300 px-2 py-1 rounded-md font-bold text-xs border border-purple-200 dark:border-purple-800">{result.dosage} mg</span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
           </div>

           {/* --- NEW SECTION: Photographic Progression --- */}
           <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700">
               <div className="flex justify-between items-center mb-6">
                   <div>
                       <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center">
                           <i className="fa-solid fa-camera mr-2 text-clinical-600"></i> Evolução Visual
                       </h3>
                       <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Histórico fotográfico comparativo.</p>
                   </div>
                   <button className="text-xs font-bold bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-white px-4 py-2 rounded-lg transition-colors border border-slate-200 dark:border-slate-600">
                       <i className="fa-solid fa-upload mr-2"></i> Nova Foto
                   </button>
               </div>

               {patient.photos && patient.photos.length > 0 ? (
                   <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                       {patient.photos.map((photo) => (
                           <div key={photo.id} className="group relative bg-slate-50 dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 hover:shadow-lg transition-all">
                               <div className="aspect-[3/4] overflow-hidden">
                                   <img src={photo.url} alt="Progresso" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                                   <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                                       <p className="text-white text-xs font-medium">{photo.note}</p>
                                   </div>
                               </div>
                               <div className="p-3 bg-white dark:bg-slate-800 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center">
                                   <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{photo.date}</span>
                                   <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">{photo.weight}kg</span>
                               </div>
                           </div>
                       ))}
                   </div>
               ) : (
                   <div className="text-center py-12 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl bg-slate-50 dark:bg-slate-900/50">
                       <i className="fa-solid fa-images text-3xl text-slate-300 dark:text-slate-600 mb-2"></i>
                       <p className="text-slate-500 dark:text-slate-400 font-bold text-sm">Nenhum registro fotográfico encontrado.</p>
                       <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Importe fotos do prontuário ou adicione manualmente.</p>
                   </div>
               )}
           </div>

           {/* Research Module (Grounding) */}
           <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-blue-500 to-purple-600"></div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center">
                    <div className="w-8 h-8 bg-blue-50 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-3 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-800">
                        <i className="fa-brands fa-google"></i>
                    </div>
                    Assistente de Pesquisa Clínica
                </h3>
                <div className="flex gap-3 mb-6">
                    <input 
                        type="text"
                        className="flex-1 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 rounded-xl px-5 py-3 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-clinical-600 outline-none text-slate-900 dark:text-white font-bold transition-all placeholder-slate-400"
                        placeholder="Ex: 'Efeitos colaterais da Nandrolona no perfil lipídico'"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                    <button 
                        onClick={handleSearch}
                        disabled={isSearching}
                        className="bg-clinical-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-clinical-800 disabled:bg-slate-300 dark:disabled:bg-slate-600 transition-all shadow-md"
                    >
                        {isSearching ? <i className="fa-solid fa-spinner fa-spin"></i> : 'Pesquisar'}
                    </button>
                </div>
                {searchResult && (
                    <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 animate-fade-in">
                        <SimpleFormattedText text={searchResult.text} />
                        
                        {searchResult.sources.length > 0 && (
                            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                                <p className="text-[10px] font-extrabold text-clinical-600 dark:text-clinical-400 uppercase tracking-wider mb-2">Fontes Verificadas:</p>
                                <ul className="space-y-2">
                                    {searchResult.sources.map((chunk, idx) => (
                                        <li key={idx} className="text-xs truncate flex items-center text-slate-700 dark:text-slate-300 font-medium">
                                            <i className="fa-solid fa-link mr-2 text-clinical-500"></i>
                                            <a href={chunk.web?.uri} target="_blank" rel="noreferrer" className="hover:underline hover:text-clinical-900 dark:hover:text-clinical-200 transition-colors">
                                                {chunk.web?.title || chunk.web?.uri}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                )}
           </div>

           {/* Lifestyle Ecosystem */}
           <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700">
             <div className="flex justify-between items-center mb-6">
               <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">Estilo de Vida & Otimização Científica</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Adaptações metabólicas e comportamentais.</p>
               </div>
               <button 
                  onClick={handleGenerateLifestyle}
                  disabled={isLoadingLifestyle}
                  className="px-4 py-2 bg-gradient-to-r from-blue-700 to-indigo-800 text-white text-sm font-bold rounded-xl shadow-lg hover:shadow-blue-500/30 transition-all disabled:opacity-50"
               >
                  {isLoadingLifestyle ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <><i className="fa-solid fa-dna mr-2"></i> Gerar Diretrizes</>}
               </button>
             </div>

             {lifestylePlan.length > 0 ? (
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
                  {lifestylePlan.map((tip) => (
                    <div key={tip.id} className="group relative bg-slate-50 dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 hover:shadow-xl transition-all duration-300">
                        <div className="aspect-[9/16] relative bg-slate-200">
                           {tip.videoUrl ? (
                              <video 
                                src={tip.videoUrl} 
                                autoPlay 
                                loop 
                                muted 
                                className="w-full h-full object-cover"
                              />
                           ) : (
                              <img 
                                src={tip.imageUrl} 
                                alt={tip.title} 
                                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                              />
                           )}
                           
                           <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent"></div>
                           
                           <div className="absolute bottom-0 left-0 p-5 text-white">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className={`px-2 py-0.5 backdrop-blur-md rounded-md text-[10px] font-bold uppercase tracking-wider border border-white/10 ${
                                    tip.category === 'Nutrition' ? 'bg-emerald-900/60 text-emerald-100' :
                                    tip.category === 'Sleep' ? 'bg-indigo-900/60 text-indigo-100' :
                                    'bg-purple-900/60 text-purple-100'
                                }`}>
                                   {tip.category === 'Nutrition' ? 'Bioquímica Nutricional' : tip.category === 'Sleep' ? 'Higiene do Sono' : 'Neurociência'}
                                </span>
                              </div>
                              <h4 className="font-extrabold text-lg leading-tight mb-1 drop-shadow-md">{tip.title}</h4>
                              <p className="text-xs text-gray-200 line-clamp-3 font-medium drop-shadow-sm leading-relaxed">{tip.description}</p>
                           </div>

                           {!tip.videoUrl && (
                             <button 
                                onClick={() => handleAnimateTip(tip.id, tip.imageUrl, tip.title)}
                                disabled={!!generatingVideoId}
                                className="absolute top-3 right-3 w-8 h-8 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white hover:text-black transition-all border border-white/30"
                                title="Animar com Veo"
                             >
                                {generatingVideoId === tip.id ? (
                                   <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                                ) : (
                                   <i className="fa-solid fa-clapperboard text-xs"></i>
                                )}
                             </button>
                           )}
                        </div>
                    </div>
                  ))}
               </div>
             ) : (
               <div className="text-center py-12 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
                  <div className="w-16 h-16 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm text-blue-500 text-2xl border border-slate-200 dark:border-slate-600">
                     <i className="fa-solid fa-microscope"></i>
                  </div>
                  <h4 className="text-slate-800 dark:text-slate-200 font-bold">Nenhuma diretriz ativa</h4>
                  <p className="text-sm text-slate-500 dark:text-slate-400 font-medium max-w-md mx-auto mt-1">
                     Use a IA para cruzar os dados do protocolo injetável com ajustes metabólicos e comportamentais cientificamente validados.
                  </p>
               </div>
             )}
           </div>
        </div>

        {/* Right Column: Visual Education & History */}
        <div className="space-y-8">
            <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 flex flex-col h-auto">
                <div className="mb-6">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Educação Visual do Paciente</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold mt-1">Gere ou edite imagens para explicar o tratamento.</p>
                </div>

                {!showEditControls ? (
                    <div className="space-y-4 mb-6">
                        <div>
                            <label className="text-xs font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wide ml-1">Prompt da Imagem</label>
                            <textarea 
                                className="w-full mt-2 p-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-sm focus:ring-2 focus:ring-clinical-500 outline-none text-slate-900 dark:text-white font-bold transition-all resize-none"
                                rows={3}
                                value={imagePrompt}
                                onChange={(e) => setImagePrompt(e.target.value)}
                            />
                        </div>
                        <div className="flex space-x-3">
                            <div className="flex-1">
                                <select 
                                    className="w-full p-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-sm font-bold focus:outline-none text-slate-900 dark:text-white"
                                    value={imageSize}
                                    onChange={(e) => setImageSize(e.target.value as any)}
                                >
                                    <option value="1K">1K (Rápido)</option>
                                    <option value="2K">2K (Alta Definição)</option>
                                    <option value="4K">4K (Ultra HD)</option>
                                </select>
                            </div>
                            <button 
                                onClick={handleGenerateImage}
                                disabled={isGeneratingImg}
                                className="flex-1 bg-clinical-600 text-white py-2 rounded-xl font-bold hover:bg-clinical-800 shadow-lg shadow-clinical-900/20 disabled:bg-slate-300 dark:disabled:bg-slate-600 transition-all text-sm"
                            >
                                {isGeneratingImg ? <i className="fa-solid fa-spinner fa-spin"></i> : 'Gerar'}
                            </button>
                        </div>
                    </div>
                ) : (
                     <div className="space-y-4 mb-6 animate-fade-in bg-purple-50 dark:bg-purple-900/20 p-4 rounded-xl border border-purple-200 dark:border-purple-800">
                        <div className="flex justify-between items-center">
                            <label className="text-xs font-extrabold text-purple-800 dark:text-purple-300 uppercase tracking-wide">Editar Imagem (IA)</label>
                            <button onClick={() => setShowEditControls(false)} className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white font-bold"><i className="fa-solid fa-times"></i> Cancelar</button>
                        </div>
                        <textarea 
                            className="w-full p-3 bg-white dark:bg-slate-900 border border-purple-200 dark:border-purple-700 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none text-slate-900 dark:text-white font-bold transition-all resize-none"
                            rows={2}
                            placeholder="Ex: Adicione uma seta vermelha no local..."
                            value={editPrompt}
                            onChange={(e) => setEditPrompt(e.target.value)}
                        />
                        <button 
                            onClick={handleEditImage}
                            disabled={isEditingImg || !editPrompt}
                            className="w-full bg-purple-700 text-white py-2 rounded-xl font-bold hover:bg-purple-800 shadow-lg shadow-purple-500/20 disabled:bg-slate-300 transition-all text-sm"
                        >
                            {isEditingImg ? <i className="fa-solid fa-spinner fa-spin"></i> : <><i className="fa-solid fa-wand-magic-sparkles mr-2"></i> Aplicar Edição</>}
                        </button>
                    </div>
                )}

                <div className="flex-1 bg-slate-100 dark:bg-slate-900 rounded-2xl flex items-center justify-center overflow-hidden border border-slate-200 dark:border-slate-700 relative min-h-[250px] group">
                    {generatedImage ? (
                        <>
                            <img src={generatedImage} alt="Visual Médico" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 backdrop-blur-sm">
                                <button 
                                    onClick={() => setShowEditControls(true)}
                                    className="bg-white text-slate-900 px-4 py-2 rounded-lg font-bold text-sm hover:bg-slate-200 shadow-lg"
                                >
                                    <i className="fa-solid fa-pen-to-square mr-2"></i> Editar
                                </button>
                                <a href={generatedImage} download="medical-visual.png" className="bg-clinical-600 text-white px-4 py-2 rounded-lg font-bold text-sm hover:bg-clinical-700 shadow-lg">
                                    <i className="fa-solid fa-download"></i>
                                </a>
                            </div>
                        </>
                    ) : (
                        <div className="text-center text-slate-400 dark:text-slate-600 p-6">
                            <i className="fa-solid fa-photo-film text-4xl mb-3 opacity-50"></i>
                            <p className="text-sm font-bold text-slate-500 dark:text-slate-400">As imagens geradas pelo Gemini aparecerão aqui.</p>
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Notas & Efeitos Colaterais</h3>
                <div className="flex flex-col gap-4">
                  {SIDE_EFFECTS.map((effect) => (
                    <div key={effect.id} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 hover:bg-white dark:hover:bg-slate-700/50 hover:shadow-md transition-all flex items-start space-x-4 w-full">
                      <div className="text-2xl sm:text-3xl select-none flex-shrink-0" role="img" aria-label={effect.severity}>
                        {getSeverityEmoji(effect.severity)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white break-words">{effect.name}</h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed font-medium break-words text-justify">{effect.note}</p>
                      </div>
                    </div>
                  ))}
                </div>
            </div>

            {/* CLINICAL HISTORY TIMELINE - GROUPED & MODERN */}
            <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6 flex items-center">
                   <i className="fa-solid fa-clock-rotate-left mr-2 text-clinical-600"></i> Histórico Clínico
                </h3>
                
                <div className="space-y-8">
                  {Object.entries(groupedHistory).map(([date, items], groupIndex) => (
                    <div key={groupIndex} className="relative">
                       {/* Date Header */}
                       <div className="sticky top-0 z-10 flex items-center mb-4">
                          <div className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs px-3 py-1 rounded-full border border-slate-200 dark:border-slate-600 uppercase tracking-wider">
                             {date}
                          </div>
                          <div className="h-px bg-slate-200 dark:bg-slate-700 flex-1 ml-4"></div>
                       </div>

                       {/* Items Group */}
                       <div className="space-y-4 pl-4 border-l-2 border-slate-100 dark:border-slate-700 ml-3">
                          {items.map((item) => {
                             const style = getTimelineStyle(item.type);
                             return (
                               <div key={item.id} className="relative pl-6 group/item">
                                  {/* Dot on line */}
                                  <div className={`absolute -left-[9px] top-5 w-4 h-4 rounded-full border-2 border-white dark:border-slate-800 ${style.bg} shadow-sm z-10 transition-transform group-hover/item:scale-125`}></div>
                                  
                                  {/* Interactive Card */}
                                  <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 hover:shadow-lg transition-all cursor-pointer hover:border-clinical-200 dark:hover:border-clinical-700 group hover:-translate-y-0.5">
                                      <div className="flex justify-between items-start mb-3">
                                          <div className="flex items-center space-x-3">
                                              <span className={`w-10 h-10 rounded-xl flex items-center justify-center ${style.bg} ${style.text} bg-opacity-20 border ${style.border}`}>
                                                  <i className={`fa-solid ${style.icon} text-sm`}></i>
                                              </span>
                                              <div>
                                                  <h4 className="font-bold text-slate-900 dark:text-white text-sm leading-tight group-hover:text-clinical-700 dark:group-hover:text-clinical-400 transition-colors">{item.title}</h4>
                                                  <span className={`text-[9px] uppercase font-bold tracking-wide ${style.text}`}>
                                                      {item.type}
                                                  </span>
                                              </div>
                                          </div>
                                      </div>
                                      <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-medium pl-1">
                                          {item.notes}
                                      </p>
                                  </div>
                               </div>
                             )
                          })}
                       </div>
                    </div>
                  ))}
                </div>
                
                <button className="w-full mt-8 py-3 text-xs font-bold text-slate-500 hover:text-clinical-600 bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-700/50 rounded-xl transition-all border border-slate-100 dark:border-slate-700">
                    Carregar Histórico Completo
                </button>
            </div>
        </div>

      </div>
    </div>
  );
};

export default PatientDetail;
