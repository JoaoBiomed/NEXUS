
import React, { useState } from 'react';
import { MOCK_INVENTORY, MOCK_COMPOUND_STOCK } from '../constants';
import { InventoryItem, CompoundStockItem } from '../types';

const InventoryManager: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'RAW' | 'COMPOUNDS'>('RAW');

  const getStockColor = (percent: number) => {
    if (percent < 30) return 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.4)]';
    if (percent < 60) return 'bg-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.4)]';
    return 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.4)]';
  };

  const VialCard: React.FC<{ item: InventoryItem }> = ({ item }) => {
    const percentage = (item.currentVolume / item.totalVolume) * 100;
    
    return (
      <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 p-6 flex flex-col justify-between hover:shadow-xl hover:border-clinical-300 dark:hover:border-clinical-500 hover:-translate-y-1 transition-all duration-300 group relative overflow-hidden">
        {/* Decorative Background */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-700 dark:to-slate-600 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none opacity-50"></div>
        
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
             <span className={`px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest border ${
                 item.type === 'Vial' ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800' : 
                 item.type === 'Implant' ? 'bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800' : 
                 'bg-orange-50 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-800'
             }`}>
                {item.type === 'Vial' ? 'Frasco' : item.type === 'Implant' ? 'Implante' : 'Oral'}
             </span>
             <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono font-bold bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded border border-slate-200 dark:border-slate-600">#{item.batchNumber}</span>
          </div>
          <h3 className="font-extrabold text-slate-900 dark:text-white text-lg leading-tight mb-1">{item.name}</h3>
          <p className="text-sm text-clinical-700 dark:text-clinical-400 font-bold">{item.concentration}</p>
        </div>

        <div className="mt-8 relative z-10">
          <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-400 mb-2">
            <span>Atual: {item.currentVolume}mL</span>
            <span>Total: {item.totalVolume}mL</span>
          </div>
          {/* Visual Liquid Simulation */}
          <div className="h-5 w-full bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden border border-slate-200 dark:border-slate-700 relative shadow-inner">
             <div 
                className={`h-full ${getStockColor(percentage)} transition-all duration-1000 ease-out relative`}
                style={{ width: `${percentage}%` }}
             >
                <div className="absolute top-0 right-0 h-full w-2 bg-white/30 blur-[2px]"></div>
             </div>
             <div className="absolute top-0 left-0 w-full h-full flex justify-between px-1 pointer-events-none">
                {[...Array(9)].map((_, i) => (
                    <div key={i} className="h-full w-px bg-slate-900/10 dark:bg-white/10"></div>
                ))}
             </div>
          </div>
          <div className="flex justify-between items-center mt-3">
             <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Val: <span className="text-slate-800 dark:text-slate-200 font-bold">{item.expirationDate}</span></p>
             <p className={`text-xs font-black ${percentage < 30 ? 'text-red-600 dark:text-red-400' : 'text-slate-800 dark:text-slate-200'}`}>{percentage.toFixed(0)}%</p>
          </div>
        </div>

        {/* Cost Info */}
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center text-xs">
            <span className="text-slate-400 font-bold uppercase">Custo/mL</span>
            <span className="text-slate-800 dark:text-slate-200 font-bold">R$ {item.costPerMl?.toFixed(2) || '-'}</span>
        </div>

        <div className="mt-6 flex space-x-3 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity duration-200 relative z-10">
            <button className="flex-1 py-2 text-xs border border-slate-300 dark:border-slate-600 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold transition-colors shadow-sm">
                Dosar
            </button>
            <button className="flex-1 py-2 text-xs bg-clinical-700 text-white rounded-xl hover:bg-clinical-800 shadow-lg shadow-clinical-900/20 font-bold transition-colors">
                Repor
            </button>
        </div>
      </div>
    );
  };

  const CompoundCard: React.FC<{ item: CompoundStockItem }> = ({ item }) => {
    const isOutOfStock = item.quantity === 0 || item.status === 'Production';
    const profit = item.sellingPrice - item.costPrice;
    
    return (
        <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 p-0 flex flex-col hover:shadow-xl hover:scale-[1.02] transition-all duration-300 group overflow-hidden relative">
            {/* Contextual Icon Background */}
            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                 {item.category === 'Facial' && <i className="fa-regular fa-face-smile text-6xl text-pink-600"></i>}
                 {item.category === 'Corporal' && <i className="fa-solid fa-child-reaching text-6xl text-orange-600"></i>}
                 {item.category === 'Capilar' && <i className="fa-solid fa-scissors text-6xl text-slate-600"></i>}
                 {item.category === 'Soro' && <i className="fa-solid fa-droplet text-6xl text-cyan-600"></i>}
                 {item.category === 'IM' && <i className="fa-solid fa-dumbbell text-6xl text-blue-600"></i>}
            </div>

            <div className={`h-2 w-full ${
                item.category === 'Facial' ? 'bg-pink-500' : 
                item.category === 'Corporal' ? 'bg-orange-500' : 
                item.category === 'Capilar' ? 'bg-slate-600' : 
                item.category === 'Soro' ? 'bg-cyan-500' :
                'bg-blue-600'
            }`}></div>
            
            <div className="p-6 flex-1 flex flex-col relative z-10">
                <div className="flex justify-between items-start mb-2">
                    <span className={`text-[10px] font-extrabold uppercase px-2 py-1 rounded-md border ${
                        item.category === 'Facial' ? 'bg-pink-50 dark:bg-pink-900/20 text-pink-700 dark:text-pink-300 border-pink-100 dark:border-pink-800' : 
                        item.category === 'Corporal' ? 'bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300 border-orange-100 dark:border-orange-800' : 
                        item.category === 'Capilar' ? 'bg-slate-100 dark:bg-slate-700/50 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-600' : 
                        item.category === 'Soro' ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-700 dark:text-cyan-300 border-cyan-100 dark:border-cyan-800' :
                        'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-100 dark:border-blue-800'
                    }`}>
                        {item.category}
                    </span>
                    <span className={`flex items-center space-x-1 text-[10px] font-extrabold uppercase px-2 py-1 rounded-md border ${
                        item.quantity === 0 ? 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600' :
                        item.quantity < 5 ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 border-red-100 dark:border-red-800' : 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 border-emerald-100 dark:border-emerald-800'
                    }`}>
                        <i className={`fa-solid ${item.quantity === 0 ? 'fa-clock' : item.quantity < 5 ? 'fa-triangle-exclamation' : 'fa-check'}`}></i>
                        <span>{item.quantity === 0 ? 'Produção' : item.quantity < 5 ? 'Baixo' : 'Ok'}</span>
                    </span>
                </div>

                <h3 className="font-extrabold text-slate-900 dark:text-white text-lg leading-tight mb-1">{item.name}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 font-medium line-clamp-2 min-h-[2.5em]">{item.description}</p>

                <div className="mt-6 flex items-end justify-between">
                    <div>
                        <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wide">Em Estoque</p>
                        <p className={`text-3xl font-black ${isOutOfStock ? 'text-slate-300 dark:text-slate-600' : 'text-slate-900 dark:text-white'}`}>{item.quantity} <span className="text-sm text-slate-400 font-bold">unid.</span></p>
                    </div>
                    <div className="text-right">
                         <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wide">Preço Venda</p>
                         <p className="text-lg font-bold text-clinical-700 dark:text-clinical-400">R$ {item.sellingPrice}</p>
                    </div>
                </div>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 flex flex-col gap-2 relative z-10">
                {/* Profit Indicator */}
                <div className="flex justify-between items-center text-xs mb-2 px-1">
                    <span className="text-slate-500 dark:text-slate-400 font-bold">Lucro/Unid:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-black">R$ {profit}</span>
                </div>
                
                {isOutOfStock ? (
                     <button className="w-full py-2 bg-gradient-to-r from-slate-700 to-slate-900 text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center group-hover:scale-105 active:scale-95">
                        <i className="fa-solid fa-industry mr-2"></i> Encomendar Manipulação
                     </button>
                ) : (
                    <div className="flex space-x-2">
                        <button className="flex-1 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors">
                            Usar
                        </button>
                        <button className="flex-1 py-2 bg-clinical-100 dark:bg-clinical-900/40 text-clinical-700 dark:text-clinical-300 rounded-xl text-xs font-bold hover:bg-clinical-200 dark:hover:bg-clinical-900/60 transition-colors">
                            Repor
                        </button>
                    </div>
                )}
            </div>
            
            {/* Parceiro Indicator */}
            <div className="absolute bottom-1 right-1 opacity-10 pointer-events-none">
                <i className="fa-solid fa-mortar-pestle text-4xl dark:text-white"></i>
            </div>
        </div>
    );
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto animate-fade-in pb-12">
       
       {/* Header Section with Glass Effect */}
       <div className="relative bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-3xl p-8 border border-white dark:border-slate-700 shadow-soft flex flex-col md:flex-row justify-between items-end md:items-center gap-6">
         <div className="relative z-10">
            <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">Farmácia Central</h2>
            <p className="text-slate-600 dark:text-slate-400 mt-2 font-semibold">Gestão inteligente de insumos e fórmulas manipuladas.</p>
         </div>
         
         <div className="relative z-10 flex flex-col sm:flex-row gap-4 w-full md:w-auto">
             {/* Tab Switcher */}
             <div className="bg-slate-100 dark:bg-slate-900 p-1 rounded-xl flex shadow-inner">
                <button 
                    onClick={() => setActiveTab('RAW')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'RAW' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                >
                    Matéria Prima
                </button>
                <button 
                    onClick={() => setActiveTab('COMPOUNDS')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'COMPOUNDS' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                >
                    Fórmulas
                </button>
             </div>

            <div className="relative">
                <i className="fa-solid fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400"></i>
                <input 
                    type="text" 
                    placeholder={activeTab === 'RAW' ? "Buscar insumo..." : "Buscar fórmula..."}
                    className="pl-11 pr-4 py-3 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-xl focus:ring-2 focus:ring-clinical-500 focus:border-clinical-500 w-full sm:w-64 shadow-sm transition-all text-sm font-semibold text-slate-900 dark:text-white placeholder-slate-400"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
         </div>
       </div>

       {activeTab === 'RAW' ? (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 animate-fade-in">
             {MOCK_INVENTORY
                .filter(i => i.name.toLowerCase().includes(searchTerm.toLowerCase()))
                .map(item => (
                <VialCard key={item.id} item={item} />
             ))}
           </div>
       ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 animate-fade-in">
                {MOCK_COMPOUND_STOCK
                    .filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
                    .map(item => (
                    <CompoundCard key={item.id} item={item} />
                ))}
                
                {/* Add New Compound Card */}
                <div className="bg-slate-50 dark:bg-slate-800/50 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-white dark:hover:bg-slate-800 hover:border-clinical-400 dark:hover:border-clinical-500 transition-all group min-h-[250px]">
                    <div className="w-16 h-16 bg-white dark:bg-slate-700 rounded-full flex items-center justify-center shadow-sm text-slate-300 dark:text-slate-500 group-hover:text-clinical-600 dark:group-hover:text-clinical-400 group-hover:shadow-md transition-all mb-4 border border-slate-200 dark:border-slate-600">
                        <i className="fa-solid fa-plus text-2xl"></i>
                    </div>
                    <p className="font-bold text-slate-400 dark:text-slate-500 group-hover:text-clinical-700 dark:group-hover:text-clinical-400 transition-colors">Novo Complexo</p>
                    <p className="text-xs text-center text-slate-500 dark:text-slate-400 font-medium mt-2 px-4">Cadastrar kit pré-montado ou fórmula externa.</p>
                </div>
            </div>
       )}
       
       {/* Footer Partner Info */}
       <div className="flex items-center justify-center mt-8 space-x-3 text-slate-400">
            <i className="fa-solid fa-handshake-simple"></i>
            <span className="text-xs font-bold uppercase tracking-widest">Integrado com PharmaLabs™ Manipulation</span>
       </div>
    </div>
  );
};

export default InventoryManager;
