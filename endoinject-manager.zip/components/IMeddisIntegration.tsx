import React, { useState } from 'react';
import { MOCK_PATIENTS } from '../constants';
import { Patient } from '../types';

// Mock Data Interfaces for iMeddis
interface GeneticMarker {
  gene: string;
  result: string;
  impact: string;
  recommendation: string;
  riskLevel: 'Low' | 'Medium' | 'High';
}

interface CortexAnalysis {
  optimizationScore: number;
  pharmacogenetics: {
    alertTitle: string;
    alertDescription: string;
    suggestion: string;
    gene: string;
  }[];
  metabolicMarkers: GeneticMarker[];
}

const IMeddisIntegration: React.FC = () => {
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState<CortexAnalysis | null>(null);

  const selectedPatient = MOCK_PATIENTS.find(p => p.id === selectedPatientId);

  // SIMULATION: Cortex Engine Logic
  const runCortexAnalysis = () => {
    if (!selectedPatient) return;

    setIsAnalyzing(true);
    setAnalysisData(null);

    // Simulate "Thinking" time of the Cortex
    setTimeout(() => {
      let result: CortexAnalysis;

      // Logic based on current protocol to simulate real cross-referencing
      if (selectedPatient.currentProtocol.includes('Testosterona') || selectedPatient.gender === 'Male') {
        result = {
          optimizationScore: 78,
          pharmacogenetics: [
            {
              alertTitle: 'Alerta de Aromatização Rápida',
              alertDescription: 'Polimorfismo CYP19A1 detectado. Alta conversão periférica de T em E2.',
              suggestion: 'Associar Inibidor de Aromatase (Anastrozol) em dose baixa ou fracionar aplicações.',
              gene: 'CYP19A1'
            },
            {
              alertTitle: 'Risco de Poliglobulia',
              alertDescription: 'Sensibilidade aumentada à eritropoiese androgênica.',
              suggestion: 'Monitorar Hematócrito a cada 45 dias. Considerar sangria terapêutica se > 54%.',
              gene: 'EPOR'
            }
          ],
          metabolicMarkers: [
            { gene: 'AR (Receptor)', result: 'Sensibilidade Média', impact: 'Resposta hipertrófica padrão.', recommendation: 'Manter dose supra-fisiológica para anabolismo.', riskLevel: 'Low' },
            { gene: 'COMT', result: 'Metabolismo Lento', impact: 'Acúmulo de catecolaminas (Stress).', recommendation: 'Evitar estimulantes potentes no pré-treino.', riskLevel: 'Medium' }
          ]
        };
      } else if (selectedPatient.currentProtocol.includes('Gestrinona') || selectedPatient.gender === 'Female') {
        result = {
          optimizationScore: 92,
          pharmacogenetics: [
             {
              alertTitle: 'Perfil Lipídico Adverso',
              alertDescription: 'Tendência genética a redução acentuada de HDL com andrógenos.',
              suggestion: 'Aumentar aporte de Omega-3 (4g/dia) e incluir Niacina.',
              gene: 'LIPC'
            }
          ],
          metabolicMarkers: [
            { gene: 'SHBG', result: 'Baixa Afinidade', impact: 'Maior fração livre hormonal.', recommendation: 'Doses menores geram grandes resultados.', riskLevel: 'Low' },
            { gene: 'CYP3A4', result: 'Metabolização Rápida', impact: 'Depuração acelerada do implante.', recommendation: 'Reduzir intervalo de troca do implante.', riskLevel: 'High' }
          ]
        };
      } else {
        // Default / GH / Others
        result = {
          optimizationScore: 85,
          pharmacogenetics: [
            {
                alertTitle: 'Resistência à Insulina',
                alertDescription: 'Variante TCF7L2 associada a menor sensibilidade à insulina.',
                suggestion: 'Associar Metformina ou Berberina ao protocolo de GH.',
                gene: 'TCF7L2'
            }
          ],
          metabolicMarkers: [
            { gene: 'ACTN3', result: 'Tipo RR (Força)', impact: 'Explosão muscular favorecida.', recommendation: 'Focar treinos tensionais.', riskLevel: 'Low' },
            { gene: 'FTO', result: 'Risco Obesidade', impact: 'Apetite aumentado.', recommendation: 'Controle rigoroso de carga glicêmica.', riskLevel: 'Medium' }
          ]
        };
      }

      setAnalysisData(result);
      setIsAnalyzing(false);
    }, 2500);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-fade-in pb-12">
      
      {/* NEXUS HEADER - Immersive Experience */}
      <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-slate-900 min-h-[300px] flex flex-col items-center justify-center text-center p-8 border border-slate-800">
          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
              {/* Grid Overlay */}
              <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
          </div>

          <div className="relative z-10 space-y-4">
              <div className="inline-flex items-center space-x-2 bg-slate-800/80 backdrop-blur-md border border-slate-700 rounded-full px-4 py-1.5 shadow-lg">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)] animate-pulse"></div>
                  <span className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-emerald-100">Sistema Cortex: Ativo</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
                INTELIGÊNCIA <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-emerald-400">iMEDDIS</span>
              </h1>
              <p className="text-slate-400 font-medium max-w-2xl mx-auto text-lg">
                Mapeamento Genômico & Farmacogenética de Precisão.
              </p>
          </div>
      </div>

      {/* CONTROL STATION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 -mt-16 relative z-20 px-4 md:px-0">
          
          {/* LEFT: Patient Selector Node */}
          <div className="lg:col-span-4 flex flex-col space-y-4">
              <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-soft border border-slate-200 p-6 flex-1">
                  <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4 flex items-center">
                     <i className="fa-solid fa-users-viewfinder mr-2"></i> Seleção de Paciente
                  </h3>
                  
                  <div className="space-y-3 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
                      {MOCK_PATIENTS.map(p => (
                          <button
                            key={p.id}
                            onClick={() => { setSelectedPatientId(p.id); setAnalysisData(null); }}
                            className={`w-full flex items-center p-3 rounded-2xl border transition-all duration-200 group relative overflow-hidden ${
                                selectedPatientId === p.id 
                                ? 'bg-slate-900 border-slate-800 shadow-lg scale-[1.02]' 
                                : 'bg-slate-50 border-slate-100 hover:bg-white hover:border-slate-300'
                            }`}
                          >
                              <img src={p.avatar} className={`w-12 h-12 rounded-xl object-cover ring-2 transition-all ${selectedPatientId === p.id ? 'ring-teal-500' : 'ring-transparent'}`} alt={p.name} />
                              <div className="ml-4 text-left">
                                  <p className={`font-bold text-sm ${selectedPatientId === p.id ? 'text-white' : 'text-slate-800'}`}>{p.name}</p>
                                  <p className={`text-[10px] font-semibold uppercase ${selectedPatientId === p.id ? 'text-slate-400' : 'text-slate-500'}`}>{p.currentProtocol.substring(0, 25)}...</p>
                              </div>
                              {selectedPatientId === p.id && (
                                  <div className="absolute right-4 text-teal-400 animate-pulse">
                                      <i className="fa-solid fa-link"></i>
                                  </div>
                              )}
                          </button>
                      ))}
                  </div>
              </div>
          </div>

          {/* RIGHT: Action & Results Core */}
          <div className="lg:col-span-8 flex flex-col">
              <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-soft border border-slate-200 p-8 min-h-[400px] flex flex-col justify-center items-center text-center relative overflow-hidden transition-all">
                  
                  {!selectedPatient ? (
                      // IDLE STATE
                      <div className="opacity-50 space-y-4">
                          <i className="fa-solid fa-dna text-6xl text-slate-300"></i>
                          <p className="text-slate-500 font-bold">Selecione um paciente à esquerda para iniciar o sequenciamento.</p>
                      </div>
                  ) : !analysisData ? (
                      // READY STATE
                      <div className="w-full h-full flex flex-col items-center justify-center animate-fade-in relative z-10">
                          <div className="flex items-center space-x-6 mb-8 bg-slate-50 p-4 rounded-2xl border border-slate-200 w-full max-w-lg">
                              <div className="flex-1 text-right">
                                  <p className="text-[10px] font-extrabold text-slate-400 uppercase">Protocolo Ativo</p>
                                  <p className="font-bold text-slate-900">{selectedPatient.currentProtocol}</p>
                              </div>
                              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-400">
                                  <i className="fa-solid fa-arrow-right-arrow-left text-xs"></i>
                              </div>
                              <div className="flex-1 text-left">
                                  <p className="text-[10px] font-extrabold text-slate-400 uppercase">Banco iMeddis</p>
                                  <p className="font-bold text-teal-700">DNA Mapeado</p>
                              </div>
                          </div>

                          <button 
                            onClick={runCortexAnalysis}
                            disabled={isAnalyzing}
                            className={`group relative px-10 py-5 bg-slate-900 text-white font-bold rounded-2xl shadow-xl shadow-slate-900/20 overflow-hidden transition-all transform hover:scale-105 active:scale-95 disabled:cursor-wait ${isAnalyzing ? 'w-full max-w-md' : ''}`}
                          >
                              <div className={`absolute inset-0 bg-gradient-to-r from-teal-600 via-emerald-600 to-teal-600 opacity-0 group-hover:opacity-20 transition-opacity duration-500 ${isAnalyzing ? 'animate-pulse opacity-20' : ''}`}></div>
                              
                              {isAnalyzing ? (
                                  <div className="flex items-center justify-center space-x-3">
                                      <span className="relative flex h-3 w-3">
                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                                        <span className="relative inline-flex rounded-full h-3 w-3 bg-teal-500"></span>
                                      </span>
                                      <span>Cruzando Polimorfismos...</span>
                                  </div>
                              ) : (
                                  <span className="flex items-center text-lg tracking-wide">
                                      <i className="fa-solid fa-microchip mr-3 text-emerald-400"></i>
                                      EXECUTAR VARREDURA GENÔMICA
                                  </span>
                              )}
                          </button>
                      </div>
                  ) : (
                      // RESULTS DASHBOARD (ENHANCED)
                      <div className="w-full animate-fade-in text-left">
                           <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-100">
                                <div className="flex items-center space-x-3">
                                    <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center border border-teal-200">
                                        <i className="fa-solid fa-check"></i>
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-slate-900">Análise Genômica Concluída</h3>
                                        <p className="text-xs text-slate-500 font-semibold">Cortex V3.1 • Ref: {selectedPatient.id.substring(0,4)}</p>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => setAnalysisData(null)} 
                                    className="text-xs font-bold text-slate-400 hover:text-slate-700"
                                >
                                    Nova Análise
                                </button>
                           </div>

                           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                {/* Score Card */}
                                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex items-center justify-between relative overflow-hidden">
                                    <div className="absolute top-0 right-0 p-4 opacity-5">
                                        <i className="fa-solid fa-chart-line text-6xl"></i>
                                    </div>
                                    <div className="relative z-10">
                                        <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Compatibilidade Genética</p>
                                        <h4 className="text-4xl font-black text-slate-900 mt-1">{analysisData.optimizationScore}<span className="text-lg text-slate-400">/100</span></h4>
                                        <p className="text-xs font-bold text-emerald-600 mt-1">Alta Sinergia</p>
                                    </div>
                                    <div className="h-16 w-16 relative z-10">
                                        <svg className="w-full h-full transform -rotate-90">
                                            <circle cx="32" cy="32" r="28" stroke="#cbd5e1" strokeWidth="6" fill="none" />
                                            <circle 
                                                cx="32" cy="32" r="28" 
                                                stroke={analysisData.optimizationScore > 80 ? '#0d9488' : '#eab308'} 
                                                strokeWidth="6" 
                                                fill="none" 
                                                strokeDasharray={2 * Math.PI * 28} 
                                                strokeDashoffset={2 * Math.PI * 28 * (1 - analysisData.optimizationScore / 100)} 
                                                strokeLinecap="round"
                                            />
                                        </svg>
                                    </div>
                                </div>

                                {/* Main Pharmacogenetic Alert */}
                                {analysisData.pharmacogenetics.length > 0 && (
                                    <div className="bg-amber-50 p-5 rounded-2xl border border-amber-100 flex flex-col justify-center relative overflow-hidden">
                                         <div className="absolute right-0 top-0 w-16 h-16 bg-amber-200 rounded-bl-full opacity-20"></div>
                                         <div className="flex items-center space-x-2 mb-2 relative z-10">
                                             <div className="w-5 h-5 rounded-full bg-amber-200 flex items-center justify-center text-amber-600">
                                                 <i className="fa-solid fa-triangle-exclamation text-[10px]"></i>
                                             </div>
                                             <span className="text-[10px] font-extrabold text-amber-700 uppercase">Interação Crítica Detectada</span>
                                         </div>
                                         <p className="font-bold text-slate-900 text-sm leading-tight relative z-10">{analysisData.pharmacogenetics[0].alertTitle}</p>
                                         <p className="text-xs text-slate-600 mt-1 font-medium relative z-10">Gene: <span className="font-bold text-amber-800">{analysisData.pharmacogenetics[0].gene}</span></p>
                                         <p className="text-xs text-amber-900 mt-2 bg-amber-100/50 p-2 rounded-lg border border-amber-200/50">
                                             <i className="fa-solid fa-user-doctor mr-1"></i>
                                             {analysisData.pharmacogenetics[0].suggestion}
                                         </p>
                                    </div>
                                )}
                           </div>

                           {/* Detailed Gene Cards */}
                           <div>
                                <h4 className="text-xs font-extrabold text-slate-500 uppercase mb-3 flex items-center">
                                    <i className="fa-solid fa-dna mr-2"></i> Marcadores Metabólicos
                                </h4>
                                <div className="grid grid-cols-1 gap-3">
                                    {analysisData.metabolicMarkers.map((marker, i) => (
                                        <div key={i} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-white rounded-xl border border-slate-200 shadow-sm hover:border-teal-200 transition-colors">
                                            <div className="mb-2 sm:mb-0">
                                                <div className="flex items-center space-x-2">
                                                    <span className="font-black text-slate-800 text-sm">{marker.gene}</span>
                                                    <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded ${
                                                        marker.riskLevel === 'Low' ? 'bg-emerald-100 text-emerald-700' : 
                                                        marker.riskLevel === 'Medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                                                    }`}>{marker.riskLevel === 'Low' ? 'Favorável' : marker.riskLevel === 'Medium' ? 'Atenção' : 'Risco'}</span>
                                                </div>
                                                <p className="text-xs text-slate-500 font-medium mt-1">{marker.impact}</p>
                                            </div>
                                            <div className="w-full sm:w-auto bg-slate-50 px-3 py-2 rounded-lg border border-slate-100">
                                                <p className="text-[10px] text-slate-400 font-extrabold uppercase mb-0.5">Recomendação Clínica</p>
                                                <p className="text-xs font-bold text-teal-700">{marker.recommendation}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                           </div>
                      </div>
                  )}
              </div>
          </div>
      </div>
    </div>
  );
};

export default IMeddisIntegration;