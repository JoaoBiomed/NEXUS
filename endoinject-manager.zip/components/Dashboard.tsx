
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_PATIENTS, MOCK_INVENTORY, MOCK_COMPOUND_STOCK } from '../constants';
import { Patient } from '../types';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  // --- REGISTRATION STATE ---
  const [isRegModalOpen, setIsRegModalOpen] = useState(false);
  const [regCPF, setRegCPF] = useState('');
  const [regStep, setRegStep] = useState<'INPUT' | 'SEARCHING' | 'CONFIRM'>('INPUT');
  const [searchProgress, setSearchProgress] = useState({ imeddis: 0, labpro: 0 });
  const [foundPatient, setFoundPatient] = useState<Partial<Patient> | null>(null);

  const criticalStock = MOCK_INVENTORY.filter(i => (i.currentVolume / i.totalVolume) < 0.3);
  const criticalPatients = MOCK_PATIENTS.filter(p => p.status === 'Critical');

  // --- FINANCIAL CALCULATIONS ---
  const rawMaterialValue = MOCK_INVENTORY.reduce((acc, item) => acc + (item.currentVolume * item.costPerMl), 0);
  const compoundsValue = MOCK_COMPOUND_STOCK.reduce((acc, item) => acc + (item.quantity * item.costPrice), 0);
  const totalInvestedStock = rawMaterialValue + compoundsValue;
  const potentialRevenue = MOCK_COMPOUND_STOCK.reduce((acc, item) => acc + (item.quantity * item.sellingPrice), 0);
  const potentialProfit = potentialRevenue - compoundsValue;
  const profitMargin = potentialRevenue > 0 ? (potentialProfit / potentialRevenue) * 100 : 0;

  const filteredPatients = MOCK_PATIENTS.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.currentProtocol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handlePatientClick = (patient: any) => {
    navigate('/patients', { state: { patientData: patient } });
  };

  // --- REGISTRATION LOGIC ---
  const startRegistration = () => {
      if(!regCPF) return;
      setRegStep('SEARCHING');
      
      const imeddisInterval = setInterval(() => {
          setSearchProgress(prev => {
              if (prev.imeddis >= 100) {
                  clearInterval(imeddisInterval);
                  return prev;
              }
              return { ...prev, imeddis: prev.imeddis + 10 };
          });
      }, 200);

      setTimeout(() => {
        const labproInterval = setInterval(() => {
            setSearchProgress(prev => {
                if (prev.labpro >= 100) {
                    clearInterval(labproInterval);
                    return prev;
                }
                return { ...prev, labpro: prev.labpro + 20 };
            });
        }, 300);
      }, 1000);

      setTimeout(() => {
          setFoundPatient({
              name: 'Novo Paciente Mock',
              cpf: regCPF,
              age: 32,
              gender: 'Female',
              avatar: `https://ui-avatars.com/api/?name=NP&background=random`,
              status: 'Active',
              currentProtocol: 'Análise Inicial',
              lastVisit: new Date().toLocaleDateString(),
              nextRenewal: '-',
              photos: []
          });
          setRegStep('CONFIRM');
      }, 3500);
  };

  const confirmRegistration = () => {
      if (foundPatient) {
          setIsRegModalOpen(false);
          setRegStep('INPUT');
          setRegCPF('');
          setSearchProgress({ imeddis: 0, labpro: 0 });
          navigate('/patients', { state: { patientData: foundPatient } });
      }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto relative">
      
      {/* --- REGISTRATION MODAL --- */}
      {isRegModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
              <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-fade-in border border-slate-200 dark:border-slate-700">
                  <div className="bg-slate-50 dark:bg-slate-900 px-8 py-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
                      <h3 className="text-xl font-black text-slate-900 dark:text-white">Admissão de Paciente</h3>
                      <button onClick={() => setIsRegModalOpen(false)} className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                          <i className="fa-solid fa-times text-xl"></i>
                      </button>
                  </div>

                  <div className="p-8">
                      {regStep === 'INPUT' && (
                          <div className="space-y-6">
                              <p className="text-sm text-slate-600 dark:text-slate-300 font-medium">Insira o CPF para buscar o histórico unificado nas bases NEXUS.</p>
                              <div>
                                  <label className="text-xs font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">CPF</label>
                                  <input 
                                    type="text" 
                                    placeholder="000.000.000-00"
                                    className="w-full mt-2 p-4 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-2xl text-lg font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-clinical-600 outline-none"
                                    value={regCPF}
                                    onChange={(e) => setRegCPF(e.target.value)}
                                  />
                              </div>
                              <button 
                                onClick={startRegistration}
                                className="w-full py-4 bg-clinical-900 text-white font-bold rounded-2xl shadow-xl hover:bg-clinical-800 transition-all flex items-center justify-center"
                              >
                                  <i className="fa-solid fa-satellite-dish mr-2"></i>
                                  Buscar Integração
                              </button>
                          </div>
                      )}

                      {regStep === 'SEARCHING' && (
                          <div className="space-y-8 py-4">
                              <div className="space-y-2">
                                  <div className="flex justify-between text-xs font-bold uppercase text-teal-700 dark:text-teal-400">
                                      <span>Base Genética (iMeddis)</span>
                                      <span>{searchProgress.imeddis}%</span>
                                  </div>
                                  <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                                      <div className="h-full bg-teal-500 transition-all duration-300" style={{width: `${searchProgress.imeddis}%`}}></div>
                                  </div>
                              </div>
                              <div className="space-y-2">
                                  <div className="flex justify-between text-xs font-bold uppercase text-blue-700 dark:text-blue-400">
                                      <span>Histórico de Exames (LabPro)</span>
                                      <span>{searchProgress.labpro}%</span>
                                  </div>
                                  <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                                      <div className="h-full bg-blue-500 transition-all duration-300" style={{width: `${searchProgress.labpro}%`}}></div>
                                  </div>
                              </div>
                              <div className="flex items-center justify-center text-slate-400 text-sm font-bold animate-pulse">
                                  <i className="fa-solid fa-circle-notch fa-spin mr-2"></i> Sincronizando Prontuários...
                              </div>
                          </div>
                      )}

                      {regStep === 'CONFIRM' && foundPatient && (
                          <div className="text-center space-y-6">
                              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600 text-3xl shadow-sm">
                                  <i className="fa-solid fa-check"></i>
                              </div>
                              <div>
                                  <h4 className="text-xl font-bold text-slate-900 dark:text-white">Paciente Localizado</h4>
                                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Histórico completo importado com sucesso.</p>
                              </div>
                              <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 text-left flex items-center space-x-4">
                                  <div className="w-12 h-12 bg-slate-200 rounded-full"></div>
                                  <div>
                                      <p className="font-bold text-slate-900 dark:text-white">{foundPatient.name}</p>
                                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">CPF: {foundPatient.cpf}</p>
                                  </div>
                              </div>
                              <button 
                                onClick={confirmRegistration}
                                className="w-full py-4 bg-emerald-600 text-white font-bold rounded-2xl shadow-xl hover:bg-emerald-700 transition-all"
                              >
                                  Confirmar Admissão
                              </button>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}

      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex-1">
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white">Painel de Controle</h2>
          <p className="text-slate-600 dark:text-slate-400 font-medium mt-1">Resumo clínico e inteligência financeira.</p>
        </div>
        
        {/* Search Bar Integration */}
        <div className="w-full md:w-auto flex-1 max-w-md relative z-10">
            <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i className="fa-solid fa-search text-slate-400 group-focus-within:text-clinical-600 transition-colors"></i>
                </div>
                <input 
                    type="text" 
                    className="block w-full pl-11 pr-4 py-3 border border-slate-300 dark:border-slate-600 rounded-2xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-clinical-600 focus:border-transparent shadow-sm transition-all" 
                    placeholder="Buscar paciente por nome ou protocolo..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                    <button 
                        onClick={() => setSearchTerm('')}
                        className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                    >
                        <i className="fa-solid fa-times"></i>
                    </button>
                )}
            </div>
        </div>

        <div className="flex space-x-3 hidden md:flex">
             <button className="px-5 py-2.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm transition-all hover:text-slate-900 dark:hover:text-white">
                <i className="fa-solid fa-calendar mr-2 text-slate-500 dark:text-slate-400"></i> Agenda
             </button>
             {/* High Contrast Button for "New Patient" with Modal Trigger */}
             <button 
                onClick={() => setIsRegModalOpen(true)}
                className="px-5 py-2.5 bg-white dark:bg-slate-800 border-2 border-slate-900 dark:border-white text-slate-900 dark:text-white rounded-xl text-sm font-black hover:bg-slate-100 dark:hover:bg-slate-700 shadow-md transition-all transform hover:-translate-y-0.5 flex items-center"
             >
                <i className="fa-solid fa-plus mr-2 font-black"></i> Novo Paciente
             </button>
        </div>
      </header>

      {/* Conditional Rendering: Search Results vs Dashboard Widgets */}
      {searchTerm ? (
        <div className="animate-fade-in">
            <div className="flex items-center space-x-3 mb-6">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Resultados da Busca</h3>
                <span className="bg-clinical-100 dark:bg-clinical-900/50 text-clinical-800 dark:text-clinical-300 text-xs font-bold px-2 py-1 rounded-full border border-clinical-200 dark:border-clinical-800">
                    {filteredPatients.length} encontrado(s)
                </span>
            </div>

            {filteredPatients.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredPatients.map(patient => (
                        <div 
                            key={patient.id} 
                            onClick={() => handlePatientClick(patient)}
                            className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-soft border border-slate-200 dark:border-slate-700 hover:border-clinical-500 hover:shadow-xl transition-all cursor-pointer group relative overflow-hidden"
                        >
                             <div className="absolute top-0 right-0 w-24 h-24 bg-clinical-50 dark:bg-clinical-900/20 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                             
                             <div className="flex items-center space-x-4 mb-4 relative z-10">
                                <img src={patient.avatar} alt={patient.name} className="w-16 h-16 rounded-full object-cover ring-4 ring-slate-50 dark:ring-slate-700 shadow-md border border-slate-100 dark:border-slate-600" />
                                <div>
                                    <h4 className="font-bold text-lg text-slate-900 dark:text-white leading-tight group-hover:text-clinical-700 dark:group-hover:text-clinical-400 transition-colors">{patient.name}</h4>
                                    <p className="text-sm text-slate-600 dark:text-slate-400 font-semibold">{patient.age} anos</p>
                                </div>
                             </div>

                             <div className="space-y-3 relative z-10">
                                 <div>
                                     <p className="text-[11px] uppercase font-extrabold text-slate-500 dark:text-slate-400 tracking-wider">Protocolo Atual</p>
                                     <p className="text-sm font-bold text-slate-800 dark:text-slate-200 truncate">{patient.currentProtocol}</p>
                                 </div>
                                 <div className="flex justify-between items-center pt-2">
                                     <span className={`px-2.5 py-1 rounded-md text-xs font-extrabold uppercase tracking-wide border ${
                                         patient.status === 'Active' ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800' :
                                         patient.status === 'Critical' ? 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 border-red-200 dark:border-red-800' :
                                         'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                                     }`}>
                                         {patient.status === 'Active' ? 'Ativo' : patient.status === 'Critical' ? 'Crítico' : 'Manutenção'}
                                     </span>
                                     <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 group-hover:bg-clinical-600 group-hover:text-white transition-all">
                                         <i className="fa-solid fa-chevron-right text-xs"></i>
                                     </div>
                                 </div>
                             </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-20 bg-white dark:bg-slate-800 rounded-3xl border-2 border-dashed border-slate-300 dark:border-slate-700">
                    <i className="fa-solid fa-user-slash text-4xl text-slate-300 dark:text-slate-600 mb-4"></i>
                    <p className="text-slate-600 dark:text-slate-400 font-bold">Nenhum paciente encontrado para "{searchTerm}"</p>
                </div>
            )}
        </div>
      ) : (
        <>
            {/* --- FINANCIAL HEALTH SECTION --- */}
            <div className="bg-gradient-to-r from-slate-900 to-slate-800 dark:from-slate-950 dark:to-slate-900 rounded-3xl p-8 shadow-xl text-white relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-96 h-96 bg-white opacity-5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
                 <div className="relative z-10">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold flex items-center">
                            <i className="fa-solid fa-sack-dollar text-emerald-400 mr-3 text-2xl"></i>
                            Saúde Financeira da Clínica
                        </h3>
                        <span className="bg-emerald-500/20 text-emerald-300 text-xs font-bold px-3 py-1 rounded-full border border-emerald-500/30">
                            Projeção Baseada em Estoque
                        </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {/* Revenue */}
                        <div className="bg-white/5 p-5 rounded-2xl border border-white/10">
                            <p className="text-slate-400 text-xs font-extrabold uppercase tracking-widest mb-1">Potencial de Receita</p>
                            <h4 className="text-3xl font-black text-white">R$ {potentialRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h4>
                            <p className="text-xs text-slate-400 mt-2 font-medium">
                                Valor total de venda dos complexos prontos em estoque.
                            </p>
                        </div>

                        {/* Cost */}
                        <div className="bg-white/5 p-5 rounded-2xl border border-white/10">
                            <p className="text-slate-400 text-xs font-extrabold uppercase tracking-widest mb-1">Custo Investido</p>
                            <h4 className="text-3xl font-black text-white">R$ {totalInvestedStock.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h4>
                            <p className="text-xs text-slate-400 mt-2 font-medium">
                                Soma de matéria prima e produtos acabados.
                            </p>
                        </div>

                        {/* Profit */}
                        <div className="bg-emerald-500/10 p-5 rounded-2xl border border-emerald-500/30 relative overflow-hidden">
                             <div className="absolute -right-6 -bottom-6 text-emerald-500/10 text-8xl">
                                 <i className="fa-solid fa-chart-line"></i>
                             </div>
                            <p className="text-emerald-300 text-xs font-extrabold uppercase tracking-widest mb-1">Lucro Projetado</p>
                            <h4 className="text-3xl font-black text-emerald-400">R$ {potentialProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h4>
                            <div className="flex items-center mt-2">
                                <span className="bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded mr-2">
                                    +{profitMargin.toFixed(0)}% Margem
                                </span>
                                <span className="text-xs text-emerald-200/70 font-medium">Média Global</span>
                            </div>
                        </div>
                    </div>
                 </div>
            </div>

            {/* Standard Dashboard Content */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Critical Alerts */}
                <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 overflow-hidden flex flex-col">
                <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900">
                    <h3 className="font-bold text-lg text-slate-900 dark:text-white flex items-center">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-600 mr-3 animate-pulse ring-2 ring-red-200 dark:ring-red-900"></div>
                    Alertas Críticos
                    </h3>
                    <button className="text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-clinical-700 dark:hover:text-clinical-400 uppercase tracking-wide">Ver todos</button>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-700 flex-1">
                    {criticalPatients.map(p => (
                    <div key={p.id} onClick={() => handlePatientClick(p)} className="px-8 py-5 flex items-center justify-between hover:bg-red-50/50 dark:hover:bg-red-900/10 transition-colors cursor-pointer group">
                        <div className="flex items-center space-x-4">
                        <div className="relative">
                            <img src={p.avatar} className="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-slate-700 shadow-sm border border-slate-200 dark:border-slate-600" alt={p.name} />
                            <div className="absolute -bottom-1 -right-1 bg-red-600 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full border-2 border-white dark:border-slate-800 font-bold">!</div>
                        </div>
                        <div>
                            <p className="font-bold text-slate-900 dark:text-white group-hover:text-clinical-700 dark:group-hover:text-clinical-400 transition-colors">{p.name}</p>
                            <p className="text-xs text-red-700 dark:text-red-400 font-bold bg-red-50 dark:bg-red-900/30 px-2 py-1 rounded-md inline-block mt-1 border border-red-100 dark:border-red-900/50">Hematócrito Elevado (54%)</p>
                        </div>
                        </div>
                        <button className="text-sm bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 px-4 py-2 rounded-lg text-slate-700 dark:text-slate-200 font-bold hover:border-clinical-500 hover:text-clinical-700 transition-all shadow-sm">
                            Ver Exames
                        </button>
                    </div>
                    ))}
                    {criticalStock.map(s => (
                    <div key={s.id} className="px-8 py-5 flex items-center justify-between hover:bg-yellow-50/50 dark:hover:bg-yellow-900/10 transition-colors cursor-pointer group">
                        <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-orange-600 dark:text-orange-400 ring-2 ring-white dark:ring-slate-700 shadow-sm border border-orange-200 dark:border-orange-900/50">
                            <i className="fa-solid fa-flask"></i>
                        </div>
                        <div>
                            <p className="font-bold text-slate-900 dark:text-white group-hover:text-clinical-700 dark:group-hover:text-clinical-400 transition-colors">{s.name}</p>
                            <p className="text-xs text-orange-700 dark:text-orange-400 font-bold bg-orange-50 dark:bg-orange-900/30 px-2 py-1 rounded-md inline-block mt-1 border border-orange-100 dark:border-orange-900/50">Estoque Baixo: {((s.currentVolume/s.totalVolume)*100).toFixed(0)}% restante</p>
                        </div>
                        </div>
                        <button className="text-sm bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 px-4 py-2 rounded-lg text-slate-700 dark:text-slate-200 font-bold hover:border-clinical-500 hover:text-clinical-700 transition-all shadow-sm">
                            Repor
                        </button>
                    </div>
                    ))}
                </div>
                </div>

                {/* Schedule */}
                <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 overflow-hidden">
                <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
                    <h3 className="font-bold text-lg text-slate-900 dark:text-white">Agenda de Hoje</h3>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-700">
                    {[1,2,3].map((_, i) => (
                    <div key={i} className="px-8 py-5 flex space-x-6 group hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors cursor-pointer">
                        <div className="text-center w-14 flex flex-col justify-center">
                        <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Manhã</p>
                        <p className="font-black text-slate-800 dark:text-slate-200 text-xl">09:{i}0</p>
                        </div>
                        <div className="flex-1 bg-clinical-50/50 dark:bg-clinical-900/20 rounded-2xl p-4 border-l-4 border-clinical-500 group-hover:bg-clinical-50 dark:group-hover:bg-clinical-900/30 transition-colors">
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="font-bold text-slate-900 dark:text-white text-base">Retorno: Ajuste de TRT</p>
                                    <div className="flex items-center mt-2 text-sm text-slate-600 dark:text-slate-400 font-medium">
                                        <i className="fa-regular fa-user mr-2 text-slate-400"></i>
                                        <span>Carlos Mendes</span>
                                    </div>
                                </div>
                                <div className="w-8 h-8 rounded-full bg-white dark:bg-slate-800 flex items-center justify-center text-clinical-600 dark:text-clinical-400 shadow-sm border border-slate-100 dark:border-slate-700">
                                    <i className="fa-solid fa-chevron-right text-xs"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    ))}
                </div>
                </div>
            </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;
