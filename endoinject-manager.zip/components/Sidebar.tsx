
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';

const Sidebar: React.FC = () => {
  const location = useLocation();
  const { theme, setTheme } = useTheme();
  const [currentTime, setCurrentTime] = useState(new Date());

  // Simulação de "Heartbeat" do sistema para atualizar os tempos de sincronização
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navItems = [
    { path: '/dashboard', label: 'Visão Geral', icon: 'fa-chart-pie' },
    { path: '/calendar', label: 'Agenda', icon: 'fa-calendar-days' },
    { path: '/patients', label: 'Pacientes', icon: 'fa-users' },
    { path: '/inventory', label: 'Estoque & Farmácia', icon: 'fa-prescription-bottle-medical' },
    { path: '/compounds', label: 'Laboratório de Fórmulas', icon: 'fa-flask-vial' },
    { path: '/protocol', label: 'Protocolo AI', icon: 'fa-brain' },
    { path: '/plans', label: 'Planos & Serviços', icon: 'fa-gem' }, // Added Plans Item
  ];

  const IntegrationCard = ({ 
    path, 
    label, 
    subLabel, 
    icon, 
    colorTheme, 
    status, 
    latency 
  }: { 
    path: string, 
    label: string, 
    subLabel: string, 
    icon: string, 
    colorTheme: 'teal' | 'indigo',
    status: string,
    latency: string
  }) => {
    const active = isActive(path);
    
    // Theme configurations
    const themes = {
      teal: {
        activeBg: 'bg-teal-50/80 dark:bg-teal-900/30',
        activeBorder: 'border-teal-200 dark:border-teal-700',
        activeText: 'text-teal-900 dark:text-teal-100',
        iconBg: 'bg-teal-100/80 dark:bg-teal-800/50',
        iconColor: 'text-teal-600 dark:text-teal-300',
        glow: 'shadow-[0_0_15px_rgba(20,184,166,0.15)]',
        statusDot: 'bg-teal-500'
      },
      indigo: {
        activeBg: 'bg-indigo-50/80 dark:bg-indigo-900/30',
        activeBorder: 'border-indigo-200 dark:border-indigo-700',
        activeText: 'text-indigo-900 dark:text-indigo-100',
        iconBg: 'bg-indigo-100/80 dark:bg-indigo-800/50',
        iconColor: 'text-indigo-600 dark:text-indigo-300',
        glow: 'shadow-[0_0_15px_rgba(99,102,241,0.15)]',
        statusDot: 'bg-indigo-500'
      }
    };
    
    const theme = themes[colorTheme];

    return (
      <Link
        to={path}
        className={`w-full block relative rounded-2xl border transition-all duration-300 group overflow-hidden backdrop-blur-sm ${
          active 
            ? `${theme.activeBg} ${theme.activeBorder} ${theme.glow}` 
            : 'bg-white/40 border-white/40 dark:bg-slate-800/40 dark:border-slate-700/40 hover:bg-white/60 hover:border-white/60 dark:hover:bg-slate-800/60'
        }`}
      >
        {/* Active Indicator Bar */}
        {active && <div className={`absolute left-0 top-0 bottom-0 w-1 ${theme.statusDot}`}></div>}

        <div className="p-3.5 flex items-center space-x-3">
          {/* Icon Container */}
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
            active ? theme.iconBg : 'bg-white/50 dark:bg-slate-700/50'
          }`}>
             <i className={`fa-solid ${icon} ${active ? theme.iconColor : 'text-slate-600 dark:text-slate-400'} text-lg`}></i>
          </div>

          <div className="flex-1 min-w-0">
             <div className="flex justify-between items-center mb-0.5">
                <span className={`text-sm font-black tracking-tight ${active ? theme.activeText : 'text-slate-800 dark:text-slate-200'}`}>
                  {label}
                </span>
                {/* Live Status Indicator */}
                <div className="flex items-center space-x-1.5 bg-white/50 dark:bg-slate-900/50 px-1.5 py-0.5 rounded-full border border-white/20 dark:border-slate-700">
                   <div className={`w-1.5 h-1.5 rounded-full ${theme.statusDot} animate-pulse`}></div>
                   <span className={`text-[9px] font-bold uppercase ${active ? theme.activeText : 'text-slate-500 dark:text-slate-400'}`}>{status}</span>
                </div>
             </div>
             <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide truncate">{subLabel}</p>
          </div>
        </div>

        {/* Technical Footer (Telemetry) */}
        <div className={`px-3.5 py-2 border-t flex justify-between items-center text-[9px] font-mono font-medium ${
            active ? `border-${colorTheme}-100 dark:border-${colorTheme}-900 bg-white/50 dark:bg-slate-900/30` : 'border-slate-200/30 dark:border-slate-700/30 bg-white/20 dark:bg-slate-800/20'
        }`}>
            <span className="text-slate-500 dark:text-slate-400">Ping: <span className="text-slate-700 dark:text-slate-300">{latency}</span></span>
            <span className="text-slate-500 dark:text-slate-400 flex items-center">
               <i className="fa-solid fa-rotate text-[8px] mr-1"></i> 
               Sync: Agora
            </span>
        </div>
      </Link>
    );
  };

  return (
    <div className="w-72 bg-white/60 dark:bg-slate-900/80 backdrop-blur-2xl border-r border-white/40 dark:border-slate-700/40 h-screen flex flex-col fixed left-0 top-0 z-50 shadow-[0_0_40px_rgba(0,0,0,0.05)] transition-colors duration-300">
      {/* Branding */}
      <div className="p-8 flex items-center space-x-3 border-b border-white/30 dark:border-slate-700/30 bg-gradient-to-b from-white/40 to-transparent dark:from-slate-800/20">
        <div className="w-10 h-10 bg-slate-900/90 dark:bg-clinical-600 backdrop-blur-md rounded-xl flex items-center justify-center text-white shadow-lg shadow-slate-900/20 ring-4 ring-white/50 dark:ring-slate-700/50">
          <i className="fa-solid fa-dna text-lg"></i>
        </div>
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight leading-none">EndoInject</h1>
          <p className="text-[10px] uppercase tracking-[0.25em] text-clinical-600 dark:text-clinical-400 font-bold mt-1.5">Nexus OS</p>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-1.5 mt-6 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`w-full flex items-center space-x-4 px-5 py-3.5 rounded-xl transition-all duration-200 group relative border backdrop-blur-sm ${
              isActive(item.path)
                ? 'bg-white/80 dark:bg-slate-800/80 border-white/60 dark:border-slate-600 text-slate-900 dark:text-white shadow-glass'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:bg-white/40 dark:hover:bg-slate-800/40 hover:text-slate-900 dark:hover:text-white hover:border-white/30 dark:hover:border-slate-700'
            }`}
          >
             {isActive(item.path) && (
               <div className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-1 bg-clinical-600 rounded-r-full shadow-glow"></div>
             )}

            <i className={`fa-solid ${item.icon} w-5 text-center text-lg transition-transform group-hover:scale-110 duration-300 ${isActive(item.path) ? 'text-clinical-600 dark:text-clinical-400' : 'text-slate-500 dark:text-slate-500 group-hover:text-clinical-600 dark:group-hover:text-clinical-400'}`}></i>
            <span className={`tracking-wide text-sm font-bold ${isActive(item.path) ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white'}`}>{item.label}</span>
          </Link>
        ))}

        {/* Separator - Nexus Integrations */}
        <div className="pt-8 pb-4 px-2">
            <div className="flex items-center space-x-2 mb-3 px-2">
                <i className="fa-solid fa-server text-[10px] text-slate-400 dark:text-slate-500"></i>
                <p className="text-[10px] uppercase font-black text-slate-400 dark:text-slate-500 tracking-[0.15em]">Sistemas Conectados</p>
            </div>
            
            <div className="space-y-3">
                <IntegrationCard 
                    path="/imeddis"
                    label="iMeddis"
                    subLabel="Interações Medicamentosas"
                    icon="fa-network-wired"
                    colorTheme="teal"
                    status="Online"
                    latency="12ms"
                />

                <IntegrationCard 
                    path="/labpro"
                    label="LabPro"
                    subLabel="Análises Clínicas"
                    icon="fa-microscope"
                    colorTheme="indigo"
                    status="Ativo"
                    latency="24ms"
                />
            </div>
        </div>
      </nav>

      {/* Theme & User Profile */}
      <div className="p-4 border-t border-white/30 dark:border-slate-700/30 bg-white/30 dark:bg-slate-800/30 space-y-4">
        
        {/* Theme Switcher */}
        <div className="flex p-1 bg-white/50 dark:bg-slate-900/50 rounded-xl border border-white/40 dark:border-slate-700">
           <button 
             onClick={() => setTheme('light')}
             className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1 ${theme === 'light' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
             title="Claro"
           >
             <i className="fa-solid fa-sun"></i>
           </button>
           <button 
             onClick={() => setTheme('dark')}
             className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1 ${theme === 'dark' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
             title="Escuro"
           >
             <i className="fa-solid fa-moon"></i>
           </button>
           <button 
             onClick={() => setTheme('system')}
             className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1 ${theme === 'system' ? 'bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
             title="Sistema"
           >
             <i className="fa-solid fa-laptop"></i>
           </button>
        </div>

        <div className="flex items-center space-x-3 p-3 rounded-2xl bg-white/60 dark:bg-slate-800/60 border border-white/50 dark:border-slate-600 shadow-sm cursor-pointer group hover:border-clinical-300 transition-all hover:shadow-glass backdrop-blur-sm">
          <div className="w-10 h-10 rounded-full bg-clinical-100 dark:bg-slate-700 overflow-hidden ring-2 ring-white dark:ring-slate-600 border border-clinical-200 dark:border-slate-500 group-hover:scale-105 transition-transform">
             <img src="https://ui-avatars.com/api/?name=Sandra+Lobato&background=1e3a8a&color=fff&font-size=0.4" alt="Profile" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-black text-slate-900 dark:text-white group-hover:text-clinical-800 dark:group-hover:text-clinical-400 transition-colors truncate">Dra. Sandra Lobato</p>
            <p className="text-[10px] text-slate-600 dark:text-slate-400 font-bold uppercase tracking-wide truncate">Enfermeira Chefe</p>
          </div>
          <i className="fa-solid fa-gear text-slate-400 dark:text-slate-500 group-hover:text-clinical-600 transition-colors"></i>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
