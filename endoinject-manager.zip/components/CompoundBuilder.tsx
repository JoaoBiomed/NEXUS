
import React, { useState, useEffect } from 'react';
import { MOCK_INVENTORY, PRESET_PROTOCOLS, MOCK_COMPOUND_STOCK } from '../constants';
import { Compound, CompoundIngredient, PresetProtocol } from '../types';
import { generateCompoundSuggestion } from '../services/geminiService';
import { fetchManipulationCostFromPharmacy } from '../services/pharmacyService';

const CompoundBuilder: React.FC = () => {
  // activeIngredients now acts as the "Base Ratio" definition
  const [activeIngredients, setActiveIngredients] = useState<CompoundIngredient[]>([]);
  const [compoundName, setCompoundName] = useState('');
  const [administration, setAdministration] = useState<'IM' | 'IV' | 'SC' | 'ID'>('IM');
  
  // This is the Master Controller for volume
  const [targetTotalVolume, setTargetTotalVolume] = useState<number>(0);
  
  // Tabs for Left Panel
  const [leftTab, setLeftTab] = useState<'INGREDIENTS' | 'LIBRARY'>('LIBRARY');
  const [libraryCategory, setLibraryCategory] = useState<string>('Todos');

  // AI Suggestion State
  const [aiGoal, setAiGoal] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState<Compound[]>([]);
  
  // Visual Context State
  const [bgImage, setBgImage] = useState<string>('');
  const [bgCategory, setBgCategory] = useState<string>('');

  // Financial Data State
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [marketPriceSuggestion, setMarketPriceSuggestion] = useState<number>(0);
  const [isQuoting, setIsQuoting] = useState(false);
  const [isLiveQuote, setIsLiveQuote] = useState(false);

  // Import State
  const [importCode, setImportCode] = useState('');

  // Detail Modal State
  const [selectedDetailProtocol, setSelectedDetailProtocol] = useState<PresetProtocol | null>(null);

  // Standard Vial Sizes for Quick Selection
  const STANDARD_VOLUMES = [2, 5, 10, 15, 20, 30, 50, 100, 250];

  // Mock available base ingredients
  const availableIngredients = [
    ...MOCK_INVENTORY.map(i => ({ name: i.name, concentration: i.concentration, category: i.type })),
    { name: 'L-Carnitina', concentration: '600mg/2mL', category: 'Lipolítico' },
    { name: 'HMB', concentration: '100mg/mL', category: 'Muscular' },
    { name: 'PQQ', concentration: '5mg/mL', category: 'Mitocondrial' },
    { name: 'Vitamina B12', concentration: '2500mcg/mL', category: 'Vitamínico' },
    { name: 'CoQ10', concentration: '50mg/mL', category: 'Mitocondrial' },
    { name: 'Magnésio', concentration: '200mg/2mL', category: 'Mineral' },
    { name: 'PDRN', concentration: '15mg/mL', category: 'Regenerativo' },
    { name: 'Exossomas', concentration: '3%', category: 'Regenerativo' },
    { name: 'DMAE', concentration: '3%', category: 'Tensor' },
    { name: 'Silício Orgânico', concentration: '10mg/mL', category: 'Estrutural' },
  ];

  // Imagens sutis e profissionais para o fundo
  const getBackgroundImage = (category: string) => {
      switch(category) {
          case 'Facial': return 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?q=80&w=2070&auto=format&fit=crop'; // Clean skin texture/spa
          case 'Corporal': return 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=2070&auto=format&fit=crop'; // Fitness/Tape measure
          case 'Capilar': return 'https://images.unsplash.com/photo-1585238342024-78d387f4a707?q=80&w=2080&auto=format&fit=crop'; // Hair texture
          case 'IM': return 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?q=80&w=2071&auto=format&fit=crop'; // Weights/Muscle
          case 'Soro': return 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=2070&auto=format&fit=crop'; // Lab/IV
          default: return 'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?q=80&w=2091&auto=format&fit=crop'; // Generic Medical
      }
  };

  const updateBackground = (cat: string) => {
      setBgCategory(cat);
      setBgImage(getBackgroundImage(cat));
  };

  // Helper: Calculate the sum of base volumes (the denominator for ratio)
  const getBaseSum = () => {
    return activeIngredients.reduce((acc, curr) => acc + curr.volume, 0);
  };

  const handleAddIngredient = (item: any) => {
    // Default add 1mL to the base ratio
    const newItem: CompoundIngredient = {
      name: item.name,
      dose: item.concentration, 
      volume: 1.0 
    };
    
    setTargetTotalVolume(prev => prev + 1.0);
    setActiveIngredients([...activeIngredients, newItem]);
    setIsLiveQuote(false); // Reset live quote on modification
    
    if(!bgImage) {
        updateBackground('General');
    }
    // Simple cost estimator for added items (approximate)
    setEstimatedCost(prev => prev + 15); 
  };

  const handleRemoveIngredient = (index: number) => {
    const ingredientToRemove = activeIngredients[index];
    const baseSum = getBaseSum();
    const currentRealVolume = baseSum > 0 
        ? (ingredientToRemove.volume / baseSum) * targetTotalVolume 
        : 0;

    const newIngredients = [...activeIngredients];
    newIngredients.splice(index, 1);
    setActiveIngredients(newIngredients);
    setTargetTotalVolume(prev => Math.max(0, prev - currentRealVolume));
    setIsLiveQuote(false); // Reset live quote on modification
    
    // Reduce estimated cost (approximate)
    setEstimatedCost(prev => Math.max(0, prev - 15));
  };

  const handleAiSuggest = async () => {
    if (!aiGoal) return;
    setIsGenerating(true);
    setSuggestions([]);
    const results = await generateCompoundSuggestion(aiGoal);
    setSuggestions(results);
    setIsGenerating(false);
  };

  const applySuggestion = (compound: Compound) => {
    setCompoundName(compound.name);
    setAdministration(compound.administration);
    setActiveIngredients(compound.ingredients);
    setTargetTotalVolume(compound.totalVolume);
    setMarketPriceSuggestion(0); // Explicitly 0 for AI suggestions
    setEstimatedCost(compound.totalVolume * 25); // Estimated cost logic
    setIsLiveQuote(false);
    // Infer category for background
    if (compound.tags.includes('Facial')) updateBackground('Facial');
    else if (compound.tags.includes('Hair')) updateBackground('Capilar');
    else if (compound.administration === 'IV') updateBackground('Soro');
    else updateBackground('IM');
  };

  const applyPreset = (preset: PresetProtocol) => {
    setCompoundName(preset.name);
    setAdministration(preset.administration);
    setActiveIngredients(preset.ingredients.map(ing => ({...ing})));
    
    const presetTotal = preset.ingredients.reduce((acc, i) => acc + i.volume, 0);
    setTargetTotalVolume(presetTotal);
    
    // Financial Data - Use exact preset values
    setMarketPriceSuggestion(preset.averageMarketPrice);
    setEstimatedCost(preset.estimatedCost);
    setIsLiveQuote(false); // Preset has estimated cost stored, not live yet

    updateBackground(preset.category);
    setSelectedDetailProtocol(null); // Close modal
  };

  const handleImportFromStock = () => {
      const stockItem = MOCK_COMPOUND_STOCK.find(item => item.id.toLowerCase() === importCode.toLowerCase());

      if (stockItem) {
          setCompoundName(stockItem.name);
          setTargetTotalVolume(stockItem.unitVolume);
          
          // Attempt to find matching preset to get ingredients, otherwise create generic
          const matchingPreset = PRESET_PROTOCOLS.find(p => p.name === stockItem.name);
          
          if (matchingPreset) {
              setActiveIngredients(matchingPreset.ingredients.map(i => ({...i})));
              setAdministration(matchingPreset.administration);
              updateBackground(matchingPreset.category);
          } else {
              // Fallback if no detailed recipe exists, map the stock item itself as a base
              setActiveIngredients([{
                  name: stockItem.name,
                  dose: 'Formula Base',
                  volume: stockItem.unitVolume
              }]);
              
              // Infer admin from category
              if(stockItem.category === 'IM') setAdministration('IM');
              else if(stockItem.category === 'Soro') setAdministration('IV');
              else if(stockItem.category === 'Facial') setAdministration('ID');
              else setAdministration('SC');
              
              updateBackground(stockItem.category);
          }

          // Financials from Stock
          setEstimatedCost(stockItem.costPrice);
          setMarketPriceSuggestion(stockItem.sellingPrice);
          setIsLiveQuote(true); // It's a real stock item
          
          setImportCode(''); // Clear input
      } else {
          alert("Código de estoque não encontrado. Tente: stk-fac-01, stk-im-01...");
      }
  };

  const handleSyncQuote = async () => {
    if (targetTotalVolume <= 0) return;
    
    setIsQuoting(true);
    const cost = await fetchManipulationCostFromPharmacy(
        compoundName || 'Fórmula Personalizada',
        targetTotalVolume
    );
    
    setIsQuoting(false);
    
    if (cost !== null) {
        setEstimatedCost(cost);
        setIsLiveQuote(true);
    }
  };

  // Filter Logic for Library
  const categories = ['Todos', 'Facial', 'Corporal', 'Capilar', 'IM', 'Soro'];
  const filteredPresets = libraryCategory === 'Todos' 
    ? PRESET_PROTOCOLS 
    : PRESET_PROTOCOLS.filter(p => p.category === libraryCategory);

  // Calculation Logic for Rendering
  const baseSum = getBaseSum();
  const scalingRatio = baseSum > 0 ? targetTotalVolume / baseSum : 0;
  
  // Dynamic Profit Calculation
  const profit = marketPriceSuggestion - estimatedCost;
  const margin = estimatedCost > 0 ? (profit / estimatedCost) * 100 : 0;

  return (
    <div className="max-w-7xl mx-auto h-[calc(100vh-6rem)] grid grid-cols-12 gap-6 animate-fade-in pb-4 relative">
      
      {/* --- PROTOCOL DETAILS MODAL --- */}
      {selectedDetailProtocol && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col relative">
                {/* Header Background */}
                <div className="h-40 relative overflow-hidden shrink-0">
                    <img src={getBackgroundImage(selectedDetailProtocol.category)} className="w-full h-full object-cover" alt="Header" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-8 w-full">
                        <div className="flex justify-between items-end">
                            <div>
                                <span className="bg-white/20 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-extrabold uppercase border border-white/30 mb-2 inline-block">
                                    {selectedDetailProtocol.category} • Via {selectedDetailProtocol.administration}
                                </span>
                                <h2 className="text-3xl font-black text-white leading-none">{selectedDetailProtocol.name}</h2>
                            </div>
                            <button onClick={() => setSelectedDetailProtocol(null)} className="text-white/60 hover:text-white transition-colors">
                                <i className="fa-solid fa-xmark text-3xl"></i>
                            </button>
                        </div>
                    </div>
                </div>

                {/* Modal Content */}
                <div className="flex-1 overflow-y-auto p-8 custom-scrollbar bg-slate-50">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Column 1: Science & Description */}
                        <div className="space-y-6">
                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                                <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide mb-3 flex items-center">
                                    <i className="fa-solid fa-microscope text-clinical-600 mr-2"></i> Mecanismo de Ação
                                </h3>
                                <p className="text-slate-700 text-sm leading-relaxed font-medium">
                                    {selectedDetailProtocol.mechanism || "Descrição técnica não disponível para este protocolo."}
                                </p>
                            </div>
                            
                            <div>
                                <h3 className="text-sm font-extrabold text-slate-500 uppercase tracking-wide mb-3">Indicação Clínica</h3>
                                <p className="text-slate-800 font-bold text-lg leading-tight">{selectedDetailProtocol.indication}</p>
                            </div>

                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                                <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide mb-4">Composição (Dose Padrão)</h3>
                                <div className="space-y-2">
                                    {selectedDetailProtocol.ingredients.map((ing, idx) => (
                                        <div key={idx} className="flex justify-between text-sm border-b border-slate-50 pb-2 last:border-0 last:pb-0">
                                            <span className="text-slate-700 font-bold">{ing.name}</span>
                                            <div className="flex items-center space-x-3">
                                                <span className="text-slate-500 text-xs font-semibold">{ing.dose}</span>
                                                <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-xs font-mono font-bold">{ing.volume}mL</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Column 2: Pros/Cons & Action */}
                        <div className="space-y-6 flex flex-col">
                            <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-2xl">
                                <h3 className="text-xs font-extrabold text-emerald-800 uppercase tracking-wide mb-3 flex items-center">
                                    <i className="fa-solid fa-thumbs-up mr-2"></i> Benefícios (Prós)
                                </h3>
                                <ul className="space-y-2">
                                    {selectedDetailProtocol.pros && selectedDetailProtocol.pros.length > 0 ? (
                                        selectedDetailProtocol.pros.map((pro, i) => (
                                            <li key={i} className="flex items-start text-sm text-emerald-900 font-medium">
                                                <i className="fa-solid fa-check text-emerald-500 mt-1 mr-2 text-xs"></i>
                                                {pro}
                                            </li>
                                        ))
                                    ) : <li className="text-sm text-emerald-900/60 italic">Dados não listados.</li>}
                                </ul>
                            </div>

                            <div className="bg-amber-50 border border-amber-100 p-6 rounded-2xl">
                                <h3 className="text-xs font-extrabold text-amber-800 uppercase tracking-wide mb-3 flex items-center">
                                    <i className="fa-solid fa-triangle-exclamation mr-2"></i> Atenção (Contras)
                                </h3>
                                <ul className="space-y-2">
                                    {selectedDetailProtocol.cons && selectedDetailProtocol.cons.length > 0 ? (
                                        selectedDetailProtocol.cons.map((con, i) => (
                                            <li key={i} className="flex items-start text-sm text-amber-900 font-medium">
                                                <i className="fa-solid fa-xmark text-amber-500 mt-1 mr-2 text-xs"></i>
                                                {con}
                                            </li>
                                        ))
                                    ) : <li className="text-sm text-amber-900/60 italic">Nenhuma contraindicação específica listada.</li>}
                                </ul>
                            </div>
                            
                            <div className="mt-auto pt-4">
                                <button 
                                    onClick={() => applyPreset(selectedDetailProtocol)}
                                    className="w-full py-4 bg-clinical-900 text-white font-black text-lg rounded-2xl shadow-xl hover:bg-clinical-800 hover:scale-[1.02] transition-all flex items-center justify-center"
                                >
                                    <i className="fa-solid fa-flask-vial mr-3"></i>
                                    Carregar no Misturador
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
           </div>
        </div>
      )}

      {/* LEFT COLUMN: Ingredients & Library */}
      <div className="col-span-3 bg-white/95 backdrop-blur-md rounded-3xl shadow-soft border border-slate-200 flex flex-col overflow-hidden h-full">
        
        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200">
            <button 
                onClick={() => setLeftTab('LIBRARY')}
                className={`flex-1 py-4 text-xs font-extrabold uppercase tracking-wider transition-all relative ${leftTab === 'LIBRARY' ? 'text-clinical-800 bg-clinical-50' : 'text-slate-500 hover:text-slate-700'}`}
            >
                {leftTab === 'LIBRARY' && <div className="absolute bottom-0 left-0 w-full h-1 bg-clinical-600"></div>}
                <i className="fa-solid fa-book-medical mr-2"></i> Biblioteca
            </button>
            <button 
                onClick={() => setLeftTab('INGREDIENTS')}
                className={`flex-1 py-4 text-xs font-extrabold uppercase tracking-wider transition-all relative ${leftTab === 'INGREDIENTS' ? 'text-clinical-800 bg-clinical-50' : 'text-slate-500 hover:text-slate-700'}`}
            >
                {leftTab === 'INGREDIENTS' && <div className="absolute bottom-0 left-0 w-full h-1 bg-clinical-600"></div>}
                <i className="fa-solid fa-vial mr-2"></i> Avulso
            </button>
        </div>

        {leftTab === 'LIBRARY' ? (
            <div className="flex flex-col h-full overflow-hidden">
                <div className="p-3 border-b border-slate-100 overflow-x-auto whitespace-nowrap custom-scrollbar flex space-x-2 bg-white">
                    {categories.map(cat => (
                        <button 
                            key={cat}
                            onClick={() => setLibraryCategory(cat)}
                            className={`px-3 py-1.5 rounded-xl text-[10px] font-extrabold uppercase transition-all shadow-sm ${libraryCategory === cat ? 'bg-clinical-700 text-white border border-clinical-700' : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'}`}
                        >
                            {cat}
                        </button>
                    ))}
                </div>
                <div className="overflow-y-auto flex-1 p-4 space-y-3 custom-scrollbar bg-slate-50">
                    {filteredPresets.map((preset) => (
                        <div 
                            key={preset.id} 
                            className="group relative p-4 rounded-2xl border border-slate-200 bg-white shadow-sm hover:border-clinical-400 hover:shadow-md transition-all overflow-hidden"
                        >
                            {/* Hover Action Overlay */}
                            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-all duration-300 z-20 flex flex-col items-center justify-center space-y-2 px-4">
                                <button 
                                    onClick={(e) => { e.stopPropagation(); applyPreset(preset); }}
                                    className="w-full py-2.5 bg-clinical-600 text-white font-bold rounded-xl shadow-lg hover:bg-clinical-500 transition-transform active:scale-95 flex items-center justify-center text-xs"
                                >
                                    <i className="fa-solid fa-flask mr-2"></i> Carregar Agora
                                </button>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); setSelectedDetailProtocol(preset); }}
                                    className="w-full py-2.5 bg-white text-slate-900 font-bold rounded-xl shadow-lg hover:bg-slate-100 transition-transform active:scale-95 flex items-center justify-center text-xs"
                                >
                                    <i className="fa-solid fa-eye mr-2"></i> Ver Detalhes
                                </button>
                            </div>

                            <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-slate-50 to-clinical-50 rounded-bl-full -mr-8 -mt-8"></div>
                            
                            <div className="mb-2 relative z-10">
                                <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md text-white shadow-sm ${
                                    preset.category === 'Facial' ? 'bg-pink-500' : 
                                    preset.category === 'Corporal' ? 'bg-orange-500' : 
                                    preset.category === 'Capilar' ? 'bg-slate-700' : 
                                    preset.category === 'Soro' ? 'bg-cyan-600' : 'bg-blue-600'
                                }`}>
                                    {preset.category}
                                </span>
                            </div>

                            <h4 className="font-extrabold text-slate-900 text-sm leading-tight mb-1 relative z-10">{preset.name}</h4>
                            <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed font-medium relative z-10">{preset.description}</p>
                            
                            {/* Mini Price Indicator */}
                            <div className="mt-2 flex items-center space-x-2">
                                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                                    <i className="fa-solid fa-tags mr-1"></i> R$ {preset.averageMarketPrice}
                                </span>
                                <span className="text-[10px] text-slate-500 font-bold bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200" title="Volume Base do Protocolo">
                                    <i className="fa-solid fa-flask mr-1"></i> {preset.ingredients.reduce((a,b)=>a+b.volume,0)}mL
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        ) : (
            <>
                <div className="p-4 border-b border-slate-200 bg-slate-50">
                <div className="relative">
                    <i className="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 text-xs"></i>
                    <input 
                        type="text" 
                        placeholder="Buscar ativo..." 
                        className="w-full text-xs pl-8 p-3 rounded-xl border border-slate-300 bg-white shadow-sm focus:ring-2 focus:ring-clinical-500 font-bold text-slate-900 placeholder-slate-400"
                    />
                </div>
                </div>
                <div className="overflow-y-auto flex-1 p-4 space-y-3 custom-scrollbar bg-slate-50">
                {availableIngredients.map((item, idx) => (
                    <div 
                    key={idx} 
                    onClick={() => handleAddIngredient(item)}
                    className="p-3 rounded-2xl border border-slate-200 bg-white hover:border-clinical-400 hover:shadow-md cursor-pointer transition-all group flex items-center justify-between"
                    >
                    <div>
                        <p className="font-extrabold text-sm text-slate-900 group-hover:text-clinical-700">{item.name}</p>
                        <p className="text-[11px] text-slate-600 font-semibold">{item.concentration}</p>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-clinical-50 text-clinical-600 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <i className="fa-solid fa-plus text-xs"></i>
                    </div>
                    </div>
                ))}
                </div>
            </>
        )}
      </div>

      {/* CENTER COLUMN: The Mixer */}
      <div className="col-span-5 flex flex-col space-y-6 h-full">
        <div className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/60 p-0 flex-1 flex flex-col relative overflow-hidden group transition-all duration-700">
           
           {/* DYNAMIC BACKGROUND ENGINE */}
           <div className="absolute inset-0 z-0 transition-opacity duration-1000 ease-in-out pointer-events-none">
                {bgImage ? (
                    <>
                        <img 
                            src={bgImage} 
                            alt="Background Context" 
                            className="w-full h-full object-cover opacity-10 mix-blend-multiply filter blur-[1px] scale-105 transition-transform duration-[2000ms]"
                        />
                        {/* Gradient Overlay for Text Readability */}
                        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/80 to-white/40"></div>
                    </>
                ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-slate-50 to-clinical-50/30"></div>
                )}
           </div>

           {/* Content Container */}
           <div className="flex flex-col h-full relative z-10 p-8">
                
                {/* --- IMPORT BAR --- */}
                <div className="flex items-center space-x-2 mb-6 bg-slate-50/80 backdrop-blur-sm rounded-xl p-2 border border-slate-200 shadow-sm">
                    <div className="relative flex-1">
                        <i className="fa-solid fa-barcode absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 text-xs"></i>
                        <input 
                            type="text" 
                            className="w-full pl-8 pr-3 py-2 bg-white rounded-lg border border-slate-200 text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-clinical-500 placeholder-slate-400"
                            placeholder="Importar Código Estoque (ex: stk-fac-01)..."
                            value={importCode}
                            onChange={(e) => setImportCode(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleImportFromStock()}
                        />
                    </div>
                    <button 
                        onClick={handleImportFromStock}
                        className="bg-slate-200 text-slate-700 hover:bg-clinical-600 hover:text-white px-3 py-2 rounded-lg text-xs font-bold transition-all"
                    >
                        <i className="fa-solid fa-download"></i>
                    </button>
                </div>

                {/* Header */}
                <div className="flex justify-between items-start mb-4">
                    <div className="flex-1 mr-4">
                        <label className="block text-[11px] font-extrabold text-clinical-600 uppercase tracking-widest mb-2 flex items-center">
                            <i className="fa-solid fa-tag mr-1.5"></i> Nome do Complexo
                        </label>
                        <input 
                            type="text" 
                            placeholder="Ex: Lipo Burn Ultimate"
                            className="w-full text-2xl font-black text-slate-900 placeholder-slate-300 border-none focus:ring-0 p-0 bg-transparent tracking-tight leading-none"
                            value={compoundName}
                            onChange={(e) => setCompoundName(e.target.value)}
                        />
                    </div>
                    <div className="flex flex-col items-end">
                         <label className="block text-[11px] font-extrabold text-clinical-600 uppercase tracking-widest mb-2">Via</label>
                         <select 
                            className="bg-clinical-50 text-clinical-900 font-bold text-sm rounded-lg border border-clinical-100 focus:ring-2 focus:ring-clinical-500 py-2 px-4 shadow-sm cursor-pointer hover:bg-clinical-100 transition-colors"
                            value={administration}
                            onChange={(e) => setAdministration(e.target.value as any)}
                        >
                            <option value="IM">Intramuscular</option>
                            <option value="IV">Intravenoso</option>
                            <option value="SC">Subcutâneo</option>
                            <option value="ID">Intradérmica</option>
                        </select>
                    </div>
                </div>

                {/* --- FINANCIAL INTELLIGENCE BAR --- */}
                {/* Always show if there is an estimated cost (active ingredients) */}
                {(estimatedCost > 0 || marketPriceSuggestion > 0) && (
                    <div className="bg-white/60 backdrop-blur-md rounded-xl p-3 border border-slate-200/60 flex items-center justify-between mb-4 shadow-sm">
                        <div className="flex items-center space-x-4">
                            <div>
                                <p className="text-[9px] text-slate-500 font-extrabold uppercase flex items-center gap-1">
                                    {isLiveQuote ? (
                                        <>
                                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                            Custo (Parceiro)
                                        </>
                                    ) : (
                                        <>
                                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                            Custo {marketPriceSuggestion > 0 ? '(Base)' : '(Estimado)'}
                                        </>
                                    )}
                                </p>
                                <div className="flex items-center gap-2">
                                    <p className="text-sm font-bold text-slate-800">R$ {estimatedCost.toFixed(2)}</p>
                                    {!isLiveQuote && targetTotalVolume > 0 && (
                                        <button 
                                            onClick={handleSyncQuote}
                                            disabled={isQuoting}
                                            className="text-[10px] bg-white border border-slate-300 text-slate-600 px-2 py-0.5 rounded-md font-bold hover:text-clinical-700 hover:border-clinical-400 transition-all flex items-center gap-1"
                                            title="Sincronizar preço com parceiro"
                                        >
                                            {isQuoting ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <i className="fa-solid fa-rotate"></i>}
                                            Cotar
                                        </button>
                                    )}
                                </div>
                            </div>
                             <div className="h-6 w-px bg-slate-300"></div>
                            <div>
                                <p className="text-[9px] text-slate-500 font-extrabold uppercase">
                                    Preço Mercado {marketPriceSuggestion === 0 && '(Não definido)'}
                                </p>
                                <p className="text-sm font-bold text-clinical-700">
                                    {marketPriceSuggestion > 0 ? `R$ ${marketPriceSuggestion.toFixed(2)}` : '---'}
                                </p>
                            </div>
                        </div>
                        <div className="text-right">
                             {marketPriceSuggestion > 0 ? (
                                <>
                                    <p className="text-[9px] text-emerald-600 font-extrabold uppercase">Lucro Potencial</p>
                                    <p className="text-sm font-black text-emerald-600 flex items-center">
                                        R$ {profit.toFixed(2)}
                                        <span className="bg-emerald-100 text-emerald-700 text-[10px] px-1.5 rounded ml-2">
                                            {margin.toFixed(0)}%
                                        </span>
                                    </p>
                                </>
                             ) : (
                                <p className="text-[10px] text-slate-400 font-bold italic mt-1">
                                    Defina preço de venda para calcular margem
                                </p>
                             )}
                        </div>
                    </div>
                )}

                {/* Visualization of the Vial/Syringe */}
                <div className="flex-1 flex flex-col relative my-2">
                    {activeIngredients.length === 0 ? (
                        <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 border-2 border-dashed border-slate-300 rounded-3xl m-4 bg-slate-50/50">
                            <div className="w-20 h-20 rounded-full bg-white shadow-sm flex items-center justify-center mb-4 border border-slate-100">
                                <i className="fa-solid fa-flask text-3xl text-slate-300"></i>
                            </div>
                            <p className="text-slate-500 font-bold text-lg">Laboratório Vazio</p>
                            <p className="text-xs text-slate-500 font-medium mt-1">Selecione um protocolo ou adicione ativos.</p>
                        </div>
                    ) : (
                        <div className="w-full space-y-3 relative overflow-y-auto max-h-[350px] custom-scrollbar pr-2 pb-4">
                            {activeIngredients.map((ing, idx) => {
                                const calculatedVolume = (ing.volume * scalingRatio).toFixed(2);
                                const percent = targetTotalVolume > 0 ? ((parseFloat(calculatedVolume) / targetTotalVolume) * 100).toFixed(0) : 0;
                                
                                return (
                                <div key={idx} className="flex items-center space-x-4 bg-white/80 backdrop-blur-sm p-4 rounded-2xl border border-slate-200 shadow-sm animate-fade-in hover:border-clinical-300 hover:shadow-md transition-all group/item">
                                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-clinical-600 to-clinical-800 text-white flex items-center justify-center font-bold text-xs shadow-md">
                                        {idx + 1}
                                    </div>
                                    <div className="flex-1">
                                        <p className="font-extrabold text-slate-900 text-sm leading-tight">{ing.name}</p>
                                        <p className="text-[11px] text-slate-600 font-bold uppercase tracking-wide mt-0.5">{ing.dose}</p>
                                    </div>
                                    <div className="flex items-center space-x-3">
                                        
                                        {/* Volume Base / Recomendado (Exibido para referência clínica) */}
                                        <div className="hidden md:flex flex-col items-end px-2 border-r border-slate-200 mr-2">
                                            <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wider">Rec.</span>
                                            <span className="text-xs font-bold text-slate-500">{ing.volume} mL</span>
                                        </div>

                                        {/* Percentage Bar */}
                                        <div className="hidden sm:block w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                                            <div className="h-full bg-clinical-500 rounded-full" style={{width: `${percent}%`}}></div>
                                        </div>
                                        
                                        {/* Read-Only Calculated Volume */}
                                        <div className="flex items-center bg-slate-50 rounded-lg border border-slate-200 px-3 py-1.5 shadow-inner">
                                            <span className="text-base font-black text-slate-900">{calculatedVolume}</span>
                                            <span className="text-[10px] text-slate-500 font-bold ml-1 uppercase">mL</span>
                                            <div className="h-3 w-px bg-slate-300 mx-2"></div>
                                            <i className="fa-solid fa-lock text-[10px] text-slate-400"></i>
                                        </div>
                                    </div>
                                    <button onClick={() => handleRemoveIngredient(idx)} className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all">
                                        <i className="fa-solid fa-trash-can text-sm"></i>
                                    </button>
                                </div>
                            )})}
                        </div>
                    )}
                </div>

                {/* Footer Stats - MASTER CONTROL */}
                <div className="mt-auto pt-4 border-t border-slate-200 flex flex-col relative z-20">
                    
                    {/* Standard Volumes Selector */}
                    <div className="flex items-center space-x-2 mb-3 overflow-x-auto whitespace-nowrap custom-scrollbar pb-2">
                        <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest mr-2">Padrões:</span>
                        {STANDARD_VOLUMES.map(vol => (
                            <button
                                key={vol}
                                onClick={() => {
                                    setTargetTotalVolume(vol);
                                    setIsLiveQuote(false);
                                }}
                                className={`px-2.5 py-1 rounded-md text-[10px] font-bold border transition-all ${
                                    targetTotalVolume === vol 
                                    ? 'bg-clinical-600 text-white border-clinical-600 shadow-md' 
                                    : 'bg-white text-slate-600 border-slate-200 hover:border-clinical-300 hover:text-clinical-700'
                                }`}
                            >
                                {vol}mL
                            </button>
                        ))}
                    </div>

                    <div className="flex justify-between items-end">
                        <div className="flex flex-col">
                            <div className="flex items-center space-x-2 mb-1">
                                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">
                                    Volume Total <span className="text-slate-300 mx-1">|</span> <span className="text-clinical-600" title="Volume padrão recomendado para este protocolo">Padrão: {baseSum.toFixed(1)}mL</span>
                                </label>
                                <div className="group/tooltip relative">
                                    <i className="fa-solid fa-circle-question text-slate-400 text-xs cursor-help hover:text-clinical-600 transition-colors"></i>
                                    <div className="absolute bottom-full left-0 mb-2 w-48 bg-slate-800 text-white text-[10px] p-2 rounded-lg shadow-xl hidden group-hover/tooltip:block z-50">
                                        O volume padrão é a soma das doses recomendadas. Alterar o total abaixo recalcula a proporção.
                                    </div>
                                </div>
                            </div>
                            
                            <div className="flex items-baseline">
                                <input 
                                    type="number" 
                                    step="0.5"
                                    min="0"
                                    className="text-5xl font-black text-clinical-700 bg-transparent border-none focus:ring-0 p-0 w-32 tracking-tighter transition-colors placeholder-slate-200"
                                    value={targetTotalVolume === 0 ? '' : targetTotalVolume.toFixed(1)}
                                    onChange={(e) => {
                                        setTargetTotalVolume(Number(e.target.value));
                                        setIsLiveQuote(false); // Reset quote on volume change
                                    }}
                                    placeholder="0.0"
                                />
                                <span className="text-xl font-bold text-slate-400 ml-1">mL</span>
                            </div>
                            {baseSum > 0 && targetTotalVolume !== baseSum && (
                                <div className="flex items-center text-orange-600 mt-1 bg-orange-50 px-2 py-1 rounded-md self-start border border-orange-200">
                                    <i className="fa-solid fa-scale-balanced mr-1.5 text-xs"></i>
                                    <p className="text-[10px] font-bold uppercase">Proporção Ajustada</p>
                                </div>
                            )}
                            {baseSum > 0 && targetTotalVolume === baseSum && (
                                <div className="flex items-center text-emerald-600 mt-1 bg-emerald-50 px-2 py-1 rounded-md self-start border border-emerald-200">
                                    <i className="fa-solid fa-check mr-1.5 text-xs"></i>
                                    <p className="text-[10px] font-bold uppercase">Volume Padrão</p>
                                </div>
                            )}
                        </div>
                        <button className="bg-clinical-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-clinical-800 shadow-xl shadow-clinical-900/20 transition-all flex items-center transform hover:-translate-y-1 hover:scale-105 active:scale-95 group/btn border border-clinical-700">
                            <span className="mr-2">Salvar no Estoque</span>
                            <i className="fa-solid fa-box-archive group-hover/btn:animate-bounce"></i>
                        </button>
                    </div>
                </div>
           </div>
        </div>
      </div>

      {/* RIGHT COLUMN: AI Pharmacist */}
      <div className="col-span-4 bg-white/95 backdrop-blur-md rounded-3xl shadow-soft border border-slate-200 flex flex-col overflow-hidden h-full">
         <div className="p-6 bg-gradient-to-br from-purple-50 via-white to-indigo-50 border-b border-purple-100">
            <div className="flex items-center space-x-3 mb-4">
               <div className="w-12 h-12 bg-white text-purple-600 rounded-2xl flex items-center justify-center shadow-md border border-purple-100">
                  <i className="fa-solid fa-wand-magic-sparkles text-xl"></i>
               </div>
               <div>
                   <h3 className="font-extrabold text-purple-900 text-lg leading-tight">Sugestão AI</h3>
                   <p className="text-[10px] font-bold text-purple-600 uppercase tracking-wider">Farmacêutico Virtual</p>
               </div>
            </div>
            <div className="relative">
               <input 
                  type="text" 
                  className="w-full p-4 pr-12 rounded-2xl border border-purple-100 bg-white shadow-sm focus:ring-2 focus:ring-purple-500 text-sm font-bold text-slate-900 placeholder-purple-300"
                  placeholder="Ex: Ganho de Massa, Lipo..."
                  value={aiGoal}
                  onChange={(e) => setAiGoal(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAiSuggest()}
               />
               <button 
                  onClick={handleAiSuggest}
                  className="absolute right-2 top-2 w-10 h-10 bg-purple-600 text-white rounded-xl flex items-center justify-center hover:bg-purple-700 transition-all shadow-md hover:shadow-lg shadow-purple-500/30"
               >
                  {isGenerating ? <i className="fa-solid fa-spinner fa-spin text-sm"></i> : <i className="fa-solid fa-arrow-right text-sm"></i>}
               </button>
            </div>
         </div>
         
         <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-slate-50">
            {suggestions.length > 0 ? (
               suggestions.map((sug) => (
                  <div key={sug.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-lg hover:border-purple-300 transition-all group">
                     <div className="flex justify-between items-start mb-3">
                        <span className="px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 text-[10px] font-extrabold uppercase border border-purple-100">{sug.administration}</span>
                        <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">Vol: {sug.totalVolume}mL</span>
                     </div>
                     <h4 className="font-extrabold text-slate-900 mb-1 text-lg">{sug.name}</h4>
                     <p className="text-xs text-slate-600 mb-4 line-clamp-2 leading-relaxed font-medium">{sug.description}</p>
                     
                     <div className="space-y-1 mb-5 bg-slate-50 p-3 rounded-xl border border-slate-200">
                        {sug.ingredients.map((ing, i) => (
                           <div key={i} className="flex justify-between text-xs text-slate-700 py-0.5">
                              <span className="font-bold">{ing.name}</span>
                              <span className="font-mono font-bold text-clinical-700">{ing.volume}mL</span>
                           </div>
                        ))}
                     </div>
                     
                     <button 
                        onClick={() => applySuggestion(sug)}
                        className="w-full py-3 bg-white text-slate-700 hover:bg-clinical-600 hover:text-white font-bold text-xs rounded-xl border-2 border-slate-200 hover:border-clinical-600 transition-all shadow-sm flex items-center justify-center"
                     >
                        <i className="fa-solid fa-flask mr-2"></i>
                        Carregar Fórmula
                     </button>
                  </div>
               ))
            ) : (
               <div className="flex flex-col items-center justify-center h-64 opacity-50">
                  <i className="fa-solid fa-microchip text-4xl mb-4 text-purple-300"></i>
                  <p className="text-sm font-bold text-slate-500 text-center px-8">Descreva o objetivo clínico acima para gerar sugestões inteligentes.</p>
               </div>
            )}
         </div>
      </div>

    </div>
  );
};

export default CompoundBuilder;
