
import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { generateProtocolWithThinking } from '../services/geminiService';
import { ProtocolRequest, Patient, GeneticProfile, LabProReport } from '../types';
import { MOCK_PATIENTS } from '../constants';

// --- MOCK INTEGRATION DATA GENERATORS ---
const getMockGenetics = (gender: string): GeneticProfile => ({
    metabolism: gender === 'Male' ? 'Fast' : 'Slow',
    aromatizationRisk: gender === 'Male' ? 'High' : 'Low',
    shbgAffinity: 'Low',
    oxidativeStress: 'Medium',
    polymorphisms: gender === 'Male' ? ['CYP19A1 (Aromatase)', 'ACTN3 (Força)'] : ['MTHFR (Metilação)', 'COMT (Stress)']
});

const getMockLabs = (gender: string): LabProReport => ({
    lastExamDate: new Date().toLocaleDateString('pt-BR'),
    liverFunction: 'Normal',
    lipidProfile: 'Dyslipidemia',
    kidneyFunction: 'Normal',
    hormonalStatus: {
        testoTotal: gender === 'Male' ? 350 : 25,
        freeTesto: gender === 'Male' ? 8 : 0.5,
        estradiol: gender === 'Male' ? 45 : 120,
        shbg: 25
    }
});

// Visual Markdown Parser Component (Same as before but refined styles)
const FormattedProtocol: React.FC<{ text: string }> = ({ text }) => {
  if (!text) return null;
  const lines = text.split('\n');
  
  return (
    <div className="space-y-4">
      {lines.map((line, index) => {
        const key = index;
        const trimmed = line.trim();
        if (!trimmed) return <div key={key} className="h-2" />;

        if (trimmed.startsWith('# ')) {
          return (
            <div key={key} className="mt-8 mb-4 p-4 rounded-xl border-l-4 border-clinical-500 bg-clinical-50 dark:bg-clinical-900/20 dark:border-clinical-400 shadow-sm">
              <h1 className="text-xl font-extrabold flex items-center text-clinical-900 dark:text-clinical-100">
                <i className="fa-solid fa-dna mr-3 text-clinical-600 dark:text-clinical-400"></i>
                {trimmed.replace('# ', '')}
              </h1>
            </div>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <h2 key={key} className="text-lg font-bold text-slate-800 dark:text-slate-200 mt-6 mb-3 flex items-center border-b border-slate-200 dark:border-slate-700 pb-2">
              <i className="fa-solid fa-angle-right text-clinical-400 mr-2 text-sm"></i>
              {trimmed.replace('## ', '')}
            </h2>
          );
        }
        // Bullets
        if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
          const content = trimmed.substring(2);
          const parts = content.split(/(\*\*.*?\*\*)/g);
          return (
            <div key={key} className="flex items-start space-x-3 ml-2 mb-2">
               <div className="w-1.5 h-1.5 rounded-full bg-clinical-400 mt-2.5 flex-shrink-0"></div>
               <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-sm font-medium">
                 {parts.map((part, i) => 
                    part.startsWith('**') ? <strong key={i} className="text-slate-900 dark:text-white font-bold">{part.replace(/\*\*/g, '')}</strong> : part
                 )}
               </p>
            </div>
          );
        }
        // Paragraphs
        const parts = trimmed.split(/(\*\*.*?\*\*)/g);
        return (
          <p key={key} className="text-slate-600 dark:text-slate-400 leading-relaxed mb-2 text-sm font-medium">
             {parts.map((part, i) => 
                part.startsWith('**') ? <strong key={i} className="text-slate-900 dark:text-white font-bold">{part.replace(/\*\*/g, '')}</strong> : part
             )}
          </p>
        );
      })}
    </div>
  );
};

const ProtocolAssistant: React.FC = () => {
  const location = useLocation();
  
  // FORM STATE
  const [formData, setFormData] = useState<ProtocolRequest>({
    patientWeight: 0,
    patientHeight: 0,
    gender: 'Male',
    goal: 'Hypertrophy',
    medicalHistory: ''
  });
  
  // UI STATE
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [patientSearch, setPatientSearch] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  
  // INTEGRATION STATE
  const [integrations, setIntegrations] = useState({
      imeddis: false,
      labpro: false
  });
  const [mockGenetics, setMockGenetics] = useState<GeneticProfile | null>(null);
  const [mockLabs, setMockLabs] = useState<LabProReport | null>(null);

  // AI STATE
  const [result, setResult] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  // Check for passed state
  useEffect(() => {
    if (location.state) {
      const state = location.state as Partial<ProtocolRequest>;
      setFormData(prev => ({ ...prev, ...state }));
    }
  }, [location.state]);

  // Handle Patient Selection
  const handleSelectPatient = (p: Patient) => {
      setSelectedPatient(p);
      setFormData({
          patientWeight: 80, // Mock, should come from DB
          patientHeight: 180, // Mock
          gender: p.gender,
          goal: 'Hypertrophy',
          medicalHistory: `Protocolo atual: ${p.currentProtocol}. Status: ${p.status}.`,
          patientName: p.name
      });
      setPatientSearch(p.name);
      setIsDropdownOpen(false);
      
      // Reset Integrations
      setIntegrations({ imeddis: false, labpro: false });
      setMockGenetics(null);
      setMockLabs(null);
      setResult('');
  };

  const toggleIntegration = (type: 'imeddis' | 'labpro') => {
      if (!selectedPatient) return;

      const newState = !integrations[type];
      setIntegrations(prev => ({ ...prev, [type]: newState }));

      if (newState) {
          // Simulate Fetching Data
          if (type === 'imeddis') {
              setMockGenetics(getMockGenetics(selectedPatient.gender));
          } else {
              setMockLabs(getMockLabs(selectedPatient.gender));
          }
      } else {
          if (type === 'imeddis') setMockGenetics(null);
          else setMockLabs(null);
      }
  };

  const handleGenerate = async () => {
    if (!formData.patientWeight || !formData.medicalHistory) return;

    setIsLoading(true);
    setResult('');
    
    // Prepare enriched request
    const enrichedRequest: ProtocolRequest = {
        ...formData,
        genetics: mockGenetics || undefined,
        labs: mockLabs || undefined
    };

    const protocol = await generateProtocolWithThinking(enrichedRequest);
    setResult(protocol);
    setIsLoading(false);
  };

  const filteredPatients = MOCK_PATIENTS.filter(p => p.name.toLowerCase().includes(patientSearch.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto h-[calc(100vh-6rem)] grid grid-cols-12 gap-6 animate-fade-in pb-4">
      
      {/* LEFT PANEL: INPUT & INTEGRATION */}
      <div className="col-span-12 lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl shadow-soft border border-slate-200 dark:border-slate-700 overflow-hidden flex flex-col h-full">
         <div className="p-6 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700">
            <div className="flex items-center space-x-3 mb-1">
                <div className="w-10 h-10 bg-clinical-900 dark:bg-clinical-600 rounded-xl flex items-center justify-center text-white shadow-lg">
                    <i className="fa-solid fa-brain"></i>
                </div>
                <div>
                    <h2 className="text-xl font-black text-slate-900 dark:text-white leading-none">Protocolo AI</h2>
                    <p className="text-[10px] font-bold text-clinical-600 dark:text-clinical-400 uppercase tracking-widest mt-1">Cortex Engine V3.1</p>
                </div>
            </div>
         </div>

         <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
            {/* 1. Patient Selector */}
            <div className="relative">
                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2 block">Paciente Alvo</label>
                <div className="relative">
                    <input 
                        type="text" 
                        placeholder="Buscar paciente..."
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-clinical-500 outline-none"
                        value={patientSearch}
                        onChange={(e) => { setPatientSearch(e.target.value); setIsDropdownOpen(true); }}
                        onFocus={() => setIsDropdownOpen(true)}
                    />
                    <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 text-xs"></i>
                </div>
                {isDropdownOpen && patientSearch && (
                    <div className="absolute top-full left-0 w-full mt-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl rounded-xl z-50 overflow-hidden">
                        {filteredPatients.map(p => (
                            <button 
                                key={p.id} 
                                onClick={() => handleSelectPatient(p)}
                                className="w-full text-left px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-700 text-sm font-bold text-slate-700 dark:text-slate-200 border-b border-slate-50 dark:border-slate-700 last:border-0"
                            >
                                {p.name}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            {/* 2. Biometrics (Auto-filled) */}
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2 block">Peso (kg)</label>
                    <input 
                        type="number" 
                        className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white outline-none focus:border-clinical-400"
                        value={formData.patientWeight || ''}
                        onChange={(e) => setFormData({...formData, patientWeight: Number(e.target.value)})}
                    />
                </div>
                <div>
                    <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2 block">Altura (cm)</label>
                    <input 
                        type="number" 
                        className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white outline-none focus:border-clinical-400"
                        value={formData.patientHeight || ''}
                        onChange={(e) => setFormData({...formData, patientHeight: Number(e.target.value)})}
                    />
                </div>
            </div>

            <div>
                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2 block">Objetivo Clínico</label>
                <select 
                    className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white outline-none focus:border-clinical-400"
                    value={formData.goal}
                    onChange={(e) => setFormData({...formData, goal: e.target.value as any})}
                >
                    <option value="Hypertrophy">Hipertrofia & Ganho de Massa</option>
                    <option value="Weight Loss">Emagrecimento & Definição</option>
                    <option value="HRT">TRT / Reposição Hormonal</option>
                    <option value="Libido">Performance & Libido</option>
                </select>
            </div>

            {/* 3. INTEGRATION MODULES */}
            <div className="space-y-3">
                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Fontes de Dados (NEXUS)</label>
                
                {/* iMeddis Integration */}
                <div 
                    onClick={() => toggleIntegration('imeddis')}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all relative overflow-hidden group ${
                        integrations.imeddis 
                        ? 'bg-teal-50 dark:bg-teal-900/20 border-teal-500 shadow-md' 
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-teal-200 opacity-60 grayscale hover:grayscale-0'
                    }`}
                >
                    <div className="flex justify-between items-center relative z-10">
                        <div className="flex items-center space-x-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${integrations.imeddis ? 'bg-teal-500 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}>
                                <i className="fa-solid fa-dna"></i>
                            </div>
                            <div>
                                <h4 className={`font-black text-sm ${integrations.imeddis ? 'text-teal-900 dark:text-teal-200' : 'text-slate-600 dark:text-slate-400'}`}>iMeddis Interações Medicamentosas</h4>
                                {integrations.imeddis && <p className="text-[10px] font-bold text-teal-600 dark:text-teal-400">Sincronizado</p>}
                            </div>
                        </div>
                        <div className={`w-4 h-4 rounded-full border-2 ${integrations.imeddis ? 'bg-teal-500 border-teal-500' : 'border-slate-300 dark:border-slate-600'}`}></div>
                    </div>
                    {integrations.imeddis && mockGenetics && (
                        <div className="mt-3 pt-3 border-t border-teal-100 dark:border-teal-900 text-[10px] text-teal-800 dark:text-teal-300 font-medium space-y-1">
                            <p>• Risco Aromatização: <span className="font-bold">{mockGenetics.aromatizationRisk}</span></p>
                            <p>• Polimorfismos: <span className="font-bold">{mockGenetics.polymorphisms.join(', ')}</span></p>
                        </div>
                    )}
                </div>

                {/* LabPro Integration */}
                <div 
                    onClick={() => toggleIntegration('labpro')}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all relative overflow-hidden group ${
                        integrations.labpro 
                        ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500 shadow-md' 
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-blue-200 opacity-60 grayscale hover:grayscale-0'
                    }`}
                >
                     <div className="flex justify-between items-center relative z-10">
                        <div className="flex items-center space-x-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${integrations.labpro ? 'bg-blue-500 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}>
                                <i className="fa-solid fa-flask-vial"></i>
                            </div>
                            <div>
                                <h4 className={`font-black text-sm ${integrations.labpro ? 'text-blue-900 dark:text-blue-200' : 'text-slate-600 dark:text-slate-400'}`}>LabPro Análises Clínicas</h4>
                                {integrations.labpro && <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400">Sincronizado</p>}
                            </div>
                        </div>
                        <div className={`w-4 h-4 rounded-full border-2 ${integrations.labpro ? 'bg-blue-500 border-blue-500' : 'border-slate-300 dark:border-slate-600'}`}></div>
                    </div>
                    {integrations.labpro && mockLabs && (
                        <div className="mt-3 pt-3 border-t border-blue-100 dark:border-blue-900 text-[10px] text-blue-800 dark:text-blue-300 font-medium space-y-1">
                            <p>• Testosterona: <span className="font-bold">{mockLabs.hormonalStatus.testoTotal} ng/dL</span></p>
                            <p>• Fígado (TGO/TGP): <span className="font-bold">{mockLabs.liverFunction}</span></p>
                        </div>
                    )}
                </div>
            </div>

            <div>
                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2 block">Histórico / Observações</label>
                <textarea 
                    className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-medium text-slate-700 dark:text-slate-300 outline-none focus:border-clinical-400 resize-none h-24 text-xs"
                    value={formData.medicalHistory}
                    onChange={(e) => setFormData({...formData, medicalHistory: e.target.value})}
                    placeholder="Detalhes adicionais..."
                />
            </div>
         </div>

         <div className="p-6 border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 mt-auto">
            <button 
                onClick={handleGenerate}
                disabled={isLoading || !selectedPatient}
                className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-black text-lg rounded-2xl shadow-xl hover:bg-slate-800 dark:hover:bg-slate-200 disabled:bg-slate-300 dark:disabled:bg-slate-600 disabled:cursor-not-allowed transition-all flex items-center justify-center transform active:scale-95 group"
            >
                {isLoading ? (
                    <span className="flex items-center space-x-3">
                         <i className="fa-solid fa-circle-notch fa-spin"></i>
                         <span>Cruzando Dados...</span>
                    </span>
                ) : (
                    <>
                        <i className="fa-solid fa-microchip mr-2 text-clinical-400 dark:text-clinical-600 group-hover:text-white dark:group-hover:text-slate-900 transition-colors"></i>
                        GERAR PROTOCOLO
                    </>
                )}
            </button>
         </div>
      </div>

      {/* RIGHT PANEL: OUTPUT */}
      <div className="col-span-12 lg:col-span-8 bg-gradient-to-br from-white via-blue-50/40 to-pink-50/40 dark:from-slate-900 dark:via-slate-900 dark:to-pink-900/10 rounded-3xl shadow-soft-xl border border-white/60 dark:border-slate-700 flex flex-col h-full relative overflow-hidden backdrop-blur-sm">
         {/* Background Pattern */}
         <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5 pointer-events-none"></div>
         
         {result ? (
             <div className="flex-1 overflow-y-auto p-8 custom-scrollbar relative z-10 animate-fade-in">
                 <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-6 mb-6">
                    <div className="flex items-center space-x-4">
                        <img src={selectedPatient?.avatar || "https://ui-avatars.com/api/?name=P"} className="w-16 h-16 rounded-full border-4 border-slate-50 dark:border-slate-700 shadow-md" alt="Patient" />
                        <div>
                            <h3 className="text-2xl font-black text-slate-900 dark:text-white">{formData.patientName}</h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wide">Relatório de Precisão Gerado em {new Date().toLocaleDateString()}</p>
                        </div>
                    </div>
                    <div className="flex space-x-2">
                        <span className="px-3 py-1 bg-teal-50 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300 text-[10px] font-extrabold uppercase rounded border border-teal-100 dark:border-teal-800">
                             {integrations.imeddis ? 'Interações Integradas' : 'Sem Interações'}
                        </span>
                        <span className="px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-[10px] font-extrabold uppercase rounded border border-blue-100 dark:border-blue-800">
                             {integrations.labpro ? 'Análises Integradas' : 'Sem Análises'}
                        </span>
                    </div>
                 </div>
                 
                 <FormattedProtocol text={result} />
                 
                 <div className="mt-12 p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-start space-x-4">
                    <i className="fa-solid fa-shield-halved text-slate-400 text-2xl"></i>
                    <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">Validação Médica Necessária</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            Este protocolo é uma sugestão baseada em algoritmos de IA e dados fornecidos. A responsabilidade da prescrição é exclusivamente do médico assistente.
                        </p>
                    </div>
                 </div>
             </div>
         ) : (
             <div className="flex-1 flex flex-col items-center justify-center p-12 text-center relative z-10">
                 {isLoading ? (
                     <div className="space-y-6">
                         <div className="relative">
                            <div className="w-24 h-24 border-4 border-slate-100 dark:border-slate-800 border-t-clinical-600 rounded-full animate-spin mx-auto"></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                                <i className="fa-solid fa-brain text-2xl text-clinical-600 animate-pulse"></i>
                            </div>
                         </div>
                         <div>
                            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Processando Inteligência NEXUS</h3>
                            <p className="text-slate-500 dark:text-slate-400 text-sm mt-2">Analisando polimorfismos e marcadores bioquímicos...</p>
                         </div>
                     </div>
                 ) : (
                     <div className="space-y-4 opacity-50">
                         <div className="w-32 h-32 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
                            <i className="fa-solid fa-file-medical text-5xl text-slate-300 dark:text-slate-600"></i>
                         </div>
                         <h3 className="text-2xl font-bold text-slate-400 dark:text-slate-500">Aguardando Parâmetros</h3>
                         <p className="text-slate-400 dark:text-slate-500 max-w-md mx-auto">
                            Selecione um paciente e conecte os módulos iMeddis/LabPro para gerar um protocolo de alta precisão.
                         </p>
                     </div>
                 )}
             </div>
         )}
      </div>

    </div>
  );
};

export default ProtocolAssistant;
